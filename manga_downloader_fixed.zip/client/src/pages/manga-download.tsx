import { useState } from "react";
import { useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import NavigationHeader from "@/components/navigation-header";
import MangaDetail from "@/components/manga-detail";
import DownloadProgress from "@/components/download-progress";
import CompletedDownload from "@/components/completed-download";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Loader2 } from "lucide-react";
import type { MangaDetail as MangaDetailType } from "@shared/schema";

export default function MangaDownloadPage() {
  const [, params] = useRoute("/download/:id");
  const [downloadId, setDownloadId] = useState<number | null>(null);
  const [downloadCompleted, setDownloadCompleted] = useState(false);
  const [downloadData, setDownloadData] = useState(null);
  
  const mangaId = params?.id;

  const { data: manga, isLoading, error } = useQuery<MangaDetailType>({
    queryKey: [`/api/manga/${mangaId}`],
    enabled: !!mangaId,
  });

  const handleDownloadStart = (id: number) => {
    setDownloadId(id);
    setDownloadCompleted(false);
  };

  const handleDownloadComplete = (data) => {
    setDownloadData(data);
    setDownloadCompleted(true);
    setDownloadId(null);
  };

  const handleNewDownload = () => {
    setDownloadCompleted(false);
    setDownloadId(null);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <NavigationHeader />
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-center py-12">
            <div className="text-center">
              <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
              <p>Loading manga details...</p>
            </div>
          </div>
        </main>
      </div>
    );
  }

  if (error || !manga) {
    return (
      <div className="min-h-screen bg-gray-50">
        <NavigationHeader />
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center py-12">
            <p className="text-red-600 mb-4">Failed to load manga details.</p>
            <Link href="/">
              <Button variant="outline" className="flex items-center gap-2">
                <ArrowLeft size={16} />
                Back to Search
              </Button>
            </Link>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <NavigationHeader />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-4">
          <Link href="/">
            <Button
              variant="outline"
              className="flex items-center gap-2"
            >
              <ArrowLeft size={16} />
              Back to Search
            </Button>
          </Link>
        </div>

        {!downloadId && !downloadCompleted && (
          <MangaDetail 
            manga={manga}
            onBackToSearch={() => window.history.back()}
            onDownloadStart={handleDownloadStart}
          />
        )}
        
        {downloadId && (
          <DownloadProgress 
            downloadId={downloadId}
            onComplete={handleDownloadComplete}
            onCancel={() => setDownloadId(null)}
          />
        )}
        
        {downloadCompleted && (
          <CompletedDownload 
            downloadId={downloadId || 0}
            onNewDownload={handleNewDownload}
          />
        )}
      </main>
    </div>
  );
}