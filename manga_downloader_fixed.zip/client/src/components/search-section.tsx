import { useState, useEffect } from "react";
import { Search, Loader2 } from "lucide-react";
import { Input } from "@/components/ui/input";

interface SearchSectionProps {
  onSearch: (query: string) => void;
  initialQuery?: string;
}

export default function SearchSection({ onSearch, initialQuery = "" }: SearchSectionProps) {
  const [query, setQuery] = useState(initialQuery);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (query.trim().length >= 2) {
        setIsLoading(true);
        onSearch(query.trim());
        setTimeout(() => setIsLoading(false), 500);
      } else if (query.trim().length === 0) {
        onSearch("");
      }
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [query, onSearch]);

  return (
    <div className="mb-8">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-6">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Find Your Manga</h2>
          <p className="text-gray-600">Search and download manga chapters in batch with automatic PDF conversion</p>
        </div>
        
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="text-gray-400" size={20} />
          </div>
          <Input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search manga titles..."
            className="block w-full pl-10 pr-12 py-4 text-lg border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200 shadow-sm"
          />
          <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
            {isLoading && (
              <Loader2 className="h-5 w-5 text-primary animate-spin" />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
