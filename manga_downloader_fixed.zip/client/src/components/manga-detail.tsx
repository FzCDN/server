import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Download, Clock, Loader2 } from "lucide-react";
import { MangaDetail as MangaDetailType } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import DownloadModal from "@/components/download-modal";

interface MangaDetailProps {
  manga: MangaDetailType;
  onBackToSearch: () => void;
  onDownloadStart: (downloadId: number) => void;
}

export default function MangaDetail({ manga, onBackToSearch, onDownloadStart }: MangaDetailProps) {
  const [selectedChapters, setSelectedChapters] = useState<string[]>([]);
  const [isDownloading, setIsDownloading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [currentStatus, setCurrentStatus] = useState("");
  const [isCompleted, setIsCompleted] = useState(false);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [chapterStatuses, setChapterStatuses] = useState<{[key: string]: 'pending' | 'processing' | 'ok'}>({});
  const { toast } = useToast();

  const handleChapterToggle = (chapterId: string) => {
    console.log('Toggling chapter:', chapterId); // Debug log
    setSelectedChapters(prev => {
      if (prev.includes(chapterId)) {
        return prev.filter(id => id !== chapterId);
      } else {
        // Max 10 chapters limit
        if (prev.length >= 10) {
          toast({
            title: "Maximum limit reached",
            description: "You can only select up to 10 chapters at once.",
            variant: "destructive",
          });
          return prev;
        }
        return [...prev, chapterId];
      }
    });
  };

  const handleSelectAll = () => {
    if (selectedChapters.length === manga.chapters.length) {
      setSelectedChapters([]);
    } else {
      // Limit to max 10 chapters
      const chaptersToSelect = manga.chapters.slice(0, 10).map(ch => ch.chapterId);
      setSelectedChapters(chaptersToSelect);
      
      if (manga.chapters.length > 10) {
        toast({
          title: "Selected first 10 chapters",
          description: "Maximum 10 chapters can be selected at once.",
        });
      }
    }
  };

  const simulateRealisticProgress = (totalChapters: number) => {
    let processedCount = 0;
    let currentProcessingIndex = 0;
    
    const processNextChapter = () => {
      if (currentProcessingIndex < selectedChapters.length) {
        const chapterIndex = currentProcessingIndex;
        const chapterId = selectedChapters[chapterIndex];
        const chapterNumber = totalChapters - chapterIndex; // Reverse order like backend
        
        // Set current chapter to processing
        setChapterStatuses(prev => ({
          ...prev,
          [chapterId]: 'processing'
        }));
        
        console.log(`Chapter ${chapterNumber} Processing...`);
        
        // Simulate realistic processing time (5-12 seconds per chapter)
        setTimeout(() => {
          setChapterStatuses(prev => ({
            ...prev,
            [chapterId]: 'ok'
          }));
          
          processedCount++;
          console.log(`Chapter ${chapterNumber} OK`);
          
          const progress = Math.round((processedCount / totalChapters) * 85); // Cap at 85%
          setDownloadProgress(progress);
          
          currentProcessingIndex++;
          
          if (currentProcessingIndex >= totalChapters) {
            setCurrentStatus("Creating ZIP archive...");
            console.log("Creating ZIP archive...");
          } else {
            // Process next chapter immediately
            processNextChapter();
          }
        }, Math.random() * 7000 + 5000); // 5-12 seconds per chapter
      }
    };
    
    // Start processing first chapter
    processNextChapter();
    
    return null; // No interval to clear
  };

  const handleDownloadStart = async () => {
    if (selectedChapters.length === 0) {
      toast({
        title: "No chapters selected",
        description: "Please select at least one chapter to download.",
        variant: "destructive",
      });
      return;
    }

    setIsDownloading(true);
    setShowModal(true);
    setDownloadProgress(0);
    setIsCompleted(false);
    
    // Initialize chapter statuses
    const initialStatuses: {[key: string]: 'pending' | 'processing' | 'ok'} = {};
    selectedChapters.forEach(chapterId => {
      initialStatuses[chapterId] = 'pending';
    });
    setChapterStatuses(initialStatuses);
    
    // Start realistic chapter progress simulation
    simulateRealisticProgress(selectedChapters.length);
    
    try {
      console.log('Sending download request with chapters:', selectedChapters);
      
      // Make actual download request
      const response = await fetch('/api/download', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          mangaId: manga.id,
          mangaTitle: manga.title,
          chapters: selectedChapters,
        }),
      });

      console.log('Response status:', response.status);
      console.log('Response headers:', response.headers.get('content-type'));

      if (!response.ok) {
        throw new Error('Download failed');
      }

      // Check response content type
      const contentType = response.headers.get('content-type');
      
      if (contentType === 'application/zip') {
        // Server is streaming ZIP directly, handle as blob download
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        setDownloadUrl(url);
        console.log('ZIP blob URL created:', url);
      } else {
        // Server returned JSON with download URL
        const responseData = await response.json();
        console.log('Server response:', responseData);
        
        if (responseData.success && responseData.downloadUrl) {
          setDownloadUrl(responseData.downloadUrl);
          console.log('Download URL received:', responseData.downloadUrl);
        } else {
          throw new Error('Server did not return download URL');
        }
      }

      // Progress simulation will handle completion UI

    } catch (error) {
      console.error("Download error:", error);
      clearInterval(progressInterval);
      setShowModal(false);
      setIsDownloading(false);
      setDownloadProgress(0);
      setIsCompleted(false);
      
      toast({
        title: "Download failed",
        description: "Failed to process download. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleCloseModal = () => {
    if (isCompleted) {
      setShowModal(false);
      setIsDownloading(false);
      setDownloadProgress(0);
      setIsCompleted(false);
      setCurrentStatus("");
    }
  };

  return (
    <div className="mb-8 animate-fade-in">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <Button 
              variant="ghost" 
              onClick={onBackToSearch}
              className="flex items-center gap-2 text-blue-600 hover:text-blue-700"
            >
              <ArrowLeft size={16} />
              Back to Search
            </Button>
          </div>
          <CardTitle className="text-2xl font-bold">{manga.title}</CardTitle>
        </CardHeader>
        
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <img 
                src={manga.imageUrl} 
                alt={manga.title}
                className="w-full max-w-sm rounded-lg shadow-md"
              />
            </div>
            
            <div className="space-y-4">
              <div className="flex gap-2">
                <Badge variant="secondary">
                  <Clock size={14} className="mr-1" />
                  {manga.status}
                </Badge>
                <Badge variant="outline">
                  ⭐ {manga.rating}
                </Badge>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-2">Description</h3>
                <p className="text-gray-600 leading-relaxed">{manga.synopsis}</p>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-2">Genres</h3>
                <div className="flex flex-wrap gap-2">
                  {manga.genres.map((genre, index) => (
                    <Badge key={index} variant="outline">{genre}</Badge>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Chapters ({manga.chapters.length})</h3>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleSelectAll}
                >
                  {selectedChapters.length === manga.chapters.length ? "Deselect All" : "Select All"}
                </Button>
                <Button 
                  onClick={handleDownloadStart}
                  disabled={isDownloading || selectedChapters.length === 0}
                  className="flex items-center gap-2"
                >
                  {isDownloading ? (
                    <Loader2 size={16} className="animate-spin" />
                  ) : (
                    <Download size={16} />
                  )}
                  Download Selected ({selectedChapters.length})
                </Button>
              </div>
            </div>

            <div className="grid gap-2 max-h-96 overflow-y-auto">
              {manga.chapters.map((chapter, index) => (
                <div 
                  key={`${chapter.chapterId}-${index}`}
                  className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-gray-50"
                >
                  <Checkbox
                    checked={selectedChapters.includes(chapter.chapterId)}
                    onCheckedChange={() => handleChapterToggle(chapter.chapterId)}
                  />
                  <div className="flex-1">
                    <p className="font-medium">{chapter.title}</p>
                    <p className="text-sm text-gray-500">{chapter.date}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <DownloadModal
        isOpen={showModal}
        onClose={handleCloseModal}
        mangaTitle={manga.title}
        chapterCount={selectedChapters.length}
        currentStep={currentStatus}
        progress={downloadProgress}
        isCompleted={isCompleted}
        downloadUrl={downloadUrl}
        chapterStatuses={chapterStatuses}
        selectedChapters={selectedChapters}
      />
    </div>
  );
}