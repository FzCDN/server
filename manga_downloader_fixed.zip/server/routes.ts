import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertDownloadSchema, chapterDetailSchema, type Download } from "@shared/schema";
import { z } from "zod";
import path from "path";
import fs from "fs/promises";
import sharp from "sharp";
import PDFDocument from "pdfkit";
import JSZip from "jszip";
import sizeOf from "probe-image-size";

const MANGA_API_BASE = "https://lk21.imgdesu.art/api/manga";
const DOWNLOADS_DIR = path.join(process.cwd(), "downloads");

// Ensure downloads directory exists
fs.mkdir(DOWNLOADS_DIR, { recursive: true });

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Search manga
  app.get("/api/search/:query", async (req, res) => {
    try {
      const { query } = req.params;
      const { page = "1" } = req.query;
      
      const apiUrl = `${MANGA_API_BASE}/search/${encodeURIComponent(query)}?page=${page}`;
      console.log("Fetching from:", apiUrl);
      
      const response = await fetch(apiUrl, {
        method: 'GET',
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'application/json, */*',
          'Accept-Language': 'en-US,en;q=0.9',
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache'
        }
      });
      
      console.log("Response status:", response.status);
      console.log("Response headers:", Object.fromEntries(response.headers.entries()));
      
      if (!response.ok) {
        const errorText = await response.text();
        console.log("Error response body:", errorText);
        throw new Error(`API request failed: ${response.status} - ${errorText}`);
      }
      
      const data = await response.json();
      console.log("API response data:", JSON.stringify(data, null, 2));
      res.json(data);
    } catch (error) {
      console.error("Search error:", error);
      res.status(500).json({ message: "Failed to search manga", error: String(error) });
    }
  });

  // Get manga detail
  app.get("/api/manga/:id", async (req, res) => {
    try {
      const { id } = req.params;
      
      const response = await fetch(`${MANGA_API_BASE}/detail/${id}`);
      if (!response.ok) {
        throw new Error(`API request failed: ${response.status}`);
      }
      
      const data = await response.json();
      res.json(data);
    } catch (error) {
      console.error("Manga detail error:", error);
      res.status(500).json({ message: "Failed to fetch manga details" });
    }
  });

  // Get chapter detail
  app.get("/api/chapter/:chapterId", async (req, res) => {
    try {
      const { chapterId } = req.params;
      
      const response = await fetch(`${MANGA_API_BASE}/chapter/${chapterId}`);
      if (!response.ok) {
        throw new Error(`API request failed: ${response.status}`);
      }
      
      const data = await response.json();
      res.json(data);
    } catch (error) {
      console.error("Chapter detail error:", error);
      res.status(500).json({ message: "Failed to fetch chapter details" });
    }
  });

  // Direct download with ZIP response
  app.post("/api/download", async (req, res) => {
    try {
      const { mangaId, mangaTitle, chapters } = req.body;
      
      console.log(`Received download request:`, { mangaId, mangaTitle, chapters });
      
      if (!chapters || chapters.length === 0) {
        return res.status(400).json({ message: "No chapters selected" });
      }
      
      if (chapters.length > 10) {
        return res.status(400).json({ message: "Maximum 10 chapters allowed" });
      }

      console.log(`Starting download for: ${mangaTitle} (${chapters.length} chapters)`);
      
      // Create ZIP
      const zip = new JSZip();
      
      for (let i = 0; i < chapters.length; i++) {
        const chapterId = chapters[i];
        console.log(`Processing chapter ${i + 1}/${chapters.length}: ${chapterId}`);
        
        if (!chapterId || chapterId === 'null') {
          console.error(`Invalid chapter ID: ${chapterId}`);
          continue;
        }
        
        try {
          // Fetch chapter data
          const chapterResponse = await fetch(`${MANGA_API_BASE}/chapter/${chapterId}`, {
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
              'Accept': 'application/json, */*'
            }
          });
          
          if (!chapterResponse.ok) {
            console.error(`Chapter fetch failed: ${chapterResponse.status}`);
            continue;
          }
          
          const chapterJson = await chapterResponse.json();
          const chapterData = chapterDetailSchema.parse(chapterJson);
          console.log(`Chapter data fetched: ${chapterData.title}, ${chapterData.sources[0]?.images?.length || 0} images`);
          
          // Process chapter to PDF
          const pdfBuffer = await processChapterToPDF(chapterData);
          console.log(`PDF generated, size: ${pdfBuffer.length} bytes`);
          
          // Add to ZIP
          const sanitizedChapterTitle = chapterData.title.replace(/[<>:"/\\|?*\u0000-\u001f\u007f-\u009f]/g, '_').replace(/[^\w\s-_.]/g, '');
          const filename = `${sanitizedChapterTitle}.pdf`;
          zip.file(filename, pdfBuffer);
          
          console.log(`Chapter ${i + 1} completed`);
        } catch (error) {
          console.error(`Error processing chapter ${chapterId}:`, error);
        }
      }

      console.log("All chapters processed, creating ZIP file...");
      
      // Generate ZIP and send
      const zipBuffer = await zip.generateAsync({ type: "nodebuffer" });
      console.log(`ZIP file created, size: ${zipBuffer.length} bytes`);
      
      // Save ZIP to temporary storage and return success  
      const sanitizedTitle = mangaTitle
        .replace(/[<>:"/\\|?*\u0000-\u001f\u007f-\u009f]/g, '_')
        .replace(/[^\w\s-_.]/g, '')
        .replace(/\s+/g, '_')
        .replace(/_{2,}/g, '_')
        .replace(/^_+|_+$/g, '');
      const fileName = `${sanitizedTitle || 'manga'}_${Date.now()}.zip`;
      const filePath = path.join(DOWNLOADS_DIR, fileName);
      
      await fs.writeFile(filePath, zipBuffer);
      console.log(`ZIP file saved: ${fileName}, size: ${zipBuffer.length} bytes`);
      
      // Schedule file deletion after 30 minutes
      setTimeout(async () => {
        try {
          await fs.unlink(filePath);
          console.log(`Auto-cleanup: Deleted ${fileName} after 30 minutes`);
        } catch (error) {
          console.log(`Auto-cleanup: Failed to delete ${fileName}:`, error);
        }
      }, 30 * 60 * 1000); // 30 minutes in milliseconds

      // Return success with download URL
      res.json({ 
        success: true, 
        downloadUrl: `/api/download/file/${fileName}`,
        fileName: fileName,
        size: zipBuffer.length
      });
      
    } catch (error) {
      console.error("Download error:", error);
      if (!res.headersSent) {
        res.status(500).json({ message: "Failed to process download" });
      }
    }
  });





  // Download file endpoint
  app.get("/api/download/file/:filename", async (req, res) => {
    try {
      const { filename } = req.params;
      const filePath = path.join(DOWNLOADS_DIR, filename);
      
      try {
        await fs.access(filePath);
      } catch (error) {
        return res.status(404).json({ message: "File not found" });
      }
      
      const stats = await fs.stat(filePath);
      
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.setHeader('Content-Length', stats.size);
      
      const fileBuffer = await fs.readFile(filePath);
      res.send(fileBuffer);
      
    } catch (error) {
      console.error("File download error:", error);
      res.status(500).json({ message: "Failed to download file" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Direct streaming function (no file storage)
async function streamDirectDownload(downloadData: any, res: any) {
  try {
    console.log(`Starting direct stream for: ${downloadData.mangaTitle}`);
    
    const zip = new JSZip();
    const totalChapters = downloadData.chapters.length;
    console.log(`Processing ${totalChapters} chapters for ${downloadData.mangaTitle}`);

    for (let i = 0; i < totalChapters; i++) {
      const chapterId = downloadData.chapters[i];
      console.log(`Processing chapter ${i + 1}/${totalChapters}: ${chapterId}`);
      
      // Fetch chapter data
      console.log(`Fetching chapter data from: ${MANGA_API_BASE}/chapter/${chapterId}`);
      const chapterResponse = await fetch(`${MANGA_API_BASE}/chapter/${chapterId}`, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Accept': 'application/json, */*'
        }
      });
      
      if (!chapterResponse.ok) {
        throw new Error(`Failed to fetch chapter ${chapterId}: ${chapterResponse.status}`);
      }
      
      const chapterData = chapterDetailSchema.parse(await chapterResponse.json());
      console.log(`Chapter data fetched: ${chapterData.title}, ${chapterData.sources[0]?.images?.length || 0} images`);
      
      // Process chapter to PDF
      console.log(`Converting chapter to PDF: ${chapterData.title}`);
      const pdfBuffer = await processChapterToPDF(chapterData);
      console.log(`PDF generated, size: ${pdfBuffer.length} bytes`);
      
      // Add PDF to ZIP
      const fileName = `${String(i + 1).padStart(3, '0')} - ${chapterData.title.replace(/[<>:"/\\|?*]/g, '_')}.pdf`;
      zip.file(fileName, pdfBuffer);
      
      console.log(`Chapter ${i + 1} completed`);
    }

    console.log("All chapters processed, streaming ZIP...");

    // Generate and stream ZIP directly to response
    const zipBuffer = await zip.generateAsync({ 
      type: "nodebuffer",
      compression: "DEFLATE",
      compressionOptions: { level: 6 }
    });

    res.end(zipBuffer);
    console.log(`Direct download completed for: ${downloadData.mangaTitle}`);

  } catch (error) {
    console.error("Direct streaming error:", error);
    throw error;
  }
}



// Background processing function with visible progress
async function processDownload(downloadId: number) {
  try {
    console.log(`Starting download processing for ID: ${downloadId}`);
    let download = await storage.getDownload(downloadId);
    if (!download) return;

    await storage.updateDownload(downloadId, { status: "processing", progress: 5 });

    const zip = new JSZip();
    const totalChapters = download.chapters.length;
    console.log(`Processing ${totalChapters} chapters for ${download.mangaTitle}`);

    for (let i = 0; i < totalChapters; i++) {
      const chapterId = download.chapters[i];
      console.log(`Processing chapter ${i + 1}/${totalChapters}: ${chapterId}`);
      
      // Check if download was cancelled
      download = await storage.getDownload(downloadId);
      if (!download || download.status === "failed") return;

      try {
        // Update progress for fetching with current chapter info
        const fetchProgress = Math.round(((i / totalChapters) * 80) + 10);
        
        // Fetch chapter data first to get title
        console.log(`Fetching chapter data from: ${MANGA_API_BASE}/chapter/${chapterId}`);
        const chapterResponse = await fetch(`${MANGA_API_BASE}/chapter/${chapterId}`, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'application/json, */*'
          }
        });
        
        console.log(`Chapter response status: ${chapterResponse.status}`);
        if (!chapterResponse.ok) {
          const errorText = await chapterResponse.text();
          console.error(`Chapter fetch failed: ${chapterResponse.status} - ${errorText}`);
          throw new Error(`Failed to fetch chapter ${chapterId}: ${chapterResponse.status}`);
        }
        
        const chapterJson = await chapterResponse.json();
        console.log(`Chapter JSON received:`, JSON.stringify(chapterJson, null, 2));
        const chapterData = chapterDetailSchema.parse(chapterJson);
        console.log(`Chapter data fetched: ${chapterData.title}, ${chapterData.sources[0]?.images?.length || 0} images`);
        
        // Update with current chapter being processed
        await storage.updateDownload(downloadId, { 
          progress: fetchProgress,
          currentChapter: `Processing ${chapterData.title}...`
        });
        
        // Process chapter to PDF
        console.log(`Converting chapter to PDF: ${chapterData.title}`);
        const pdfBuffer = await processChapterToPDF(chapterData);
        console.log(`PDF generated, size: ${pdfBuffer.length} bytes`);
        
        // Add PDF to ZIP
        const fileName = `${String(i + 1).padStart(3, '0')} - ${chapterData.title.replace(/[<>:"/\\|?*]/g, '_')}.pdf`;
        zip.file(fileName, pdfBuffer);
        
        // Update progress
        const progress = Math.round(((i + 1) / totalChapters) * 80) + 10;
        await storage.updateDownload(downloadId, { 
          progress,
          currentChapter: `Completed ${chapterData.title}`
        });
        console.log(`Chapter ${i + 1} completed, progress: ${progress}%`);
        
      } catch (error) {
        console.error(`Error processing chapter ${chapterId}:`, error);
        await storage.updateDownload(downloadId, { 
          status: "failed",
          progress: Math.round(((i + 1) / totalChapters) * 80) + 10
        });
        return;
      }
    }

    console.log("All chapters processed, creating ZIP file...");
    await storage.updateDownload(downloadId, { 
      progress: 95,
      currentChapter: "Creating ZIP file..."
    });

    // Generate ZIP file
    const zipBuffer = await zip.generateAsync({ 
      type: "nodebuffer",
      compression: "DEFLATE",
      compressionOptions: { level: 6 }
    });
    
    const zipFileName = `${download.mangaTitle.replace(/[<>:"/\\|?*]/g, '_')}_${Date.now()}.zip`;
    const zipPath = path.join(DOWNLOADS_DIR, zipFileName);
    
    await fs.writeFile(zipPath, zipBuffer);
    console.log(`ZIP file created: ${zipFileName}, size: ${zipBuffer.length} bytes`);
    
    // Update download record
    await storage.updateDownload(downloadId, {
      status: "completed",
      progress: 100,
      currentChapter: `Download complete! ${totalChapters} chapters ready`,
      zipFileName,
      downloadUrl: `/api/download/${downloadId}/file`
    });

    console.log(`Download ${downloadId} completed successfully!`);

  } catch (error) {
    console.error("Download processing error:", error);
    await storage.updateDownload(downloadId, { status: "failed" });
  }
}

async function processChapterToPDF(chapterData: any): Promise<Buffer> {
  return new Promise(async (resolve, reject) => {
    try {
      console.log(`Creating PDF for: ${chapterData.title}`);
      const doc = new PDFDocument({ autoFirstPage: false });
      const buffers: Buffer[] = [];
      
      doc.on('data', buffers.push.bind(buffers));
      doc.on('end', () => {
        const pdfBuffer = Buffer.concat(buffers);
        console.log(`PDF completed for ${chapterData.title}, size: ${pdfBuffer.length} bytes`);
        resolve(pdfBuffer);
      });

      const images = chapterData.sources[0]?.images || [];
      console.log(`Processing ${images.length} images for ${chapterData.title}`);
      
      if (images.length === 0) {
        console.log('No images found, creating empty PDF');
        doc.addPage();
        doc.fontSize(20).text('No images available for this chapter', 50, 50);
        doc.end();
        return;
      }

      // Process images in parallel but limit concurrency
      const processImage = async (imageUrl: string, index: number) => {
        try {
          console.log(`Fetching image ${index + 1}/${images.length}: ${imageUrl}`);
          
          // Fetch image with timeout
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 second timeout
          
          const imageResponse = await fetch(imageUrl, {
            signal: controller.signal,
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
              'Accept': 'image/*'
            }
          });
          
          clearTimeout(timeoutId);
          
          if (!imageResponse.ok) {
            console.log(`Failed to fetch image ${index + 1}: ${imageResponse.status}`);
            return null;
          }
          
          const imageBuffer = await imageResponse.arrayBuffer();
          const buffer = Buffer.from(imageBuffer);
          console.log(`Image ${index + 1} fetched, size: ${buffer.length} bytes`);
          
          // Process image using sharp: resize and convert to JPEG
          const processedBuffer = await sharp(buffer)
            .resize({ width: 1000, withoutEnlargement: true })
            .jpeg({ quality: 70, progressive: true })
            .toBuffer();
          
          console.log(`Image ${index + 1} processed to JPEG`);
          
          // Get processed image dimensions
          const metadata = await sharp(processedBuffer).metadata();
          const width = (metadata.width || 1000) * 0.75;
          const height = (metadata.height || 1400) * 0.75;
          
          return { processedBuffer, width, height, index };
          
        } catch (imageError) {
          console.error(`Error processing image ${index + 1} (${imageUrl}):`, imageError);
          return null;
        }
      };

      // Process images with limited concurrency (3 at a time)
      const concurrencyLimit = 3;
      const processedImages: Array<{ processedBuffer: Buffer, width: number, height: number, index: number } | null> = [];
      
      for (let i = 0; i < images.length; i += concurrencyLimit) {
        const batch = images.slice(i, i + concurrencyLimit);
        const batchPromises = batch.map((imageUrl, batchIndex) => 
          processImage(imageUrl, i + batchIndex)
        );
        
        const batchResults = await Promise.all(batchPromises);
        processedImages.push(...batchResults);
      }

      // Add processed images to PDF
      let addedPages = 0;
      for (const imageData of processedImages) {
        if (imageData) {
          const { processedBuffer, width, height, index } = imageData;
          
          // Add page with custom size
          doc.addPage({ size: [width, height] });
          
          // Add image to PDF
          doc.image(processedBuffer, 0, 0, { width, height });
          
          // Add watermark
          doc.fillColor('gray')
             .fontSize(10)
             .text('PDF by manhwadesu.com', width - 150, height - 20, {
               align: 'right',
               width: 140,
             });
          
          addedPages++;
          console.log(`Added page ${addedPages} to PDF`);
        }
      }
      
      if (addedPages === 0) {
        console.log('No images were processed successfully, creating error page');
        doc.addPage();
        doc.fontSize(16).text('Failed to load images for this chapter', 50, 50);
      }
      
      console.log(`Finalizing PDF with ${addedPages} pages`);
      doc.end();
      
    } catch (error) {
      console.error('PDF processing error:', error);
      reject(error);
    }
  });
}
