<?php
session_write_close();
include __DIR__ . '/includes/includes.php';
header('Referrer-Policy: same-origin, no-referrer, strict-origin-when-cross-origin');

set_env('site_name', get_option('site_name'));
set_env('page_type', 'website');
set_env('title', '');
set_env('description', '');
set_env('poster', '');
set_env('slogan', '');

$shortcut = ['segments', 'hls', 'dash', 'playlist', 'videoplayback', 'poster', 'subtitle', 'filmstrip'];
$uri = get_page_uris();
$page = !empty($uri[0]) ? trim(pathinfo($uri[0], PATHINFO_FILENAME)) : 'home';
$globalPageDir = FRONTEND_PATH . '/';
$globalPage = replaceSeparator($globalPageDir . $page . '.php');
if (in_array($page, $shortcut) && is_readable($globalPage)) {
    session_write_close();
    include $globalPage;
} else {
    if ($page === get_option('slug_embed') || $page === 'e') {
        session_write_close();
        $page = 'embed';
    } elseif ($page === get_option('slug_download') || $page === 'd') {
        session_write_close();
        $page = 'download';
    } elseif ($page === get_option('slug_request') || $page === 'r') {
        session_write_close();
        $page = 'embed2';
    }
    $globalPage = replaceSeparator($globalPageDir . $page . '.php');

    $frontendPage = replaceSeparator(FRONTEND_THEME_PATH . '/views/' . $page . '.php');

    $backendSlug = trim(strtr(get_page(), [$page => '']), '/');
    $backendPage = replaceSeparator(BACKEND_THEME_PATH . '/views/' . $backendSlug . '.php');

    $globalBackendDir = FRONTEND_PATH . '/backend/';
    $globalBackendPage = replaceSeparator($globalBackendDir . $backendSlug . '.php');

    if (is_readable($backendPage)) {
        session_write_close();
        include $backendPage;
    } elseif (is_readable($globalBackendPage)) {
        session_write_close();
        include $globalBackendPage;
    } elseif (is_readable($frontendPage)) {
        session_write_close();
        include $frontendPage;
    } elseif (is_readable($globalPage)) {
        session_write_close();
        include $globalPage;
    } else {
        $anonymous = get_option('anonymous_generator');
        if ((is_null($anonymous) || validate_boolean($anonymous)) && !is_admin()) {
            session_write_close();
            echo '<div style="text-align:center">Silence is golden!</div>';
        } else {
            session_write_close();
            include replaceSeparator($globalPageDir . '404.php');
        }
    }
}
