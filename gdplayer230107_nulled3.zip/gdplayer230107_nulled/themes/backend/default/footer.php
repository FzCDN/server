<?php
session_write_close();
if (!defined('BASE_DIR')) {
    session_write_close();
    exit('Access denied!');
}

$html = new \GDPlayer\HTML();
$plugins = new \GDPlayer\Plugins();
$userLogin = current_user();
$adminDir = ADMIN_PATH;
$dmca_link = get_option('dmca_page_link');
$contact_link = get_option('contact_page_link');
?>
</main>
<footer id="footer" class="row py-5 bg-dark text-center text-light rounded-bottom">
    <div class="col-12">
        <ul class="nav justify-content-center mb-3">
            <li class="nav-item">
                <a class="nav-link" href="">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="changelog/">Change Log</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="terms/">Terms</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="privacy/">Privacy</a>
            </li>
            <?php if (!empty($dmca_link)) : ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo $dmca_link; ?>" target="_blank" rel="noopener">DMCA</a>
                </li>
            <?php endif; ?>
            <?php if (!empty($contact_link)) : ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo $contact_link; ?>" target="_blank" rel="noopener">Contact</a>
                </li>
            <?php endif; ?>
        </ul>
        <p>&copy; 2020 - <?php echo date('Y'); ?>. Made with <i class="fas fa-heart text-danger"></i> by <?php echo sitename(); ?>.</p>
    </div>
</footer>
</div>
<button type="button" id="gotoTop" title="Go to Top" class="bg-custom shadow">
    <span class="gotoContent">
        <em class="fas fa-chevron-up"></em>
    </span>
</button>
<?php
$script = $plugins->getBackendJS(true);
if ($script) {
    session_write_close();
    echo $script;
}
include BACKEND_THEME_PATH . DIRECTORY_SEPARATOR . 'scripts.php';
?>
</body>

</html>
<?php
$output = ob_get_contents();
ob_end_clean();
$output = gzencode($output, 9);
header('Content-Encoding: gzip');
header('Content-Length: ' . strlen($output));
echo $output;
