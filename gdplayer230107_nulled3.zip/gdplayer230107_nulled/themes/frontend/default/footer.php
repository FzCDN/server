<?php
session_write_close();
if (!defined('BASE_DIR')) {
    session_write_close();
    exit('Access denied!');
}

$html = new \GDPlayer\HTML();
$plugins = new \GDPlayer\Plugins();
$dmca_link = get_option('dmca_page_link');
$contact_link = get_option('contact_page_link');
?>
</main>
<footer id="footer" class="row py-5 bg-dark text-center text-light rounded-bottom">
    <div class="col-12">
        <ul class="nav justify-content-center mb-3">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo BASE_URL; ?>">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="changelog">Change Log</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="terms">Terms</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="privacy">Privacy</a>
            </li>
            <?php if (!empty($dmca_link)) : ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo $dmca_link; ?>" target="_blank" rel="noopener">DMCA</a>
                </li>
            <?php endif; ?>
            <?php if (!empty($contact_link)) : ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo $contact_link; ?>" target="_blank" rel="noopener">Contact</a>
                </li>
            <?php endif; ?>
        </ul>
        <p>&copy; 2020 - <?php echo date('Y'); ?>. Made with <i class="fas fa-heart text-danger"></i> by <?php echo sitename(); ?>.</p>
    </div>
</footer>
</div>
<button type="button" id="gotoTop" title="Go to Top" class="bg-custom shadow">
    <span class="gotoContent">
        <em class="fas fa-chevron-up"></em>
    </span>
</button>
<script src="assets/vendor/pwacompat.min.js" defer></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>
<script src="assets/vendor/bs-custom-file-input/bs-custom-file-input.min.js" defer></script>
<script src="assets/vendor/sweetalert.min.js" defer></script>
<script src="assets/js/main.js" defer></script>
<?php
echo $html->recaptcha();
$script = $plugins->getFrontendJS(true);
if ($script) {
    session_write_close();
    echo $script;
}
echo $html->sharer();
echo $html->histats();
echo htmlspecialchars_decode(get_option('chat_widget'), ENT_QUOTES);
?>
<script>
    if ("serviceWorker" in navigator) {
        navigator.serviceWorker
            .register('sw.js')
            .then(function(res) {
                console.debug("service worker registered");
            })
            .catch(function(err) {
                console.debug("service worker not registered", err);
            });
    }

    var deferredPrompt,
        $prompt;

    window.addEventListener('beforeinstallprompt', function(e) {
        e.preventDefault();
        deferredPrompt = e;
        $prompt = $('<div id="installPrompt" class="position-fixed bg-white p-3 shadow rounded text-center" style="bottom:50px;left:50%;z-index:11;width:200px;transform:translateX(-50%)"><p><strong>You can access this website on your device easily.</strong></p><button type="button" id="installWeb" class="btn btn-custom"><i class="fas fa-download mr-2"></i>Install Now</button><a id="hideInstallPrompt" href="javascript:void(0)" onclick="$(\'#installPrompt\').remove()" role="button" class="text-danger position-absolute bg-white rounded-circle p-2" style="top:-1rem;right:-1rem;width:2.5rem;height:2.5rem"><i class="fas fa-xl fa-times-circle"></i></a></div>');
        $('body').append($prompt);
        document.getElementById('installWeb').addEventListener('click', async () => {
            deferredPrompt.prompt();
            const {
                outcome
            } = await deferredPrompt.userChoice;
            if (outcome !== 'dismissed') {
                deferredPrompt = null;
            }
            $prompt.remove()
        });
    });

    window.addEventListener('appinstalled', function() {
        $(document).find('#hideInstallPrompt').click();
        deferredPrompt = null;
    });
</script>
</body>

</html>
<?php
$output = ob_get_contents();
ob_end_clean();
$output = gzencode($output, 9);
header('Content-Encoding: gzip');
header('Content-Length: ' . strlen($output));
echo $output;
