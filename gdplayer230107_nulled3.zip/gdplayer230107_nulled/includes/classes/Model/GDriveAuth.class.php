<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class GDriveAuth extends \GDPlayer\Model { protected $table = "\x74\142\137\x67\x64\x72\151\x76\x65\137\x61\x75\x74\x68"; protected $fields = ["\151\144", "\145\x6d\x61\x69\154", "\141\x70\151\x5f\153\145\171", "\x63\x6c\151\145\x6e\x74\137\x69\x64", "\x63\154\151\x65\x6e\164\x5f\163\x65\143\x72\x65\x74", "\x72\x65\x66\162\145\163\150\x5f\x74\x6f\x6b\145\x6e", "\143\x72\x65\141\x74\145\x64", "\x6d\x6f\x64\151\x66\151\145\x64", "\x75\151\144", "\x73\164\x61\164\165\163"]; protected $primaryKey = "\151\144"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
