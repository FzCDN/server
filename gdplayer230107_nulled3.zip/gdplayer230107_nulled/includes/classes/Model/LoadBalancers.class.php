<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class LoadBalancers extends \GDPlayer\Model { protected $table = "\x74\142\x5f\x6c\157\x61\x64\x62\141\x6c\x61\x6e\143\x65\162\x73"; protected $fields = ["\151\144", "\156\141\x6d\x65", "\154\151\156\153", "\163\164\x61\164\x75\x73", "\x70\165\x62\154\151\143", "\x61\x64\144\145\144", "\165\160\144\141\164\145\144", "\144\x69\x73\141\x6c\154\x6f\x77\x5f\x68\157\163\x74\x73"]; protected $primaryKey = "\151\144"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
