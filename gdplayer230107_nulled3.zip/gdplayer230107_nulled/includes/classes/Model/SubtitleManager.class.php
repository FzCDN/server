<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class SubtitleManager extends \GDPlayer\Model { protected $table = "\164\x62\x5f\163\x75\x62\164\151\x74\x6c\145\137\x6d\141\x6e\141\147\145\162"; protected $fields = ["\151\144", "\x66\x69\154\x65\x5f\x6e\x61\x6d\145", "\x66\151\154\145\137\x73\151\x7a\145", "\x66\151\x6c\x65\137\x74\171\160\x65", "\154\141\156\147\x75\141\x67\145", "\x61\144\144\x65\144", "\x75\x69\x64", "\150\157\163\x74", "\x75\x70\144\x61\x74\145\144"]; protected $primaryKey = "\x69\144"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
