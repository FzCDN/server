<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class VideoShort extends \GDPlayer\Model { protected $table = "\x74\142\x5f\166\x69\x64\145\157\x73\137\x73\x68\x6f\162\164"; protected $fields = ["\151\144", "\153\145\171", "\166\x69\144"]; protected $primaryKey = "\151\x64"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
