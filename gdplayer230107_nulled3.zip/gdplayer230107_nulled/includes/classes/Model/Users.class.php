<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class Users extends \GDPlayer\Model { protected $table = "\x74\x62\137\165\163\145\162\x73"; protected $fields = ["\151\x64", "\165\163\x65\x72", "\x65\x6d\141\151\x6c", "\160\141\x73\163\167\x6f\x72\144", "\x6e\x61\155\x65", "\x73\164\141\164\165\163", "\141\144\x64\145\x64", "\x75\160\x64\x61\164\145\144", "\162\157\154\145"]; protected $primaryKey = "\x69\144"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
