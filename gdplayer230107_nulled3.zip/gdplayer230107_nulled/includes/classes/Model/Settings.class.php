<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class Settings extends \GDPlayer\Model { protected $table = "\164\142\x5f\x73\145\x74\x74\151\156\x67\163"; protected $fields = ["\x69\144", "\x6b\x65\x79", "\x76\x61\x6c\x75\x65", "\165\160\x64\141\164\145\144"]; protected $primaryKey = "\x69\x64"; public function __construct() { session_write_close(); parent::__construct(); } public function reset() { goto dk1ZM4N00x7I6OA; ndSnf3ecLRk8hYh: $this->setCriteria("\x6b\x65\171", '', "\74\x3e"); goto DZtB9QO4_fmhxYC; dk1ZM4N00x7I6OA: session_write_close(); goto ndSnf3ecLRk8hYh; DZtB9QO4_fmhxYC: return $this->delete(); goto e2uw9gM2LJXwl49; e2uw9gM2LJXwl49: } public function __destruct() { session_write_close(); parent::__destruct(); } }
