<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class Subtitles extends \GDPlayer\Model { protected $table = "\x74\142\137\163\x75\x62\164\x69\x74\154\x65\x73"; protected $fields = ["\151\144", "\x6c\141\156\x67\165\141\x67\x65", "\x6c\x69\156\x6b", "\166\x69\x64", "\141\144\144\x65\144", "\165\151\144", "\x6f\162\x64\145\162", "\165\160\144\141\x74\x65\x64"]; protected $primaryKey = "\151\144"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
