<?php
/*
 * @ https://EasyToYou.eu - IonCube v11 Decoder Online
 * @ PHP 7.2 & 7.3
 * @ Decoder version: 1.0.6
 * @ Release: 10/08/2022
 */

namespace GDPlayer;

class Security
{
    private $cipher = "AES-256-CBC";
    private $kunciGaram = "GDPlayer";
    private $otentikasiURL = "https://auth.gdplayer.to/";
    private $beitKodeJS = "%s/ambil-kode-js.php?license=%s&hostname=%s";
    private $kirimKode = "license=%s&hostname=%s";
    private $iCache = NULL;
    public function __construct()
    {
        session_write_close();
        $this->iCache = new InstanceCache();
        $this->kunciGaram .= $this->ambilKunciGaram();
    }
    public function ambilKunciGaram()
    {
        session_write_close();
        return "~F1r3b4Ll";
    }
    public function enableUAFilter()
    {
        session_write_close();
        if (isset($_SERVER["HTTP_USER_AGENT"])) {
            session_write_close();
            $ua = strtolower($_SERVER["HTTP_USER_AGENT"]);
            preg_match("/headlesschrome|httrack|apache-httpclient|harvest|audit|dirbuster|pangolin|nmap|sqln|hydra/", $ua, $match1);
            preg_match("/parser|libwww|bbbike|sqlmap|w3af|owasp|nikto|fimap|havij|zmeu|babykrokodil|netsparker|httperf| sf/", $ua, $match2);
            if (empty($match1[1]) && empty($match2[1])) {
            } else {
                session_write_close();
                error_log("invalid UA detected => " . $_SERVER["HTTP_USER_AGENT"]);
                http_response_code(403);
                exit("Access denied!");
            }
        }
    }
    public function encrypt($plainText = "")
    {
        session_write_close();
        try {
            session_write_close();
            $this->iCache->setKey("encode~" . hash("SHA256", $plainText));
            $cache = $this->iCache->get();
            if ($cache) {
                session_write_close();
                return $cache;
            }
            session_write_close();
            $key = base64_decode($this->kunciGaram . SECURE_SALT);
            $ivlen = openssl_cipher_iv_length($this->cipher);
            $iv = openssl_random_pseudo_bytes($ivlen);
            $ciphertextRaw = @openssl_encrypt($plainText, $this->cipher, $key, OPENSSL_RAW_DATA, $iv);
            $hmac = hash_hmac("sha256", $ciphertextRaw, $key, true);
            if (!(is_string($iv) && is_string($ciphertextRaw) && is_string($hmac))) {
            } else {
                session_write_close();
                $encrypted = base64_encode($iv . $hmac . $ciphertextRaw);
                $this->iCache->save($encrypted, 2592000, "encode");
                return $encrypted;
            }
        } catch (\Exception $e) {
            session_write_close();
            error_log("Security encrypt => " . $e->getMessage());
        }
        return false;
    }
    public function decrypt($encryptedText = "")
    {
        session_write_close();
        try {
            session_write_close();
            $key = base64_decode($this->kunciGaram . SECURE_SALT);
            $c = base64_decode($encryptedText);
            $ivlen = openssl_cipher_iv_length($this->cipher);
            $iv = substr($c, 0, $ivlen);
            $hmac = substr($c, $ivlen, $sha2len = 32);
            $ciphertextRaw = substr($c, $ivlen + $sha2len);
            $originalPlaintext = @openssl_decrypt($ciphertextRaw, $this->cipher, $key, OPENSSL_RAW_DATA, $iv);
            $calcmac = hash_hmac("sha256", $ciphertextRaw, $key, true);
            if (!(is_string($hmac) && is_string($calcmac) && hash_equals($hmac, $calcmac))) {
            } else {
                session_write_close();
                return $originalPlaintext;
            }
        } catch (\Exception $e) {
            session_write_close();
            error_log("Security decrypt => " . $e->getMessage());
        }
        return false;
    }
    public function encryptURL($url = NULL)
    {
        session_write_close();
        return !is_null($url) ? base64url_encode($this->encrypt($url)) : false;
    }
    public function decryptURL($url = NULL)
    {
        session_write_close();
        return !is_null($url) ? $this->decrypt(base64url_decode($url)) : false;
    }
    public function isSmartTv($ua = "")
    {
        session_write_close();
        $ua = empty($ua) && isset($_SERVER["HTTP_USER_AGENT"]) ? $_SERVER["HTTP_USER_AGENT"] : $ua;
        $class = new \WhichBrowser\Parser($ua);
        $model = isset($class->device->model) ? strtr(strtolower($class->device->model), ["-" => "", "_" => ""]) : "";
        preg_match("/seraphic|hbbtv|sraf|crkey|tpm171e|a95x-r1|netbox|mxqpro|tx3|m8s|neo-u1|t95zplus|beelink|abox|p281|hx_3229|v88|mx9|mxiii|zidoo|brightsign/i", $ua, $tv1);
        preg_match("/smart-tv|smart_tv|leelbox|minia5x|x96|mobile vr|directfb|kylo|ppc|telefunken|linux sh4|linux mips|kded|h96|x96mini|freebox|wii|playstation|nintendo|xbox|tv/i", $ua, $tv2);
        return $class->device->type === "television" || $model === "smarttv" || !empty($tv1[1]) || !empty($tv2[1]);
    }
    public function createSmartTvToken()
    {
        session_write_close();
        $result = "";
        if (isset($_SERVER["HTTP_USER_AGENT"])) {
            session_write_close();
            $class = new \WhichBrowser\Parser($_SERVER["HTTP_USER_AGENT"]);
            $result = trim($class->device->manufacturer . "~" . (isset($class->device->series) ? $class->device->series . "~" : "") . (isset($class->os->name) ? $class->os->name . "~" : "") . $class->engine->name);
        }
        return $result;
    }
    public function accessAllowed()
    {
        session_write_close();
        $ip = getUserIP();
        $referer = "";
        if (!empty($_SERVER["HTTP_REFERER"])) {
            session_write_close();
            $referer = $_SERVER["HTTP_REFERER"];
        }
        $allowDomain = is_domain_whitelisted($referer);
        $allowIPAddress = is_ip_whitelisted($ip);
        $disallowDomain = is_domain_blacklisted($referer);
        $disallowIPAddress = is_ip_blacklisted($ip);
        $disallowReferer = is_referer_blacklisted($referer);
        return ($allowDomain || $allowIPAddress) && !$disallowIPAddress && !$disallowDomain && !$disallowReferer;
    }
    public function validasiServer()
    {
        session_write_close();
        $allowed = true;
        $hostname = parse_url(BASE_URL, PHP_URL_HOST);
        
        //$license = get_option("gdplayer_license");
        //$helper = new Helper();
        //$ch = $helper->getCurlDefaultConfig(curl_init());
        //curl_setopt($ch, CURLOPT_URL, $this->otentikasiURL . "validasi.php");
        //curl_setopt($ch, CURLOPT_POST, true);
        //curl_setopt($ch, CURLOPT_POSTFIELDS, sprintf($this->kirimKode, $license, $hostname));
        //$response = curl_exec($ch);
        //$err = curl_error($ch);
        //if (!$err) {
        //    session_write_close();
        //    $arr = @json_decode($response, true);
        //    $allowed = json_last_error() === JSON_ERROR_NONE && is_array($arr) && isset($arr["status"]) && $arr["status"];
            $status = (int) $allowed;
            $lb = new Model\LoadBalancers();
            $lb->setCriteria("link", "https://" . $hostname . "%", "LIKE");
            $lb->setCriteria("link", "http://" . $hostname . "%", "LIKE", "OR");
            $lb->setCriteria("status", 1, "=", "AND");
            $lb->update(["status" => $status]);
        //}
        //curl_close($ch);
        return $allowed;
    }
    public function validasi()
    {
        session_write_close();
        //$helper = new Helper();
        $lb = new Model\LoadBalancers();
        $lb->setCriteria("status", 1);
        $lbList = $lb->get(["link", "id"]);
        if ($lbList) {
            session_write_close();
            //$license = get_option("gdplayer_license");
            //$ch = $helper->getCurlDefaultConfig(curl_init());
            foreach ($lbList as $dt) {
                session_write_close();
                $hostname = parse_url($dt["link"], PHP_URL_HOST);
                //curl_setopt($ch, CURLOPT_URL, $this->otentikasiURL . "validasi.php");
                //curl_setopt($ch, CURLOPT_POST, true);
                //curl_setopt($ch, CURLOPT_POSTFIELDS, "license=" . $license . "&hostname=" . $hostname);
                //$response = curl_exec($ch);
                //$err = curl_error($ch);
                //if ($err) {
                //} else {
                //    session_write_close();
                //    $arr = @json_decode($response, true);
                //    $status = json_last_error() === JSON_ERROR_NONE && is_array($arr) && isset($arr["status"]) && $arr["status"];
                    $status = true;
                    $status = (int) $status;
                    $lb->setCriteria("id", $dt["id"]);
                    $lb->update(["status" => $status]);
                //}
            }
            //curl_close($ch);
        }
    }
    public function kirimData($data = [])
    {
        session_write_close();
        $result = "{}";
        //$license = get_option("gdplayer_license");
        //$hostname = parse_url(BASE_URL, PHP_URL_HOST);
        //$helper = new Helper();
        //$ch = $helper->getCurlDefaultConfig(curl_init());
        //curl_setopt($ch, CURLOPT_URL, sprintf($this->beitKodeJS, rtrim($this->otentikasiURL, "/"), $license, $hostname));
        //curl_setopt($ch, CURLOPT_POST, true);
        //curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data, true));
        //$response = curl_exec($ch);
        //$err = curl_error($ch);
        //curl_close($ch);
        //if (!$err) {
        //    session_write_close();
        //    $arr = @json_decode($response, true);
        //    if (json_last_error() === JSON_ERROR_NONE && is_array($arr) && isset($arr["result"])) {
        //        session_write_close();
        //        $result = (string) $arr["result"];
        //    }
        //}
        $result = json_encode($data, true);
        return $result;
    }
}

?>