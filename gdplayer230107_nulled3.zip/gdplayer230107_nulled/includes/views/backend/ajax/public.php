<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto rMAXacU6HB9r0B1; voEtXI3oFoV_XDs: $class = new \GDPlayer\Ajax\PublicAjax(); goto O3DnSNzJxjA21xp; rMAXacU6HB9r0B1: session_write_close(); goto voEtXI3oFoV_XDs; O3DnSNzJxjA21xp: echo $class->response($_POST);
