<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto CzUvKBukpnDlUjx; RGGwWTE9zew3QnP: $class = new \GDPlayer\Ajax\Sessions(); goto PWI_SEY5C1ls_ne; CzUvKBukpnDlUjx: session_write_close(); goto RGGwWTE9zew3QnP; PWI_SEY5C1ls_ne: echo $class->list($_GET);
