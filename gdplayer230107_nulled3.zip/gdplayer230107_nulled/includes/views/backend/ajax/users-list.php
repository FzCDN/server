<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto atYd3L1DalePndf; atYd3L1DalePndf: session_write_close(); goto wGxOq7vEnQy3N9Q; wGxOq7vEnQy3N9Q: $class = new \GDPlayer\Ajax\Users(); goto Nq9OPIZjJJzS_Hi; Nq9OPIZjJJzS_Hi: echo $class->list($_GET);
