<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto L4kCkkgl3QsEJV2; BnsBahcI2qyaI12: $class = new \GDPlayer\Ajax\GDriveFiles(); goto T5BAnoBjGZGXOoc; L4kCkkgl3QsEJV2: session_write_close(); goto BnsBahcI2qyaI12; T5BAnoBjGZGXOoc: echo $class->list($_GET);
