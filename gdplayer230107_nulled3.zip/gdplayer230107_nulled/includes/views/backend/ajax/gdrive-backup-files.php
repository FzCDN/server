<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto HVOh5hYKxMrWaAO; H2FT2jy2hz2wGkQ: $class = new \GDPlayer\Ajax\GDriveMirrors(); goto uvBp__L1SgqQ5fd; HVOh5hYKxMrWaAO: session_write_close(); goto H2FT2jy2hz2wGkQ; uvBp__L1SgqQ5fd: echo $class->response($_POST);
