<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto j43HSi0xgiixTwa; tNBcPzhXejcsJ7g: $class = new \GDPlayer\Ajax\GDriveAccounts(); goto NnnBwKgW1IR3nx9; j43HSi0xgiixTwa: session_write_close(); goto tNBcPzhXejcsJ7g; NnnBwKgW1IR3nx9: echo $class->response($_POST);
