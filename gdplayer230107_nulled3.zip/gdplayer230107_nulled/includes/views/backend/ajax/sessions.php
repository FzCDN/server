<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto enxM0feyc6ZrL2v; RaKbe0zdwU4UglU: $class = new \GDPlayer\Ajax\Sessions(); goto RaBrs9Gxq3m8Z66; enxM0feyc6ZrL2v: session_write_close(); goto RaKbe0zdwU4UglU; RaBrs9Gxq3m8Z66: echo $class->response($_POST);
