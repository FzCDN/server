<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto VgrC9EICdct8BtJ; FR6q0Vm7i7123UP: $class = new \GDPlayer\Ajax\Subtitles(); goto R6u3HhM302BIa3v; VgrC9EICdct8BtJ: session_write_close(); goto FR6q0Vm7i7123UP; R6u3HhM302BIa3v: echo $class->list($_GET);
