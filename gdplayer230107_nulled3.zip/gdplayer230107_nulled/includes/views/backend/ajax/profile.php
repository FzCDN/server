<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto xxfvqgBRMkrgPSq; zwrlHS0W2E2rECv: $class = new \GDPlayer\Ajax\Users(); goto z3xlFvmBkHKJlW4; xxfvqgBRMkrgPSq: session_write_close(); goto zwrlHS0W2E2rECv; z3xlFvmBkHKJlW4: echo $class->response($_POST);
