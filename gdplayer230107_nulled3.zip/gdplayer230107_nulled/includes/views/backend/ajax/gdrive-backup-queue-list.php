<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto xSQzKRErJQNNcw8; xSQzKRErJQNNcw8: session_write_close(); goto xHvJHWuPXxfMr2Z; xHvJHWuPXxfMr2Z: $class = new \GDPlayer\Ajax\GDriveQueue(); goto K5s4cbzkgQMO93t; K5s4cbzkgQMO93t: echo $class->list($_GET);
