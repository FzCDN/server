<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-01-07 09:41:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto FkxOzIPgYtyk2OM; LAcxLy1EBo0ukx3: echo $html->renderTemplate("\x70\154\x75\x67\x69\x6e\x2d\154\151\x73\x74\x2e\150\164\x6d\154\x2e\x74\x77\x69\x67", ["\x74\151\164\x6c\145" => get_env("\164\151\164\154\145")]); goto FmS9WjBXhhkCECt; V8w5m_8a5t8m0Xt: SsMbHTCU0J35H8O: goto U_NTvw1KEEhQfBK; vJ6swBr0Izuy5nw: session_write_close(); goto aRyqLCYh5us4nn1; Q5bjCqdXPlmln2g: exit; goto V8w5m_8a5t8m0Xt; JI1W4T2ezEmWkMI: session_write_close(); goto JFzDCMrgHCQ4WOU; XbKRMgganbUKbpV: if (defined("\x42\x41\123\x45\x5f\x44\x49\122")) { goto p5ogVxK0ShX8DTU; } goto vJ6swBr0Izuy5nw; aRyqLCYh5us4nn1: die("\x61\x63\x63\145\163\x73\x20\144\145\156\151\x65\144\x21"); goto LLSbEPpEeYZfvCA; JFzDCMrgHCQ4WOU: include ADMIN_PATH . "\57\64\60\x33\56\160\150\160"; goto Q5bjCqdXPlmln2g; FkxOzIPgYtyk2OM: session_write_close(); goto XbKRMgganbUKbpV; XBMwJUY28PINxVa: get_backend_header(); goto w81e2n3jFt3uIbn; U_NTvw1KEEhQfBK: set_env("\164\151\x74\154\x65", "\120\154\165\147\151\156\x20\114\151\x73\x74"); goto XBMwJUY28PINxVa; LLSbEPpEeYZfvCA: p5ogVxK0ShX8DTU: goto VgkzWwFNWkTb7t6; w81e2n3jFt3uIbn: $html = new \GDPlayer\HTML(); goto LAcxLy1EBo0ukx3; VgkzWwFNWkTb7t6: if (is_admin()) { goto SsMbHTCU0J35H8O; } goto JI1W4T2ezEmWkMI; FmS9WjBXhhkCECt: get_backend_footer();
