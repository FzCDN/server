<?php
session_write_close();
header('location: ' . strtr($_SERVER['REQUEST_URI'], ['poster.php' => 'poster/']) . '?' . $_SERVER['QUERY_STRING']);
