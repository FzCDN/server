<?php
session_write_close();
header('location: ' . strtr($_SERVER['REQUEST_URI'], ['embed.php' => 'embed/']) . '?' . $_SERVER['QUERY_STRING']);
