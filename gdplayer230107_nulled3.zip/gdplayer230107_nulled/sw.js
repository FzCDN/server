var CACHE_VERSION = 96;
var CURRENT_CACHES = {
    prefetch: "gdplayer-v" + CACHE_VERSION,
    dynamic: "gdplayer-dynamic-v" + CACHE_VERSION,
};
var assets = [
    "./offline.html",
    "./assets/css/multi-select.dist.css",
    "./assets/css/select2-bootstrap4.min.css",
    "./assets/css/style.css",
    "./assets/css/sweetalert.css",
    "./assets/img/logo/filemoon.png",
    "./assets/img/logo/vk.png",
    "./assets/img/logo/amazon.png",
    "./assets/img/logo/anonfile.png",
    "./assets/img/logo/archive.png",
    "./assets/img/logo/bayfiles.png",
    "./assets/img/logo/blogger.png",
    "./assets/img/logo/dailymotion.png",
    "./assets/img/logo/direct.png",
    "./assets/img/logo/dropbox.png",
    "./assets/img/logo/facebook.png",
    "./assets/img/logo/fembed.png",
    "./assets/img/logo/filecm.png",
    "./assets/img/logo/filerio.png",
    "./assets/img/logo/filesfm.png",
    "./assets/img/logo/filesim.png",
    "./assets/img/logo/fireload.png",
    "./assets/img/logo/gdrive.png",
    "./assets/img/logo/gofile.png",
    "./assets/img/logo/googlephotos.png",
    "./assets/img/logo/hexupload.png",
    "./assets/img/logo/hxfile.png",
    "./assets/img/logo/indishare.png",
    "./assets/img/logo/mediafire.png",
    "./assets/img/logo/mixdropto.png",
    "./assets/img/logo/mp4upload.png",
    "./assets/img/logo/mymailru.png",
    "./assets/img/logo/okru.png",
    "./assets/img/logo/onedrive.png",
    "./assets/img/logo/pandafiles.png",
    "./assets/img/logo/pcloud.png",
    "./assets/img/logo/racaty.png",
    "./assets/img/logo/rumble.png",
    "./assets/img/logo/sendvid.png",
    "./assets/img/logo/sibnet.png",
    "./assets/img/logo/solidfiles.png",
    "./assets/img/logo/soundcloud.png",
    "./assets/img/logo/streamable.png",
    "./assets/img/logo/streamff.png",
    "./assets/img/logo/streamlare.png",
    "./assets/img/logo/streamsb.png",
    "./assets/img/logo/streamtape.png",
    "./assets/img/logo/supervideo.png",
    "./assets/img/logo/tiktok.png",
    "./assets/img/logo/uploadbuzz.png",
    "./assets/img/logo/uploadsmobi.png",
    "./assets/img/logo/upstream.png",
    "./assets/img/logo/uptobox.png",
    "./assets/img/logo/uqload.png",
    "./assets/img/logo/userscloud.png",
    "./assets/img/logo/videobin.png",
    "./assets/img/logo/vidio.png",
    "./assets/img/logo/vidoza.png",
    "./assets/img/logo/vimeo.png",
    "./assets/img/logo/viu.png",
    "./assets/img/logo/voe.png",
    "./assets/img/logo/vudeo.png",
    "./assets/img/logo/vupto.png",
    "./assets/img/logo/yadisk.png",
    "./assets/img/logo/yourupload.png",
    "./assets/img/logo/youtube.png",
    "./assets/img/logo/zippyshare.png",
    "./assets/img/logo/zplayer.png",
    "./assets/img/plyr-custom.svg",
    "./assets/vendor/apexcharts/apexcharts.css",
    "./assets/vendor/apexcharts/apexcharts.min.js",
    "./assets/vendor/bootstrap/css/bootstrap.min.css",
    "./assets/vendor/bootstrap/js/bootstrap.bundle.min.js",
    "./assets/vendor/bs-custom-file-input/bs-custom-file-input.min.js",
    "./assets/vendor/crypto-js/crypto-js.min.js",
    "./assets/vendor/crypto-js/aes.min.js",
    "./assets/vendor/datatables/datatables.min.css",
    "./assets/vendor/datatables/datatables.min.js",
    "./assets/vendor/fontawesome6/css/all.min.css",
    "./assets/vendor/fontawesome6/webfonts/fa-brands-400.woff2",
    "./assets/vendor/fontawesome6/webfonts/fa-solid-900.woff2",
    "./assets/vendor/hls.js/latest/hls.min.js",
    "./assets/vendor/jquery-wheelcolorpicker/css/wheelcolorpicker.css",
    "./assets/vendor/jquery-wheelcolorpicker/jquery.wheelcolorpicker.min.js",
    "./assets/vendor/mux.js/mux.js",
    "./assets/vendor/mux.js/mux.min.js",
    "./assets/vendor/select2/css/select2.min.css",
    "./assets/vendor/select2/js/select2.min.js",
    "./assets/vendor/shaka-player/latest/shaka-player.compiled.js",
    "./assets/vendor/toastify-js/toastify.min.css",
    "./assets/vendor/toastify-js/toastify.min.js",
    "./assets/vendor/jwplayer/jwplayer.8.9.5.js",
    "./assets/vendor/jwplayer/jwplayer.latest.js",
    "./assets/vendor/jquery-ui.min.js",
    "./assets/vendor/jquery.min.js",
    "./assets/vendor/jquery.multi-select.js",
    "./assets/vendor/js.cookie.min.js",
    "./assets/vendor/pwacompat.min.js",
    "./assets/vendor/sweetalert.min.js",
    "./assets/vendor/FormData.js",
    "./assets/vendor/plyr/plyr.css",
    "./assets/js/plyr-custom.polyfilled.js",
    "./assets/js/plyr-custom.polyfilled.min.js",
    "./assets/js/player.js",
    "./assets/js/detect-adblocker.min.js",
    "./assets/js/main.js",
    "./assets/js/md5.js",
];
var enabledCaches = ["script", "style", "font", "manifest", "image"];

self.addEventListener("install", function (e) {
    e.waitUntil(
        caches.open(CURRENT_CACHES.prefetch).then(function (cache) {
            cache.addAll(assets);
        })
    );
});

self.addEventListener("activate", function (e) {
    e.waitUntil(
        caches.keys().then(function (keys) {
            return Promise.all(
                keys
                    .filter(function (key) {
                        return key !== CURRENT_CACHES.prefetch && key !== CURRENT_CACHES.dynamic;
                    })
                    .map(function (key) {
                        return caches.delete(key);
                    })
            );
        })
    );
});

self.addEventListener("fetch", function (e) {
    var dest = e.request.destination;
    if (enabledCaches.indexOf(dest) > -1 && !e.request.redirected) {
        e.respondWith(
            caches
                .match(e.request)
                .then(function (cacheRes) {
                    return (
                        cacheRes ||
                        fetch(e.request).then(function (fetchRes) {
                            if (!fetchRes.redirected && includeURLs(e.request.url) && (fetchRes.status === 200 || fetchRes.status === 0)) {
                                return caches.open(CURRENT_CACHES.dynamic).then(function (cache) {
                                    cache.put(e.request.url, fetchRes.clone());
                                    return fetchRes;
                                });
                            } else {
                                return fetchRes;
                            }
                        })
                    );
                })
                .catch(function () {
                    return caches.match("./offline.html");
                })
        );
    } else {
        return;
    }
});

function includeURLs(url) {
    var host = location.hostname + "/",
        https = "https://" + host,
        http = "http://" + host;
    return url.startsWith(https) || url.startsWith(http);
}
