<?php defined("GOV_APP") || die("!");

Hooks::add_filter("ts-service>>is-busy", function($is_busy){
    return $is_busy;
});

/**
 * getting images from raw HTML
 * @param array $images - array of images
 * @param string $html - raw html
 * @return array
 */
Hooks::add_filter("ts-do-zip>>images", function($images, $html){
    return $images;
});

/**
 * @param string $redirect_url - the redirect url when the user is not logged in, default value is login page
 * @return string
 */
Hooks::add_filter("ts-service>>no-login-redirect", function($redirect_url){
    return $redirect_url;
});

/**
 * use curl_setopt on $curl to set curl options
 */
Hooks::add_filter("ts-curl", function($curl){
    return $curl;
});

/**
 * @param string $prefix - the prefix of item name inside zip file, by default $prefix values is the domain name
 * @return string
 */
Hooks::add_filter("ts-do-zip>>filename-prefix", function($prefix){
    return $prefix;
});

/**
 * @param string $url - the url of json file, by default this contains wp-json url
 * @return string
 */
Hooks::add_filter("ts-do-zip>>json-url", function($url){
    return $url;
});

/**
 * @param array $json - the json array
 * @return array
 */
Hooks::add_filter("ts-do-zip>>json", function($json){
    return $json;
});

/**
 * @param string $tmp_file - the temp file path for zip file
 * @param string $temp_dir - the temp directory path
 * @param string $id - the post id
 * @return string
 */
Hooks::add_filter("ts-do-zip>>tmp-file", function($tmp_file, $temp_dir, $id){
    return $tmp_file;
});

/**
 * @param string $filename - the filename of image
 * @param string $file - the url of image
 * @param string $id - the post id
 * @param int $index - the index of image
 * @return string
 */
Hooks::add_filter("ts-do-zip>>filename", function($filename, $file, $id, $index){
    return $filename;
});

/**
 * @param string $extension - the extension of image
 * @param string $filename - the filename of image
 * @param string $file - the url of image
 * @param string $id - the post id
 * @param int $index - the index of image
 * @return string
 */
Hooks::add_filter("ts-do-zip>>file_extension", function($extension, $filename, $file, $id, $index){
    return $extension;
});

/**
* @param array $allowed_extension - the allowed extension for zip file
*/
Hooks::add_filter("ts-do-zip>>allowed_extension", function($allowed_extension){
    return $allowed_extension;
});

/**
 * want to use old method for upload?
 * @param bool $use_legacy - TRUE to use legacy method, FALSE to use new method
 * @param string $file - the path of file
 * @param int $attributes - file attributes
 * @return bool
 */
Hooks::add_filter("ts-drive>>legacy-upload", function($use_legacy, $file, $attributes){
    return $use_legacy;
});

/**
 * @param string $file - the path of file
 * @param array $attributes - file attributes
 * @return array
 */
Hooks::add_filter("ts-drive>>upload-file-attribute", function($attributes, $file){
    return $attributes;
});

/**
 * @param string $file - the path of file
 * @param array $attributes - file attributes
 * @return string
 */
Hooks::add_filter("ts-drive>>upload-file-path", function($file, $attributes){
    return $file;
});


Hooks::add_filter("ts-drive>>chunk-size", function($chunkSizeBytes, $file, $attributes){
    return $chunkSizeBytes;
});

/**
 * @param array $metadata
 * @return array
 */
Hooks::add_filter("ts-zip>>zip-result-meta-data", function($metadata){
    $metadata['name'] = trim(urldecode($metadata['name']));
    return $metadata;
});