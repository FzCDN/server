<?php 
defined("GOV_APP") || die("!");
define("BASE_URL", "http://localhost/");
//DATABASE
define("DB_NAME", "");
define("DB_USER", "");
define("DB_PASSWORD", "");
define("DB_HOST", "localhost");
