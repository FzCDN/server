<?php defined("GOV_APP") || die("!"); ?>
<?php View::load("header");?>
<table class="w3-table w3-striped w3-bordered">
    <thead>
        <tr>
            <th>POST ID</th>
            <th>Size</th>
            <th>Create</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php if (sizeof($all) < 1) { ?>
            <tr>
                <td>-</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
            </tr>
        <?php } ?>
        <?php foreach($all as $k => $v) { ?>
            <tr>
                <td><a href="<?php echo Config::get('manga_site');?>?p=<?php echo $v['post_id']?>"><?php echo $v['post_id']?></a></td>
                <td><?php echo Service::convert_filesize($v['size']);?></td>
                <td><?php echo $v['created_at'];?></td>
                <td>
                    <a href="https://drive.google.com/open?id=<?php echo $v['drive_id'];?>">Download</a>
                    <a onclick="return confirm('are u sure?');" href="?id=<?php echo $v['id']?>&page=admin/deleteData&token=<?php echo User::getToken(); ?>&drive=<?php echo $v['drive_id'];?>">Delete</a>
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>
<br />
<div class="w3-container" id="pager" style="text-align:center">
    <?php if ($prev !== FALSE) { ?>
    <a class="w3-button w3-black" href="?page=admin/dashboard&offset=<?php echo $prev;?>">Prev</a>
    <?php } else { ?>
        <a class="w3-button w3-black w3-disabled" href="#">Prev</a>
    <?php } ?>
    <?php if ($next !== FALSE) { ?>
    <a class="w3-button w3-black" href="?page=admin/dashboard&offset=<?php echo $next;?>">Next</a>
     <?php } else { ?>
        <a class="w3-button w3-black w3-disabled" href="#">Next</a>
    <?php } ?>
</div>
<?php View::load("footer");?>