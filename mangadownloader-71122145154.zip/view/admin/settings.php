<?php 
View::load("header");
defined("GOV_APP") || die("!");
$current_delay = Config::get('busy_delay');
?>
<form method="POST" class="w3-container" >
    <input type="hidden" name="_token" value="<?php echo Service::tokening('_token', 'setting'); ?>" />
    <p><h2 class="">Settings</h2></p>
    <p>
        <label class=""><b>Site URL</b></label>
        <input class="w3-input w3-border" type="text" name="base_url" value="<?php echo Config::get('base_url'); ?>" />
    </p>
    <p>
        <label class=""><b>WP Site URL</b></label>
        <input class="w3-input w3-border" type="text" name="manga_site" value="<?php echo Config::get('manga_site'); ?>" />
    </p>
    <p>
        <label class=""><b>License Key</b></label>
        <input class="w3-input w3-border" type="text" name="license_key" value="<?php echo Config::get('license_key'); ?>" />
    </p>
    <p>
        <label class=""><b>Task Delay</b></label>
        <select class="w3-select w3-border" name="busy_delay">
            <option value="" disabled selected>Choose max delay</option>
            <option value="0" <?php if ($current_delay == 0) echo 'selected'; ?>>No Delay</option>
            <option value="5" <?php if ($current_delay == 5) echo 'selected'; ?>>5 Seconds</option>
            <option value="10" <?php if ($current_delay == 10) echo 'selected'; ?>>10 Seconds</option>
            <option value="20" <?php if ($current_delay == 20) echo 'selected'; ?>>20 Seconds</option>
            <option value="30" <?php if ($current_delay == 30) echo 'selected'; ?>>30 Seconds</option>
            <option value="60" <?php if ($current_delay == 60) echo 'selected'; ?>>1 Minutes</option>
        </select>
        <span class="description">Select maximum app will wait until a Task done, when set to no delay, all new tasks that requires upload to remote storage will processed immediately, if you select a delay, the app will only process 1 task at a time within the delay duration, after the task done, the delay will be cleared, so if you set 1 Minutes delay but the task is done in 5 seconds, the delay will cleared and the app can process new task. it is recommended to set a delay value, but if you have a blazing fast server you can set to "no delay".</span>
    </p>
    <p>
        <input class="w3-btn w3-black" type="submit" value="Save" />
    </p>
</form>
<?php View::load("footer");?>