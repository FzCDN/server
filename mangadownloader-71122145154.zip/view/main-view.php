<?php defined("GOV_APP") || die("!"); ?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Downloading..</title>
    </head>
    <body>
        <center><img src="<?php echo Config::get('base_url');?>/assets/loading.gif"/></center>
        <script>
            window.location.replace('?id=<?php echo $id;?>&continue=1');
        </script>
    </body>
</html>