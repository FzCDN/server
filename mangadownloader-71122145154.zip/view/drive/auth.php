<?php defined("GOV_APP") || die("!"); ?>
<?php View::load("header");?>

<div class="w3-center" id="google-sign-in">
	<p>Sign in with your google account to start using the app</p>
	<a href="<?=$authUrl?>" target="_blank"><img id="google-sign-in-btn" src="<?php echo Config::get('base_url'); ?>/assets/google/btn_google_signin_dark_normal_web@2x.png" /></a>
</div>
<div class="w3-center">
	<a class="w-button" href="https://themesia.com/terms-of-service/" target="_blank">Term of Service</a> |
	<a class="w-button" href="https://themesia.com/privacy-policy/" target="_blank">Privacy Policy</a>
</div>

<script>
	let lgn_btn_href = "<?php echo Config::get('base_url'); ?>/assets/google/";
	let lgn_btn = document.querySelector('#google-sign-in-btn');
	lgn_btn.addEventListener('mouseenter', function(e){
		e.preventDefault();
		this.src = lgn_btn_href + 'btn_google_signin_dark_focus_web@2x.png';
	});
	lgn_btn.addEventListener('mouseout', function(e){
		e.preventDefault();
		this.src = lgn_btn_href + 'btn_google_signin_dark_normal_web@2x.png';
	});
</script>
