<?php defined("GOV_APP") || die("!"); ?>
<?php View::load("header");?>
<div class="w3-panel w3-red">
  <h3>Error!</h3>
  <p><?php echo $error_msg; ?></p>
</div> 
<?php View::load("footer");?>