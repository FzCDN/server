<?php 
defined("GOV_APP") || die("!");
$me = Drive::getMe();
?>
<?php View::load("header");?>
<table>
    <tr>
        <td>Name</td>
        <td>:</td>
        <td><?php echo $me['user']['displayName'];?></td>
    </tr>
    <tr>
        <td>Email</td>
        <td>:</td>
        <td><?php echo $me['user']['emailAddress']; ?></td>
    </tr>
    <tr>
        <td>Total Storage</td>
        <td>:</td>
        <td><?php echo isset($me['storageQuota']['limit'])?Service::convert_filesize($me['storageQuota']['limit']):"Unlimited"; ?></td>
    </tr>
    <tr>
        <td>Used Storage</td>
        <td>:</td>
        <td><?php echo Service::convert_filesize($me['storageQuota']['usage']); ?></td>
    </tr>
    <tr>
        <td>Trashed</td>
        <td>:</td>
        <td><?php echo Service::convert_filesize($me['storageQuota']['usageInDriveTrash']); ?></td>
    </tr>
    <tr>
        <td>Disconnect</td>
        <td>:</td>
        <td><a href="?page=drive/disconnect&token=<?php echo User::getToken(); ?>">Click here to disconnect your google drive account</a></td>
    </tr>
</table>
<?php View::load("footer");?>