import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const downloads = pgTable("downloads", {
  id: serial("id").primaryKey(),
  mangaId: text("manga_id").notNull(),
  mangaTitle: text("manga_title").notNull(),
  chapters: jsonb("chapters").notNull().$type<string[]>(),
  status: text("status").notNull().default("pending"), // pending, processing, completed, failed
  progress: integer("progress").notNull().default(0),
  currentChapter: text("current_chapter"),
  zipFileName: text("zip_file_name"),
  downloadUrl: text("download_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertDownloadSchema = createInsertSchema(downloads).pick({
  mangaId: true,
  mangaTitle: true,
  chapters: true,
});

export type InsertDownload = z.infer<typeof insertDownloadSchema>;
export type Download = typeof downloads.$inferSelect;

// API response types
export const searchResponseSchema = z.object({
  query: z.string(),
  pagination: z.object({
    currentPage: z.number(),
    previousPage: z.number().nullable(),
    nextPage: z.number().nullable(),
    totalPages: z.number(),
  }),
  mangaList: z.array(z.object({
    id: z.string(),
    title: z.string(),
    url: z.string(),
    imageUrl: z.string(),
    imageAlt: z.string(),
    rating: z.string(),
    status: z.string(),
    type: z.string(),
    chapter: z.string(),
  })),
});

export const mangaDetailSchema = z.object({
  id: z.string(),
  title: z.string(),
  imageUrl: z.string(),
  rating: z.string(),
  status: z.string(),
  type: z.string(),
  releaseYear: z.string(),
  author: z.string(),
  artist: z.string(),
  postedBy: z.string(),
  postedOn: z.string(),
  updatedOn: z.string(),
  synopsis: z.string(),
  genres: z.array(z.string()),
  chapters: z.array(z.object({
    number: z.string(),
    title: z.string(),
    url: z.string(),
    date: z.string(),
    chapterId: z.string(),
  })),
});

export const chapterDetailSchema = z.object({
  chapterId: z.string(),
  prev: z.string().nullable(),
  next: z.string().nullable(),
  title: z.string(),
  image: z.string(),
  sources: z.array(z.object({
    source: z.string(),
    images: z.array(z.string()),
  })),
});

export type SearchResponse = z.infer<typeof searchResponseSchema>;
export type MangaDetail = z.infer<typeof mangaDetailSchema>;
export type ChapterDetail = z.infer<typeof chapterDetailSchema>;
