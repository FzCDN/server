import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { X, Loader2, CheckCircle, Clock, Download } from "lucide-react";
import { Download as DownloadType } from "@/../../shared/schema";

interface DownloadProgressProps {
  downloadId: number;
  onComplete: (completedDownloadId: number) => void;
  onCancel: () => void;
}

export default function DownloadProgress({ downloadId, onComplete, onCancel }: DownloadProgressProps) {
  const { data: download, isLoading } = useQuery<DownloadType>({
    queryKey: ["/api/download", downloadId],
    refetchInterval: (data) => data?.status === "completed" ? false : 1000,
  });

  const handleCancel = () => {
    onCancel();
  };

  if (download?.status === "completed") {
    setTimeout(() => onComplete(downloadId), 500);
    return null;
  }

  if (isLoading || !download) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg shadow-2xl max-w-md w-full mx-4">
          <div className="p-6 text-center">
            <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
            <p>Loading download status...</p>
          </div>
        </div>
      </div>
    );
  }

  const totalChapters = download.chapters.length;
  const completedChapters = Math.floor((download.progress / 100) * totalChapters);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 animate-fade-in">
      <div className="bg-white rounded-lg shadow-2xl max-w-lg w-full mx-4 max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-gray-900">Download Progress</h3>
            <Button 
              variant="destructive"
              size="sm"
              onClick={handleCancel}
              disabled={download.status === "completed"}
            >
              <X className="mr-2" size={16} />
              Cancel
            </Button>
          </div>

          {/* Manga Info */}
          <div className="mb-6">
            <h4 className="font-semibold text-gray-900 mb-2">{download.mangaTitle}</h4>
            <p className="text-sm text-gray-600">{totalChapters} chapters selected</p>
          </div>

          {/* Overall Progress */}
          <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-700">Overall Progress</span>
              <span className="text-sm text-gray-600">{download.progress}%</span>
            </div>
            <Progress value={download.progress} className="h-3" />
          </div>

          {/* Status Badge */}
          <div className="mb-6">
            <Badge 
              variant={download.status === "completed" ? "default" : "secondary"}
              className="text-sm"
            >
              {download.status === "processing" ? "Processing..." : 
               download.status === "completed" ? "Completed" : 
               download.status === "error" ? "Error" : "Pending"}
            </Badge>
          </div>

          {/* Processing Steps */}
          <div className="space-y-3 mb-6">
            <h5 className="font-medium text-gray-900">Processing Steps</h5>
            
            {/* Step 1: Fetch Images */}
            <div className={`flex items-center space-x-3 p-3 rounded-lg ${
              download.progress > 20 ? "bg-green-100" : download.progress > 0 ? "bg-blue-100" : "bg-gray-100"
            }`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                download.progress > 20 ? "bg-green-500" : download.progress > 0 ? "bg-blue-500" : "bg-gray-300"
              }`}>
                {download.progress > 20 ? (
                  <CheckCircle className="text-white" size={16} />
                ) : download.progress > 0 ? (
                  <Loader2 className="text-white animate-spin" size={16} />
                ) : (
                  <Clock className="text-gray-500" size={16} />
                )}
              </div>
              <div>
                <p className="text-sm font-medium text-gray-900">Fetching Images</p>
                <p className="text-xs text-gray-600">
                  {download.progress > 20 ? "Completed" : download.progress > 0 ? "In Progress" : "Pending"}
                </p>
              </div>
            </div>

            {/* Step 2: Convert to JPEG */}
            <div className={`flex items-center space-x-3 p-3 rounded-lg ${
              download.progress > 50 ? "bg-green-100" : download.progress > 20 ? "bg-blue-100" : "bg-gray-100"
            }`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                download.progress > 50 ? "bg-green-500" : download.progress > 20 ? "bg-blue-500" : "bg-gray-300"
              }`}>
                {download.progress > 50 ? (
                  <CheckCircle className="text-white" size={16} />
                ) : download.progress > 20 ? (
                  <Loader2 className="text-white animate-spin" size={16} />
                ) : (
                  <Clock className="text-gray-500" size={16} />
                )}
              </div>
              <div>
                <p className="text-sm font-medium text-gray-900">Converting to JPEG</p>
                <p className="text-xs text-gray-600">
                  {download.progress > 50 ? "Completed" : download.progress > 20 ? "In Progress" : "Pending"}
                </p>
              </div>
            </div>

            {/* Step 3: Generate PDF */}
            <div className={`flex items-center space-x-3 p-3 rounded-lg ${
              download.progress > 80 ? "bg-green-100" : download.progress > 50 ? "bg-blue-100" : "bg-gray-100"
            }`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                download.progress > 80 ? "bg-green-500" : download.progress > 50 ? "bg-blue-500" : "bg-gray-300"
              }`}>
                {download.progress > 80 ? (
                  <CheckCircle className="text-white" size={16} />
                ) : download.progress > 50 ? (
                  <Loader2 className="text-white animate-spin" size={16} />
                ) : (
                  <Clock className="text-gray-500" size={16} />
                )}
              </div>
              <div>
                <p className="text-sm font-medium text-gray-900">Generating PDF</p>
                <p className="text-xs text-gray-600">
                  {download.progress > 80 ? "Completed" : download.progress > 50 ? "In Progress" : "Pending"}
                </p>
              </div>
            </div>

            {/* Step 4: Creating ZIP */}
            <div className={`flex items-center space-x-3 p-3 rounded-lg ${
              download.progress >= 100 ? "bg-green-100" : download.progress > 80 ? "bg-blue-100" : "bg-gray-100"
            }`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                download.progress >= 100 ? "bg-green-500" : download.progress > 80 ? "bg-blue-500" : "bg-gray-300"
              }`}>
                {download.progress >= 100 ? (
                  <CheckCircle className="text-white" size={16} />
                ) : download.progress > 80 ? (
                  <Loader2 className="text-white animate-spin" size={16} />
                ) : (
                  <Clock className="text-gray-500" size={16} />
                )}
              </div>
              <div>
                <p className="text-sm font-medium text-gray-900">Creating ZIP File</p>
                <p className="text-xs text-gray-600">
                  {download.progress >= 100 ? "Completed" : download.progress > 80 ? "In Progress" : "Pending"}
                </p>
              </div>
            </div>
          </div>

          {/* Chapter Progress Indicators */}
          {totalChapters > 1 && (
            <div className="mb-4">
              <h5 className="font-medium text-gray-900 mb-3">Chapter Progress</h5>
              <div className="grid grid-cols-5 gap-2">
                {Array.from({ length: totalChapters }, (_, i) => {
                  const chapterNum = i + 1;
                  const isCompleted = i < completedChapters;
                  const isCurrent = i === completedChapters && download.status === "processing";
                  
                  return (
                    <div
                      key={i}
                      className={`text-xs px-2 py-1 rounded text-center font-medium ${
                        isCompleted 
                          ? "bg-green-500 text-white" 
                          : isCurrent 
                          ? "bg-blue-500 text-white animate-pulse" 
                          : "bg-gray-200 text-gray-600"
                      }`}
                    >
                      {isCompleted ? "✓" : isCurrent ? "⏳" : ""} Ch {chapterNum}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Current Status */}
          <div className="text-center">
            <p className="text-sm text-gray-600">
              {download.status === "processing" && download.progress < 20 && "Fetching chapter images..."}
              {download.status === "processing" && download.progress >= 20 && download.progress < 50 && "Converting images to JPEG format..."}
              {download.status === "processing" && download.progress >= 50 && download.progress < 80 && "Generating PDF files..."}
              {download.status === "processing" && download.progress >= 80 && download.progress < 100 && "Creating ZIP archive..."}
              {download.status === "processing" && download.progress >= 100 && "Finalizing download..."}
              {download.status === "completed" && "Download completed successfully!"}
              {download.status === "error" && "An error occurred during processing."}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}