import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { X, Loader2, Download, CheckCircle } from "lucide-react";

interface DownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  mangaTitle: string;
  chapterCount: number;
  currentStep: string;
  progress: number;
  isCompleted: boolean;
  downloadUrl?: string | null;
  chapterStatuses: {[key: string]: 'pending' | 'processing' | 'ok'};
  selectedChapters: string[];
}

export default function DownloadModal({ 
  isOpen, 
  onClose, 
  mangaTitle, 
  chapterCount, 
  currentStep, 
  progress, 
  isCompleted,
  downloadUrl,
  chapterStatuses,
  selectedChapters
}: DownloadModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 animate-fade-in">
      <div className="bg-white rounded-lg shadow-2xl max-w-md w-full mx-4">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-gray-900">
              {isCompleted ? "Download Complete!" : "Processing Download"}
            </h3>
            <Button 
              variant="outline"
              size="sm"
              onClick={onClose}
              disabled={!isCompleted}
            >
              <X className="mr-2" size={16} />
              {isCompleted ? "Close" : "Processing..."}
            </Button>
          </div>

          {/* Manga Info */}
          <div className="mb-6">
            <h4 className="font-semibold text-gray-900 mb-2">{mangaTitle}</h4>
            <p className="text-sm text-gray-600">Processing {chapterCount} chapters...</p>
          </div>

          {/* Chapter Progress List */}
          <div className="mb-6">
            <div className="space-y-2 max-h-64 overflow-y-auto bg-gray-50 p-4 rounded-lg">
              {selectedChapters.slice().reverse().map((chapterId, index) => {
                const chapterNumber = selectedChapters.length - index;
                const status = chapterStatuses[chapterId] || 'pending';
                
                return (
                  <div key={chapterId} className="flex items-center justify-between py-2 px-2 bg-white rounded border">
                    <span className="text-sm font-medium">Chapter {chapterNumber}</span>
                    <div className="flex items-center gap-2">
                      {status === 'pending' && (
                        <span className="text-xs text-gray-500">Waiting...</span>
                      )}
                      {status === 'processing' && (
                        <>
                          <Loader2 className="animate-spin" size={14} />
                          <span className="text-xs text-blue-600">Processing<span className="animate-pulse">...</span></span>
                        </>
                      )}
                      {status === 'ok' && (
                        <>
                          <CheckCircle className="text-green-600" size={14} />
                          <span className="text-xs text-green-600 font-medium">OK</span>
                        </>
                      )}
                    </div>
                  </div>
                );
              })}
              
              {currentStep === "Creating ZIP archive..." && (
                <div className="border-t border-gray-200 mt-3 space-y-2">
                  <div className="flex items-center justify-center gap-2 py-3 bg-blue-50 rounded">
                    <Loader2 className="animate-spin" size={16} />
                    <span className="text-sm text-blue-600 font-medium">Creating ZIP archive...</span>
                  </div>
                  <div className="bg-yellow-50 border border-yellow-200 rounded p-3">
                    <p className="text-sm text-yellow-800 font-medium text-center">
                      ⚠️ Jangan Tutup Halaman ini sampai muncul tombol download
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {isCompleted && (
            <div className="text-center space-y-3">
              <Button 
                onClick={() => {
                  if (downloadUrl) {
                    // Trigger download using the provided URL
                    const link = document.createElement('a');
                    link.href = downloadUrl;
                    link.download = `${mangaTitle.replace(/[<>:"/\\|?*]/g, '_')}.zip`;
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    console.log('ZIP download triggered:', downloadUrl);
                  }
                }}
                disabled={!downloadUrl}
                className="w-full bg-green-600 hover:bg-green-700 text-white disabled:bg-gray-400"
              >
                <Download className="mr-2" size={16} />
                Download ZIP File
              </Button>
              <p className="text-xs text-gray-500">
                Click button above to download your ZIP file
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}