import { Book, Wifi } from "lucide-react";

interface NavigationHeaderProps {
  onHomeClick?: () => void;
}

export default function NavigationHeader({ onHomeClick }: NavigationHeaderProps) {
  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <button 
            onClick={onHomeClick}
            className="flex items-center space-x-3 hover:opacity-80 transition-opacity cursor-pointer"
          >
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Book className="text-white text-sm" size={16} />
            </div>
            <h1 className="text-xl font-semibold text-gray-900">Manga Downloader</h1>
          </button>
          <div className="flex items-center space-x-4">
            <div className="hidden md:flex items-center space-x-2 text-sm text-gray-600">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <Wifi size={14} />
              <span>API Connected</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
