<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto lhDzl2cnG4fCutQZ; lhDzl2cnG4fCutQZ: session_write_close(); goto y1_w4v7XiAsVQ1nL; y1_w4v7XiAsVQ1nL: $stream = new \GDPlayer\StreamMaster(true, false); goto QPYl8XOCNguR81Ky; QPYl8XOCNguR81Ky: $stream->load();
