<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto zwuIjvDnyGlt5JmP; iJYPRROcKaEZFXUZ: goto wmy5Gze7tn62b9nG; goto Li7vV_YmMQWT1SSF; zwuIjvDnyGlt5JmP: session_write_close(); goto ljrqBlo3jefYnLeE; a6J3jk4ml1t3aCRU: echo $class->notValid(); goto iJYPRROcKaEZFXUZ; rFzkHm2eQlELYtYU: session_write_close(); goto a6J3jk4ml1t3aCRU; GJ7mkP1LvVUvL_Am: echo $class->response($_POST); goto TjltBKC6ZhUvvjoB; p2lLbfjvV2RqTkC9: disableCorsPolicy(); goto YiGqc3Ua7zoylKve; Li7vV_YmMQWT1SSF: brnu26DrnNl3eV72: goto BTLcmiiTOKLV7Zy8; ljrqBlo3jefYnLeE: header("\x43\x61\143\150\x65\55\103\157\156\x74\x72\157\x6c\x3a\40\156\x6f\x2d\x63\141\x63\150\x65\x2c\40\x6d\x61\x78\55\141\x67\x65\75\x30"); goto p2lLbfjvV2RqTkC9; YiGqc3Ua7zoylKve: $class = new \GDPlayer\Ajax\PrivateAjax(); goto LpyHTSsOdBIGW4fc; BTLcmiiTOKLV7Zy8: session_write_close(); goto GJ7mkP1LvVUvL_Am; LpyHTSsOdBIGW4fc: if (isset($_POST["\x61\143\164\x69\x6f\156"])) { goto brnu26DrnNl3eV72; } goto rFzkHm2eQlELYtYU; TjltBKC6ZhUvvjoB: wmy5Gze7tn62b9nG:
