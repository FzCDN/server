<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto bg1TiLRxqk0xqr1E; fthQR8wk1WlAuiHA: $stream = new \GDPlayer\StreamMaster(false, false); goto qmXJTz71RE72zeVh; bg1TiLRxqk0xqr1E: session_write_close(); goto fthQR8wk1WlAuiHA; qmXJTz71RE72zeVh: $stream->load(true);
