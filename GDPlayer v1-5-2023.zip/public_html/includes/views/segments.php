<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto wQ5Yp8Zogk1v_x5M; Jssq0WgAhB56HNq5: $stream = new \GDPlayer\StreamMaster(false, true); goto gyiv2cb27redX588; wQ5Yp8Zogk1v_x5M: session_write_close(); goto Jssq0WgAhB56HNq5; gyiv2cb27redX588: $stream->load();
