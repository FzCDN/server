<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto Oq3rTv3CWFLX0w0W; Oq3rTv3CWFLX0w0W: session_write_close(); goto EgYRvAP3WsM2EpVk; EgYRvAP3WsM2EpVk: $stream = new \GDPlayer\StreamMaster(false, false); goto xDdfN2z1C238qyI8; xDdfN2z1C238qyI8: $stream->load();
