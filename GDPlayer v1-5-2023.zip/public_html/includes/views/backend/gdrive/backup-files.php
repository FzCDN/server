<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto es2t2WHNh5IY8YbU; HpevM58srhASkelF: exit; goto BsLI4bwAKrMuvw7p; ya2bTy3vFSdB0Zul: set_env("\164\151\x74\154\x65", "\x47\x6f\x6f\147\x6c\145\40\x44\x72\x69\x76\145\x20\102\141\143\x6b\x75\160\40\x46\x69\154\145\40\114\151\x73\x74"); goto SvlmuIEZZfX_O1Sy; iomfgvtMa4iB5N0_: session_write_close(); goto VhakDlEG_pz6PdUM; D_1o5p6PDBsVp_WE: $html = new \GDPlayer\HTML(); goto qUI2apOzIEf5jugP; VhakDlEG_pz6PdUM: include ADMIN_PATH . "\x2f\x34\60\x33\56\160\x68\160"; goto HpevM58srhASkelF; BsLI4bwAKrMuvw7p: dWOyP90HLRk_VpRj: goto ya2bTy3vFSdB0Zul; TMrStqd2wHDdCsIt: if (is_admin()) { goto dWOyP90HLRk_VpRj; } goto iomfgvtMa4iB5N0_; es2t2WHNh5IY8YbU: session_write_close(); goto TMrStqd2wHDdCsIt; qUI2apOzIEf5jugP: echo $html->renderTemplate("\x67\144\162\x69\x76\145\55\x62\141\x63\153\165\160\55\146\x69\x6c\145\163\x2e\150\164\155\154\56\x74\167\x69\x67", ["\164\x69\x74\154\145" => get_env("\164\151\x74\x6c\x65")]); goto ngv_ynHl2wMm_U4R; SvlmuIEZZfX_O1Sy: get_backend_header(); goto D_1o5p6PDBsVp_WE; ngv_ynHl2wMm_U4R: get_backend_footer();
