<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto tnlGU9urQpJmITEz; gqK46QCuEy0upL0I: include ADMIN_PATH . "\x2f\x34\60\x33\56\x70\x68\160"; goto khP4QA4krqK9CrqK; FEFvjq_Wg7ArYV6d: if (is_admin()) { goto qIFTCiFo6i8hkMDu; } goto ieVb_EO4pVsJZDsm; Lk34jbyE39_XoW4_: qIFTCiFo6i8hkMDu: goto VYEypoUhYygrn8y_; tnlGU9urQpJmITEz: session_write_close(); goto FEFvjq_Wg7ArYV6d; p85iEaR0ApSuz7tm: $html = new \GDPlayer\HTML(); goto Yy6B74GT98Ss1Fuz; FIaaQq3mynqa2SYg: get_backend_header(); goto p85iEaR0ApSuz7tm; Yy6B74GT98Ss1Fuz: echo $html->renderTemplate("\147\144\162\151\166\x65\x2d\141\143\143\x6f\x75\x6e\x74\x2d\154\x69\x73\x74\x2e\150\x74\x6d\154\56\x74\x77\x69\147", ["\x74\151\164\154\x65" => get_env("\x74\151\164\x6c\145"), "\x61\144\155\x69\x6e\137\x64\x69\162" => ADMIN_DIR]); goto f4ziCCYBPAKeCy4C; VYEypoUhYygrn8y_: set_env("\x74\x69\x74\x6c\145", "\x47\x6f\157\147\154\145\x20\x44\x72\151\166\145\x20\101\143\143\x6f\165\x6e\164\x73"); goto FIaaQq3mynqa2SYg; khP4QA4krqK9CrqK: exit; goto Lk34jbyE39_XoW4_; ieVb_EO4pVsJZDsm: session_write_close(); goto gqK46QCuEy0upL0I; f4ziCCYBPAKeCy4C: get_backend_footer();
