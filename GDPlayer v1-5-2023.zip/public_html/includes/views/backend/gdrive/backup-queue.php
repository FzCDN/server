<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto mRzk1pvFYFbPXwtc; FgTwH90Lg6G_00xS: get_backend_header(); goto PaLZHO3MroMHlGMi; k3sjrSGFrqGFxkja: session_write_close(); goto BRaNl8n0MjyYtmAv; uyoIFHloFx7ORyrU: if (is_admin()) { goto XZOFVviiUeyj_Pkf; } goto k3sjrSGFrqGFxkja; BRaNl8n0MjyYtmAv: include ADMIN_PATH . "\x2f\64\60\63\x2e\x70\x68\160"; goto ZUqi1NlEcmCEyszf; bHRcMu5HF8k5tJDe: XZOFVviiUeyj_Pkf: goto I611gDZhJeKlt7Wh; PaLZHO3MroMHlGMi: $html = new \GDPlayer\HTML(); goto gtJnNY6ncGjaKr9Y; I611gDZhJeKlt7Wh: set_env("\164\151\x74\x6c\145", "\107\x6f\x6f\147\154\145\x20\x44\x72\x69\x76\x65\x20\x42\141\143\153\165\160\x20\121\x75\x65\x75\x65\40\114\x69\163\164"); goto FgTwH90Lg6G_00xS; mRzk1pvFYFbPXwtc: session_write_close(); goto uyoIFHloFx7ORyrU; ZUqi1NlEcmCEyszf: exit; goto bHRcMu5HF8k5tJDe; gtJnNY6ncGjaKr9Y: echo $html->renderTemplate("\147\x64\x72\x69\166\145\55\x62\x61\x63\153\x75\x70\x2d\161\165\145\165\145\56\x68\164\155\x6c\56\x74\167\x69\147", ["\164\x69\x74\154\145" => get_env("\164\x69\164\x6c\x65")]); goto dLxdf1OJPGis1m28; dLxdf1OJPGis1m28: get_backend_footer();
