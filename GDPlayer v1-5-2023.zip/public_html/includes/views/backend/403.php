<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto rV9TxQ7jD1jEu1k2; rV9TxQ7jD1jEu1k2: session_write_close(); goto nMMpMMnXvkmbXD8A; DkURK2s7zV4lqlb0: echo get_env("\x74\151\x74\154\x65"); goto Q9JJm8jRfP2CpszA; nMMpMMnXvkmbXD8A: set_env("\164\151\x74\154\145", "\64\x30\x33\40\106\x6f\x72\142\151\144\x64\145\156"); goto E_LmsEpaTpmApD6O; YVZUCPXQJ0G6DKGO: echo "\74\144\x69\166\x20\x63\154\141\163\x73\x3d\42\x72\x6f\x77\x22\76\15\12\40\x20\40\x20\x3c\144\x69\x76\40\x63\x6c\x61\x73\163\75\42\x63\157\154\55\61\62\40\164\145\x78\164\x2d\143\x65\x6e\x74\x65\x72\42\76\xd\xa\40\x20\x20\x20\x20\x20\40\40\74\x68\61\x20\143\x6c\x61\163\x73\x3d\x22\150\x33\40\164\145\x78\164\x2d\144\x61\x6e\147\145\x72\42\76"; goto DkURK2s7zV4lqlb0; E_LmsEpaTpmApD6O: get_backend_header(); goto YVZUCPXQJ0G6DKGO; Q9JJm8jRfP2CpszA: echo "\74\x2f\150\x31\76\15\12\40\x20\x20\x20\40\x20\40\40\74\150\x33\40\143\x6c\x61\x73\x73\x3d\42\x68\64\x20\x74\x65\170\x74\x2d\163\x65\143\x6f\156\144\141\x72\x79\x22\76\131\157\x75\40\x61\162\x65\x20\x6e\x6f\164\x20\141\x6c\154\157\167\x65\x64\x20\x74\x6f\40\141\x63\x63\x65\x73\163\40\164\x68\145\x20\160\x61\147\145\56\x3c\x2f\x68\63\x3e\xd\12\40\40\40\x20\74\57\x64\151\x76\76\15\12\74\x2f\144\x69\x76\76\xd\12"; goto fqrpIk33k2IAM1Jf; fqrpIk33k2IAM1Jf: get_backend_footer();
