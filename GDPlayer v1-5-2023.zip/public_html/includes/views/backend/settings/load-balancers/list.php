<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto eV6j0Lh1ZcrrU9sA; auy_aGuQzU0tP2R0: JGcTx_yvgpcRpawB: goto E6ZCIh07IUhdz9T1; cIdT5UsPk8YYLx4o: echo $html->renderTemplate("\154\157\x61\x64\x2d\x62\141\154\141\156\143\x65\162\55\154\x69\x73\x74\x2e\150\x74\x6d\x6c\56\x74\167\x69\x67", ["\164\151\x74\154\x65" => get_env("\164\151\x74\x6c\x65"), "\141\x64\155\x69\x6e\x5f\144\x69\162" => ADMIN_DIR]); goto lbBwWgKg7TM2n6iy; eV6j0Lh1ZcrrU9sA: session_write_close(); goto Wp6PHGrq5V0LkuDK; aiTEelDFJVwvpEPN: $html = new \GDPlayer\HTML(); goto cIdT5UsPk8YYLx4o; xJoUTWS1cMr4Dybn: exit; goto auy_aGuQzU0tP2R0; yp3QaoBKlXvU9sBi: session_write_close(); goto YVEG5H6yfkLN3SGe; Wp6PHGrq5V0LkuDK: if (is_admin()) { goto JGcTx_yvgpcRpawB; } goto yp3QaoBKlXvU9sBi; E6ZCIh07IUhdz9T1: set_env("\x74\x69\164\154\145", "\114\x6f\x61\144\40\x42\141\154\141\x6e\143\145\162\x20\x53\x65\x72\x76\145\162\163"); goto TkzTtXKGC09MQ9id; YVEG5H6yfkLN3SGe: include ADMIN_PATH . "\x2f\64\60\63\x2e\160\x68\160"; goto xJoUTWS1cMr4Dybn; TkzTtXKGC09MQ9id: get_backend_header(); goto aiTEelDFJVwvpEPN; lbBwWgKg7TM2n6iy: get_backend_footer();
