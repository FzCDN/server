<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto n1gvUVmskmVc5Yhb; dXcjIg3dzoMlQ8ol: get_backend_header(); goto x3JuzrDF36GFi0Dg; aMeNZRxrppukigeM: set_env("\164\151\164\154\145", "\120\x6c\165\x67\x69\156\40\x4c\151\x73\x74"); goto dXcjIg3dzoMlQ8ol; n1gvUVmskmVc5Yhb: session_write_close(); goto ZI68AnNjRuhrrv5Q; tSgOBxPfRKr7U3PD: DEcJz91hc7UwZCLK: goto aMeNZRxrppukigeM; D03Gh2ZI88ez9EBO: session_write_close(); goto wOh0bTnq0dKeHBQm; x3JuzrDF36GFi0Dg: $html = new \GDPlayer\HTML(); goto BrQv2ilFkU7bj05q; mYzl7eulGci61XHE: exit; goto tSgOBxPfRKr7U3PD; BrQv2ilFkU7bj05q: echo $html->renderTemplate("\160\x6c\x75\147\x69\x6e\55\154\151\x73\x74\56\150\164\155\x6c\56\x74\x77\x69\x67", ["\164\x69\x74\x6c\x65" => get_env("\164\x69\164\x6c\145")]); goto fOOP6ntobSaT044n; wOh0bTnq0dKeHBQm: include ADMIN_PATH . "\57\64\60\63\x2e\160\x68\160"; goto mYzl7eulGci61XHE; ZI68AnNjRuhrrv5Q: if (is_admin()) { goto DEcJz91hc7UwZCLK; } goto D03Gh2ZI88ez9EBO; fOOP6ntobSaT044n: get_backend_footer();
