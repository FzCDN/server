<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto hcvyoeSJiI_aioQv; TirrB9J8nOYYQAPF: echo "\74\144\x69\166\x20\143\x6c\x61\163\163\x3d\42\162\x6f\x77\42\x3e\15\xa\x20\x20\x20\x20\x3c\x64\x69\x76\40\143\x6c\141\x73\x73\x3d\42\x63\157\x6c\55\61\x32\x20\x74\x65\x78\x74\x2d\143\x65\x6e\164\145\x72\x22\76\15\xa\40\x20\x20\x20\x20\x20\x20\40\x3c\x68\61\40\x63\154\x61\x73\163\75\42\150\63\x20\x74\x65\x78\x74\x2d\144\x61\x6e\x67\145\x72\42\x3e"; goto YErtX2bTcpPKgiid; Z4XQ1ErfTcRcrpEC: set_env("\164\151\x74\x6c\x65", "\x34\60\64\40\x4e\x6f\x74\x20\x46\x6f\x75\156\x64"); goto U2sAlH30QuGS7xtY; Ld3al0LmEoR2g_Gn: echo "\74\57\x68\61\x3e\15\12\40\40\x20\x20\40\40\x20\40\x3c\150\x33\x20\x63\x6c\x61\163\x73\x3d\x22\150\64\x20\x74\145\x78\x74\x2d\x73\145\x63\x6f\x6e\144\141\162\171\x22\x3e\x54\150\x65\x20\x70\141\147\x65\x20\171\x6f\x75\40\x61\x72\145\40\x6c\x6f\x6f\x6b\x69\156\147\x20\146\157\x72\40\x77\141\163\x20\156\x6f\164\40\146\157\165\x6e\x64\56\74\57\150\63\x3e\15\xa\40\x20\x20\40\x3c\x2f\x64\x69\x76\76\15\xa\x3c\x2f\x64\151\x76\76\xd\12"; goto oopkY4leJpPmmblJ; YErtX2bTcpPKgiid: echo get_env("\x74\x69\164\x6c\145"); goto Ld3al0LmEoR2g_Gn; hcvyoeSJiI_aioQv: session_write_close(); goto Z4XQ1ErfTcRcrpEC; U2sAlH30QuGS7xtY: get_backend_header(); goto TirrB9J8nOYYQAPF; oopkY4leJpPmmblJ: get_backend_footer();
