<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto MlFs36dnQx6NiSO0; a3sppxbpXDRv_wNU: echo $html->renderTemplate("\x75\x73\145\x72\55\154\x69\163\164\x2e\x68\164\155\154\56\x74\167\x69\147", ["\164\151\x74\154\x65" => get_env("\164\151\x74\154\145"), "\141\144\155\151\x6e\137\144\151\x72" => ADMIN_DIR]); goto PmI7h9QoFadS6swo; jhi5Y158lquz1CkG: eJdp3Z2wO5AG63c2: goto sn2QJMv6uQPymWLr; MlFs36dnQx6NiSO0: session_write_close(); goto uZ0CgmK860978hHn; JV4efDe7GuVO1CKE: $html = new \GDPlayer\HTML(); goto a3sppxbpXDRv_wNU; dgpUxCUEBp0XtNh_: include ADMIN_PATH . "\x2f\64\x30\x33\x2e\x70\x68\160"; goto vYXvqYTMQCZvSx35; NJ7udLK5kg1bvpeq: session_write_close(); goto dgpUxCUEBp0XtNh_; sn2QJMv6uQPymWLr: set_env("\164\151\164\x6c\145", "\x55\x73\145\x72\40\114\x69\163\x74"); goto yM734h9X3J3MHczL; uZ0CgmK860978hHn: if (is_admin()) { goto eJdp3Z2wO5AG63c2; } goto NJ7udLK5kg1bvpeq; vYXvqYTMQCZvSx35: exit; goto jhi5Y158lquz1CkG; yM734h9X3J3MHczL: get_backend_header(); goto JV4efDe7GuVO1CKE; PmI7h9QoFadS6swo: get_backend_footer();
