<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto rwwcztHM7BNFev8K; marcjyDQLNvB7OFn: JlrF1Aq3NQ2nkYwA: goto JPUCPJQWxSq7J19C; rUYRPrQAwXDslbs7: include ADMIN_PATH . "\57\x34\60\63\56\x70\x68\160"; goto TrhFFX_KeHUsNS9t; ADCQtLmYDrhFLiro: echo $html->renderTemplate("\165\163\145\x72\x2d\163\145\163\x73\x69\x6f\x6e\x73\56\x68\164\155\x6c\56\x74\167\151\147", ["\x74\151\x74\x6c\145" => get_env("\164\x69\x74\154\x65"), "\x61\144\x6d\x69\x6e\137\144\151\x72" => ADMIN_DIR]); goto BIHqD8eEtueQqEis; rwwcztHM7BNFev8K: session_write_close(); goto SRxqEc6Zin53r5eh; PWtufus3gPBPYpca: session_write_close(); goto rUYRPrQAwXDslbs7; m15Zt3Ne1PYNOjO8: $html = new \GDPlayer\HTML(); goto ADCQtLmYDrhFLiro; TrhFFX_KeHUsNS9t: exit; goto marcjyDQLNvB7OFn; JPUCPJQWxSq7J19C: set_env("\x74\151\x74\154\145", "\123\145\x73\163\151\x6f\x6e\40\x4c\151\163\164"); goto okFCBYMo1Oud31N1; okFCBYMo1Oud31N1: get_backend_header(); goto m15Zt3Ne1PYNOjO8; SRxqEc6Zin53r5eh: if (is_admin()) { goto JlrF1Aq3NQ2nkYwA; } goto PWtufus3gPBPYpca; BIHqD8eEtueQqEis: get_backend_footer();
