<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto x7UpgHJRv11h1XN_; x7UpgHJRv11h1XN_: session_write_close(); goto V2oU9JwWyQRnHoPR; V2oU9JwWyQRnHoPR: $class = new \GDPlayer\Ajax\GDriveMirrors(); goto VBirelEmHxpQhafV; VBirelEmHxpQhafV: echo $class->list($_GET);
