<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto FVuVUR1PiGlzLBM7; FVuVUR1PiGlzLBM7: session_write_close(); goto yj_jgZEy44wic5aq; yj_jgZEy44wic5aq: $class = new \GDPlayer\Ajax\GDriveQueue(); goto U73WwPTnfAgPV2hT; U73WwPTnfAgPV2hT: echo $class->response($_POST);
