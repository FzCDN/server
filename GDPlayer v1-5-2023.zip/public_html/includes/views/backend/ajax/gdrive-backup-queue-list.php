<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto vTgk2UD_lTLjQgKB; loKKxYm_KSRuKDTB: $class = new \GDPlayer\Ajax\GDriveQueue(); goto o2fVaE_DQEzgd0Jt; vTgk2UD_lTLjQgKB: session_write_close(); goto loKKxYm_KSRuKDTB; o2fVaE_DQEzgd0Jt: echo $class->list($_GET);
