<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto gHFVckMjRDkFTmMq; gHFVckMjRDkFTmMq: session_write_close(); goto oTdhNpuHN9U7t1NE; oTdhNpuHN9U7t1NE: $class = new \GDPlayer\Ajax\GDriveFiles(); goto HbJ3Xmqh4bM97qaI; HbJ3Xmqh4bM97qaI: echo $class->list($_GET);
