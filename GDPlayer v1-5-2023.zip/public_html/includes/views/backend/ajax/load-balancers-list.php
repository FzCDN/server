<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto TgUYslqzoBbHfZ_D; TgUYslqzoBbHfZ_D: session_write_close(); goto H5WqB5amVQN4yfmb; H5WqB5amVQN4yfmb: $class = new \GDPlayer\Ajax\LoadBalancers(); goto oz3N48pjEfdeq08Q; oz3N48pjEfdeq08Q: echo $class->list($_GET);
