<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto ZFblPWpghjVyeulP; j5SROkO48Ha6oQkk: $class = new \GDPlayer\Ajax\Sessions(); goto ftslf2bxR2atbRzy; ZFblPWpghjVyeulP: session_write_close(); goto j5SROkO48Ha6oQkk; ftslf2bxR2atbRzy: echo $class->response($_POST);
