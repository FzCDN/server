<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto i71T_LJuTDxCiacs; D2yjTmz0nd0pUKko: $class = new \GDPlayer\Ajax\Dashboard(); goto xcKhD8KgZb21GrTi; i71T_LJuTDxCiacs: session_write_close(); goto VcV5Wy9ET5rA5Ed8; VcV5Wy9ET5rA5Ed8: set_time_limit(0); goto D2yjTmz0nd0pUKko; xcKhD8KgZb21GrTi: echo $class->response($_POST);
