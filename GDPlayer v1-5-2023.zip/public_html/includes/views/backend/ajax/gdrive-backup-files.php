<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto V0NwaqoHwvUBbgks; bRRbrbjaqSUNG2sn: $class = new \GDPlayer\Ajax\GDriveMirrors(); goto FVaY94akfHhsuZ4J; V0NwaqoHwvUBbgks: session_write_close(); goto bRRbrbjaqSUNG2sn; FVaY94akfHhsuZ4J: echo $class->response($_POST);
