<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto oKVzJaxPI3AmYoVL; uv3wRif5sq8_O9NK: $class = new \GDPlayer\Ajax\Videos(); goto BRSg30KmYvlu9deL; oKVzJaxPI3AmYoVL: session_write_close(); goto uv3wRif5sq8_O9NK; BRSg30KmYvlu9deL: echo $class->list($_GET);
