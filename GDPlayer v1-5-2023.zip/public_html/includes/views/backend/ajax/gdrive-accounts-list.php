<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto BqUK1fvoYHVX8351; BqUK1fvoYHVX8351: session_write_close(); goto Q8luG0X1msEwDsIW; Q8luG0X1msEwDsIW: $class = new \GDPlayer\Ajax\GDriveAccounts(); goto TVArn3ir4DW6iTud; TVArn3ir4DW6iTud: echo $class->list($_GET);
