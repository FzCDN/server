<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto Y088mZhAYXk6RnQa; Y088mZhAYXk6RnQa: session_write_close(); goto aL9m7mdDV9p92QlD; aL9m7mdDV9p92QlD: $class = new \GDPlayer\Ajax\PublicAjax(); goto Wcazj9OEoYOjUcwb; Wcazj9OEoYOjUcwb: echo $class->response($_POST);
