<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto SxvG0B1x6B9UJkUU; SxvG0B1x6B9UJkUU: session_write_close(); goto KWOcRPloTf3kV6MR; KWOcRPloTf3kV6MR: $class = new \GDPlayer\Ajax\GDriveFiles(); goto Ny_pvI4_ljlMvQz2; Ny_pvI4_ljlMvQz2: echo $class->response($_POST);
