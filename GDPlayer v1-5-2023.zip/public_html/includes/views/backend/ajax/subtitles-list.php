<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto uP5bun0feqNCgubX; uP5bun0feqNCgubX: session_write_close(); goto TRtGesiyHfrp0e3n; TRtGesiyHfrp0e3n: $class = new \GDPlayer\Ajax\Subtitles(); goto n7ZOk1D7C_NPcCTY; n7ZOk1D7C_NPcCTY: echo $class->list($_GET);
