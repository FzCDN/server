<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto x81HFmcOwghqtGvc; x81HFmcOwghqtGvc: session_write_close(); goto B04uJ5dyllCf1nTF; B04uJ5dyllCf1nTF: $class = new \GDPlayer\Ajax\Videos(); goto PVl0hSzIW5owNo_4; PVl0hSzIW5owNo_4: echo $class->response($_POST, $_FILES);
