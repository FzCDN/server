<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto r6W5Co5KfiZcJlF_; Kan1PTLRdEXvVCfp: $class = new \GDPlayer\Ajax\Users(); goto bbG1BjuAW1l2k8BC; r6W5Co5KfiZcJlF_: session_write_close(); goto Kan1PTLRdEXvVCfp; bbG1BjuAW1l2k8BC: echo $class->list($_GET);
