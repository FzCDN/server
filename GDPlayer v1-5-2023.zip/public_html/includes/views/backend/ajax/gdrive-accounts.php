<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto hpRGHUH1FCmLf66C; hpRGHUH1FCmLf66C: session_write_close(); goto dzFMMcA593R0lBfN; dzFMMcA593R0lBfN: $class = new \GDPlayer\Ajax\GDriveAccounts(); goto YfBQ2AeIz8e1Zv9g; YfBQ2AeIz8e1Zv9g: echo $class->response($_POST);
