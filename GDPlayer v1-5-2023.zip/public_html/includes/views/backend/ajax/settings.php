<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto eG5eUJcZ8NaDw1Q1; Snaj8o8DuoDuhPuT: $class = new \GDPlayer\Ajax\Settings(); goto WZ0li6nVkYiQzGs9; eG5eUJcZ8NaDw1Q1: session_write_close(); goto Snaj8o8DuoDuhPuT; WZ0li6nVkYiQzGs9: echo $class->response($_POST);
