<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto Nvz6_BmwV0Fr5ahD; BDnEeIAn2qO3WqMh: $class = new \GDPlayer\Ajax\LoadBalancers(); goto BpAAOB_oickLLS_x; Nvz6_BmwV0Fr5ahD: session_write_close(); goto BDnEeIAn2qO3WqMh; BpAAOB_oickLLS_x: echo $class->response($_POST);
