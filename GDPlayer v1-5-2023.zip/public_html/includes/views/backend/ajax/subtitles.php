<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto yv2Da54Y8b6wD9H5; gDU6kpT1oMqitxMm: $class = new \GDPlayer\Ajax\Subtitles(); goto WzEAb43u91xj1mon; yv2Da54Y8b6wD9H5: session_write_close(); goto gDU6kpT1oMqitxMm; WzEAb43u91xj1mon: echo $class->response($_POST, $_FILES);
