<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto yA3gBhPzf4x4vfpP; IvEhdnC6iy8oVoHV: exit; goto O9YahQkaDm6xJfbc; yA3gBhPzf4x4vfpP: session_write_close(); goto gWN28GN4f_LYEIkv; G4QT1S0htV99Tkjq: $subtitles = array_values($subtitles); goto Cp3RBLrPhf1Z7h5E; O9YahQkaDm6xJfbc: pdO6oDFX39N0Ey7M: goto QlEhS8eo_FotARHC; gWN28GN4f_LYEIkv: if (current_user()) { goto pdO6oDFX39N0Ey7M; } goto HLofNlfPbh5L9KqQ; cKILcENQEYIClyrH: get_backend_header(); goto m5YH_tVq4c8xeBP1; m5YH_tVq4c8xeBP1: $html = new \GDPlayer\HTML(); goto Ewc_FfBKom_h5rro; QlEhS8eo_FotARHC: $subtitles = language_list(); goto G4QT1S0htV99Tkjq; PfHtMuStqhsbRqTr: include ADMIN_PATH . "\x2f\64\60\63\56\x70\150\x70"; goto IvEhdnC6iy8oVoHV; HLofNlfPbh5L9KqQ: session_write_close(); goto PfHtMuStqhsbRqTr; Cp3RBLrPhf1Z7h5E: set_env("\x74\x69\164\x6c\145", "\123\x75\x62\x74\x69\x74\154\x65\x20\x4d\141\x6e\141\x67\145\x72"); goto cKILcENQEYIClyrH; Ewc_FfBKom_h5rro: echo $html->renderTemplate("\163\165\142\x74\x69\164\x6c\x65\55\154\x69\163\164\x2e\x68\x74\x6d\x6c\x2e\x74\167\x69\x67", ["\164\x69\x74\x6c\x65" => get_env("\x74\x69\164\154\145"), "\x69\163\137\x61\144\155\x69\x6e" => is_admin(), "\163\x75\x62\164\151\x74\154\145\x73" => $subtitles, "\x62\141\x73\x65\137\165\162\154" => BASE_URL]); goto ki7C32sKw2E1xULk; ki7C32sKw2E1xULk: get_backend_footer();
