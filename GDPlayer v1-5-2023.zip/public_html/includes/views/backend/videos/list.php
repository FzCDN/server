<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto vtqY7QfChaFvziJz; C8ZlgACzQB_KM8hl: if (current_user()) { goto GG7HjFzlsKRiJLJK; } goto oBt6iEqdTz27Z62w; pAIflKUOO_aT8rCS: include ADMIN_PATH . "\x2f\x34\x30\x31\56\160\150\160"; goto lwcZgw2A9t6djrLc; BgxE3Qho3jfDZFwW: set_env("\x74\151\164\x6c\x65", "\126\x69\x64\x65\x6f\x20\x4c\x69\163\x74"); goto jD0Mu529Tt7m2ihp; jD0Mu529Tt7m2ihp: get_backend_header(); goto xwB5LxbWHSSyqUVV; vtqY7QfChaFvziJz: session_write_close(); goto C8ZlgACzQB_KM8hl; K0ixjzQvUjqIGj0R: echo $html->renderTemplate("\166\x69\x64\145\x6f\x2d\x6c\151\163\x74\56\150\x74\155\154\56\164\x77\x69\147", ["\164\151\x74\x6c\145" => get_env("\x74\x69\164\x6c\145"), "\x61\x64\155\151\x6e\137\144\x69\x72" => ADMIN_DIR]); goto ETuV9i2PynlaWrQq; ruAr9YuFjdreXxo3: GG7HjFzlsKRiJLJK: goto BgxE3Qho3jfDZFwW; lwcZgw2A9t6djrLc: exit; goto ruAr9YuFjdreXxo3; oBt6iEqdTz27Z62w: session_write_close(); goto pAIflKUOO_aT8rCS; xwB5LxbWHSSyqUVV: $html = new \GDPlayer\HTML(); goto K0ixjzQvUjqIGj0R; ETuV9i2PynlaWrQq: get_backend_footer();
