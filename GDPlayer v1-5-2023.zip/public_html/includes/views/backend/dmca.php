<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto UP3zndlT4Gg_TAve; YLZuyxyOORLPIyoW: set_env("\164\151\164\154\145", "\104\x4d\x43\x41\x20\x54\141\153\x65\x64\x6f\167\x6e"); goto iPa3i1zQcfZLQc66; UP3zndlT4Gg_TAve: session_write_close(); goto YLZuyxyOORLPIyoW; iPa3i1zQcfZLQc66: get_backend_header(); goto s8yi91KD_E81_DR4; m38GXVlsiwayUm2L: echo get_env("\164\x69\x74\x6c\145"); goto is8phW7nwPaPMgZk; s8yi91KD_E81_DR4: echo "\74\144\151\x76\x20\143\x6c\x61\163\x73\75\42\x72\x6f\167\x22\x3e\15\xa\x20\40\x20\40\x3c\x64\151\166\40\x63\154\141\163\x73\75\42\143\x6f\x6c\x2d\61\x32\x20\164\145\170\164\55\x63\x65\156\x74\x65\162\x22\x3e\xd\xa\x20\40\40\x20\40\x20\x20\x20\74\x68\61\x20\x63\x6c\141\163\x73\75\x22\x68\63\x20\x74\145\170\164\x2d\144\141\156\x67\145\x72\x22\x3e"; goto m38GXVlsiwayUm2L; is8phW7nwPaPMgZk: echo "\x3c\x2f\x68\x31\76\15\xa\x20\x20\x20\x20\x20\40\40\x20\74\x68\x33\x20\x63\154\x61\163\x73\75\x22\150\64\x20\x74\145\170\164\55\163\x65\143\157\156\x64\x61\162\x79\x22\x3e\x53\x6f\162\162\x79\x20\x74\150\x69\x73\x20\x76\151\x64\x65\x6f\40\151\x73\40\165\x6e\141\x76\x61\x69\154\x61\142\x6c\x65\56\x3c\x2f\150\63\76\15\xa\x20\x20\40\x20\x3c\x2f\x64\x69\x76\76\xd\12\x3c\x2f\144\151\x76\x3e\xd\xa"; goto UWbE7kBKODUCep8i; UWbE7kBKODUCep8i: get_backend_footer();
