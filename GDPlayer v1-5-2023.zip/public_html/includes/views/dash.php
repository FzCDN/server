<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto QmRbSYKTzXmm9Sir; QmRbSYKTzXmm9Sir: session_write_close(); goto TkypOONc2of6dWoh; TkypOONc2of6dWoh: $stream = new \GDPlayer\StreamMaster(true, true); goto q00MrigZTViNyQUJ; q00MrigZTViNyQUJ: $stream->load();
