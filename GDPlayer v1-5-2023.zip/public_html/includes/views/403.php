<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto WMl5yNDYInXZuzva; WMl5yNDYInXZuzva: session_write_close(); goto q3nS2efxyPpV43bc; A2pWLVPChTb0Cct9: echo "\74\57\150\x31\x3e\15\12\40\x20\x20\40\x20\x20\40\x20\74\x68\63\x20\x63\x6c\x61\163\x73\75\42\x68\x34\x20\x74\x65\x78\x74\55\163\145\x63\157\x6e\x64\141\x72\x79\x22\76\x59\157\165\40\x61\x72\145\x20\x6e\157\x74\x20\x61\154\x6c\157\167\x65\x64\x20\x74\157\40\141\x63\x63\x65\163\163\40\x74\150\145\x20\160\x61\147\145\x2e\74\x2f\150\63\x3e\xd\xa\40\x20\x20\x20\74\57\144\151\166\76\15\xa\x3c\57\144\151\166\76\15\xa"; goto iQEH7yf2nqP1vTeA; BrHkrNCvjX0KsJf5: echo "\74\x64\x69\166\x20\x63\x6c\141\163\163\75\x22\162\x6f\167\42\76\xd\12\x20\40\40\x20\74\144\x69\x76\x20\143\x6c\141\163\x73\75\x22\143\x6f\x6c\x2d\61\x32\x20\164\145\170\x74\x2d\143\x65\x6e\164\x65\162\42\76\15\xa\40\x20\x20\40\x20\40\x20\x20\x3c\150\x31\40\143\154\141\x73\x73\x3d\42\x68\63\x20\x74\x65\x78\x74\55\144\141\156\x67\145\162\x22\x3e"; goto gqO2tpyxUk8TIMfn; gqO2tpyxUk8TIMfn: echo get_env("\x74\151\x74\x6c\145"); goto A2pWLVPChTb0Cct9; q3nS2efxyPpV43bc: set_env("\x74\151\164\x6c\x65", "\x34\x30\x33\x20\x46\157\162\142\151\144\x64\145\x6e"); goto c4b7lYjD51V75NKA; c4b7lYjD51V75NKA: get_frontend_header(); goto BrHkrNCvjX0KsJf5; iQEH7yf2nqP1vTeA: get_frontend_footer();
