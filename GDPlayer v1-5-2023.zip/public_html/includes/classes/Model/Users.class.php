<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class Users extends \GDPlayer\Model { protected $table = "\164\142\x5f\165\163\x65\162\x73"; protected $fields = ["\x69\x64", "\165\x73\145\x72", "\x65\x6d\141\151\x6c", "\x70\x61\x73\x73\x77\157\162\144", "\156\141\155\x65", "\163\164\x61\164\x75\163", "\x61\144\x64\145\x64", "\165\160\144\141\x74\145\144", "\162\x6f\154\145"]; protected $primaryKey = "\x69\x64"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
