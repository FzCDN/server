<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class VideoShort extends \GDPlayer\Model { protected $table = "\x74\x62\x5f\166\151\x64\x65\157\x73\137\163\150\x6f\162\164"; protected $fields = ["\151\144", "\153\145\x79", "\x76\151\x64"]; protected $primaryKey = "\151\x64"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
