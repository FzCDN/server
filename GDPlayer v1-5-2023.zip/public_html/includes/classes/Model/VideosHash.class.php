<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class VideosHash extends \GDPlayer\Model { protected $table = "\x74\142\x5f\x76\151\x64\145\157\x73\137\x68\x61\x73\x68"; protected $fields = ["\x69\144", "\150\x6f\x73\x74", "\150\157\x73\x74\x5f\151\x64", "\x67\x64\162\x69\166\145\137\x65\x6d\141\151\x6c", "\144\x61\x74\141"]; protected $primaryKey = "\x69\x64"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
