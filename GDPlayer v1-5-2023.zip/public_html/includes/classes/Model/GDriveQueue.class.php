<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class GDriveQueue extends \GDPlayer\Model { protected $table = "\164\142\137\x67\144\x72\151\166\x65\x5f\x71\x75\x65\165\x65"; protected $fields = ["\x69\x64", "\147\x64\x72\151\166\x65\137\151\144", "\144\145\154\x61\171\145\x64"]; protected $primaryKey = "\x69\x64"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
