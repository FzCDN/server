<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class Sessions extends \GDPlayer\Model { protected $table = "\x74\x62\137\163\x65\x73\x73\151\157\156\163"; protected $fields = ["\x69\x64", "\x69\x70", "\165\163\145\x72\x61\x67\x65\x6e\x74", "\143\x72\145\141\x74\x65\x64", "\165\x73\145\162\156\x61\x6d\145", "\145\170\x70\x69\162\145\144", "\164\x6f\153\x65\156", "\x73\x74\141\164"]; protected $primaryKey = "\151\x64"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
