<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class GDriveAuth extends \GDPlayer\Model { protected $table = "\x74\x62\137\x67\x64\x72\151\166\145\x5f\141\165\x74\150"; protected $fields = ["\151\144", "\x65\x6d\141\x69\154", "\141\x70\151\137\x6b\x65\x79", "\143\x6c\x69\x65\156\164\x5f\151\x64", "\x63\x6c\x69\x65\x6e\164\137\163\145\x63\162\x65\x74", "\162\x65\x66\162\145\x73\150\137\164\157\153\145\156", "\143\x72\x65\141\x74\x65\144", "\x6d\x6f\x64\x69\146\x69\145\x64", "\165\151\x64", "\x73\164\141\x74\165\x73"]; protected $primaryKey = "\x69\144"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
