<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class Plugins extends \GDPlayer\Model { protected $table = "\x74\142\x5f\160\x6c\x75\x67\x69\156\163"; protected $fields = ["\151\144", "\153\145\x79", "\x76\141\154\x75\x65", "\165\160\144\141\164\x65\144"]; protected $primaryKey = "\151\144"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
