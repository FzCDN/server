<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class VideoSources extends \GDPlayer\Model { protected $table = "\164\x62\137\x76\x69\x64\145\x6f\163\137\x73\x6f\x75\162\x63\x65\x73"; protected $fields = ["\151\144", "\x68\x6f\x73\x74", "\150\x6f\x73\x74\137\151\x64", "\144\x61\164\141", "\x64\x6c", "\x73\151\x64", "\143\162\x65\x61\164\x65\144", "\145\170\160\x69\x72\145\x64"]; protected $primaryKey = "\151\144"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
