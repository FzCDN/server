<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class Stats extends \GDPlayer\Model { protected $table = "\164\142\x5f\x73\x74\141\x74\163"; protected $fields = ["\x69\x64", "\166\x69\144", "\x69\x70", "\x75\x61", "\x63\x72\x65\x61\x74\x65\144"]; protected $primaryKey = "\151\144"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
