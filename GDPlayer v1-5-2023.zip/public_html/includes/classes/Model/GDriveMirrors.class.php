<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class GDriveMirrors extends \GDPlayer\Model { protected $table = "\x74\x62\x5f\x67\144\162\x69\x76\x65\x5f\x6d\151\162\x72\x6f\162\163"; protected $fields = ["\151\144", "\147\144\162\151\x76\145\x5f\151\144", "\x6d\x69\x72\162\x6f\162\x5f\151\144", "\155\x69\x72\x72\157\x72\137\x65\x6d\x61\x69\x6c", "\141\144\x64\x65\x64"]; protected $primaryKey = "\x69\x64"; protected $gdAPI; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
