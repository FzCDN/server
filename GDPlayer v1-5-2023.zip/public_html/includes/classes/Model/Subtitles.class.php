<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class Subtitles extends \GDPlayer\Model { protected $table = "\x74\142\137\163\x75\142\164\x69\x74\x6c\x65\163"; protected $fields = ["\x69\144", "\154\x61\156\147\x75\x61\x67\145", "\x6c\x69\156\x6b", "\x76\x69\144", "\x61\x64\x64\145\x64", "\165\x69\x64", "\x6f\x72\144\x65\162", "\x75\x70\x64\141\x74\145\144"]; protected $primaryKey = "\x69\x64"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
