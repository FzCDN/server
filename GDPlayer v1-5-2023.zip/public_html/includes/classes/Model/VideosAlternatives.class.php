<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class VideosAlternatives extends \GDPlayer\Model { protected $table = "\x74\x62\137\166\x69\x64\145\157\163\x5f\x61\x6c\164\145\162\x6e\141\164\x69\x76\x65\163"; protected $fields = ["\x69\144", "\x76\x69\144", "\x68\x6f\163\x74", "\x68\157\163\164\137\x69\x64", "\157\x72\144\x65\162"]; protected $primaryKey = "\x69\144"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
