<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class Settings extends \GDPlayer\Model { protected $table = "\164\142\x5f\163\x65\x74\164\x69\x6e\x67\163"; protected $fields = ["\151\144", "\153\x65\x79", "\166\x61\x6c\x75\x65", "\x75\160\x64\x61\x74\x65\144"]; protected $primaryKey = "\x69\144"; public function __construct() { session_write_close(); parent::__construct(); } public function reset() { goto u3JPyJWr2vuNgMhY; E_jNAE679FB9J4YI: return $this->delete(); goto tISqVWD1NEc7G20Y; u3JPyJWr2vuNgMhY: session_write_close(); goto tm_BnESPVLYPNvMU; tm_BnESPVLYPNvMU: $this->setCriteria("\153\x65\171", '', "\74\76"); goto E_jNAE679FB9J4YI; tISqVWD1NEc7G20Y: } public function __destruct() { session_write_close(); parent::__destruct(); } }
