<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class Videos extends \GDPlayer\Model { protected $table = "\x74\x62\137\x76\x69\x64\145\x6f\163"; protected $fields = ["\x69\144", "\164\151\x74\x6c\x65", "\x68\157\163\x74", "\150\157\x73\x74\137\151\144", "\165\x69\144", "\141\x64\144\145\144", "\165\160\x64\x61\164\x65\144", "\x70\157\163\164\145\162", "\163\164\x61\164\x75\163", "\x76\151\145\167\x73", "\144\x6d\143\141"]; protected $primaryKey = "\x69\x64"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
