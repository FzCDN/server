<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class SubtitleManager extends \GDPlayer\Model { protected $table = "\x74\142\x5f\x73\165\142\164\x69\x74\x6c\145\x5f\155\x61\156\x61\147\145\x72"; protected $fields = ["\151\x64", "\x66\x69\x6c\145\x5f\x6e\x61\155\x65", "\x66\x69\154\x65\x5f\163\x69\172\x65", "\146\151\154\145\137\164\x79\160\145", "\154\x61\156\147\x75\x61\147\145", "\141\144\144\x65\x64", "\x75\151\x64", "\x68\x6f\x73\164", "\165\160\x64\x61\x74\x65\144"]; protected $primaryKey = "\x69\x64"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
