<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class LoadBalancers extends \GDPlayer\Model { protected $table = "\x74\142\137\154\157\141\x64\x62\x61\154\141\156\x63\x65\162\163"; protected $fields = ["\x69\144", "\x6e\x61\x6d\145", "\x6c\x69\x6e\x6b", "\163\164\141\x74\165\x73", "\160\165\142\x6c\x69\x63", "\x61\144\x64\145\144", "\165\160\x64\x61\164\145\x64", "\144\x69\163\141\x6c\154\157\167\x5f\x68\x6f\x73\164\163"]; protected $primaryKey = "\x69\x64"; public function __construct() { session_write_close(); parent::__construct(); } public function __destruct() { session_write_close(); parent::__destruct(); } }
