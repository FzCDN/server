<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer; class GDriveAPIHelper { protected $encryptTitle = false; protected $fileID = ''; protected $nextPageToken = ''; protected $qFolderOnly = false; protected $qPrivateOnly = false; protected $qTitle = ''; protected $title = ''; public function encryptTitle(bool $encypt = false) { session_write_close(); $this->encryptTitle = $encypt; } public function setFileID(string $id = '') { session_write_close(); $this->fileID = getDriveId($id); } public function setNextpageToken(string $nextPageToken = '') { session_write_close(); $this->nextPageToken = $nextPageToken; } public function setTitle(string $title = '') { session_write_close(); $this->title = $title; } public function searchTitle(string $qTitle = '') { session_write_close(); $this->qTitle = $qTitle; } public function searchFolderOnly(bool $qFolderOnly = false) { session_write_close(); $this->qFolderOnly = $qFolderOnly; } public function searchPrivateOnly(bool $qPrivateOnly = false) { session_write_close(); $this->qPrivateOnly = $qPrivateOnly; } public function getNextpageToken() { session_write_close(); return $this->nextPageToken; } }
