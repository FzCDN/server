<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2023-02-28 22:05:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto Q2AAw2MLADEXYOSo; iaf2WigTHLD23LBV: include __DIR__ . "\57\x66\x75\x6e\x63\164\151\x6f\156\x73\x2e\160\x68\160"; goto pHyKCaLcsg87gWK7; pJUkHfeFnWfYH_2A: header_remove("\x58\x2d\120\157\x77\145\162\x65\x64\x2d\102\171"); goto ZWtEhXeomwHbaFg7; Q2AAw2MLADEXYOSo: session_write_close(); goto v_JjuDaKlHv7g5b2; ZWtEhXeomwHbaFg7: include __DIR__ . "\x2f\x2e\x2e\57\x76\145\x6e\x64\157\162\57\141\x75\164\x6f\x6c\157\141\x64\x2e\160\x68\x70"; goto cW0Q735ILqHD7sCZ; cW0Q735ILqHD7sCZ: include __DIR__ . "\57\143\157\156\146\151\x67\56\x70\x68\160"; goto iaf2WigTHLD23LBV; v_JjuDaKlHv7g5b2: header("\104\145\x76\x65\x6c\157\x70\x65\x64\55\142\x79\72\x20\x47\x44\120\154\x61\x79\x65\162\56\x74\x6f", true); goto pJUkHfeFnWfYH_2A; pHyKCaLcsg87gWK7: include __DIR__ . "\57\160\x6c\165\x67\151\x6e\x73\56\x70\x68\160";
