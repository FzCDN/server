$(document).ready(function () {
    console.log('plugins');
});
