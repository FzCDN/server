<?php
session_write_close();
if (!defined('BASE_DIR')) {
    session_write_close();
    exit('Access denied!');
}
include BASE_DIR . 'includes/themes.php';

echo loadJsDelivrStyle('@fortawesome/fontawesome-free/css/all.min.css');
echo loadJsDelivrStyle('bootstrap@4.6.2/dist/css/bootstrap.min.css');
echo loadJsDelivrStyle('bootstrap-sweetalert/dist/sweetalert.min.css');
echo loadJsDelivrStyle('select2/dist/css/select2.min.css');
echo loadJsDelivrStyle('select2-bootstrap4-theme/dist/select2-bootstrap4.min.css');
echo loadJsDelivrStyle('jquery-wheelcolorpicker/css/wheelcolorpicker.min.css');
echo loadJsDelivrStyle('toastify-js/src/toastify.min.css');
echo loadJsDelivrStyle('apexcharts/dist/apexcharts.min.css');
echo loadCdnJsStyle('multi-select/0.9.12/css/multi-select.min.css');
echo loadStyle('https://cdn.datatables.net/v/bs4/dt-1.13.2/fc-4.2.1/fh-3.3.1/r-2.4.0/rg-1.3.0/sr-1.2.1/datatables.min.css');
echo loadStyle('assets/css/style-v3.2.min.css');
?>
<style>
    a,
    .page-link,
    .btn-outline-custom {
        color: <?php echo $customColor; ?>;
    }

    .btn-outline-custom {
        border-color: <?php echo $customColor; ?>;
    }

    a:hover,
    .page-link:hover {
        color: <?php echo $customColor2; ?>;
    }

    .border-custom {
        border-color: <?php echo $customColor; ?> !important;
    }

    div.dataTables_processing>div:last-child>div,
    .select2-container--bootstrap4 .select2-results__option--highlighted,
    .select2-container--bootstrap4 .select2-results__option--highlighted.select2-results__option[aria-selected=true],
    .page-item.active .page-link,
    .dropdown-item.active,
    .dropdown-item:active,
    .bg-custom,
    .btn-custom,
    .nav-pills .nav-link.active,
    .nav-pills .show>.nav-link {
        color: #fff;
        border-color: <?php echo $customColor; ?>;
        background-color: <?php echo $customColor; ?>;
        background-image: -webkit-linear-gradient(to right, <?php echo $customColor; ?>, <?php echo $customColor2; ?>);
        background-image: -moz-linear-gradient(to right, <?php echo $customColor; ?>, <?php echo $customColor2; ?>);
        background-image: -o-linear-gradient(to right, <?php echo $customColor; ?>, <?php echo $customColor2; ?>);
        background-image: linear-gradient(to right, <?php echo $customColor; ?>, <?php echo $customColor2; ?>)
    }

    .btn-outline-custom.active,
    .btn-outline-custom:active,
    .btn-outline-custom.focus,
    .btn-outline-custom:focus,
    .btn-outline-custom:not(:disabled):hover,
    .btn-custom.focus,
    .btn-custom:focus,
    .btn-custom:not(:disabled):hover {
        color: #fff !important;
        border-color: <?php echo $customColor2; ?>;
        background-image: -webkit-linear-gradient(to right, <?php echo $customColor2; ?>, <?php echo $customColor; ?>);
        background-image: -moz-linear-gradient(to right, <?php echo $customColor2; ?>, <?php echo $customColor; ?>);
        background-image: -o-linear-gradient(to right, <?php echo $customColor2; ?>, <?php echo $customColor; ?>);
        background-image: linear-gradient(to right, <?php echo $customColor2; ?>, <?php echo $customColor; ?>);
        background-color: <?php echo $customColor2; ?>;
    }

    .page-link:focus,
    .btn-outline-custom.focus,
    .btn-outline-custom:focus,
    .btn-outline-custom:not(:disabled):hover,
    .btn-custom.focus,
    .btn-custom:focus {
        box-shadow: 0 0 0 .2rem rgba(<?php echo $rgbColor; ?>, .2) !important
    }

    .table-hover tbody tr:hover td {
        background-color: rgba(<?php echo $rgbColor; ?>, .07) !important;
    }

    #subsWrapper .input-group-prepend {
        max-width: 150px;
    }
</style>
<?php
$cssLinks = $plugins->getBackendCSS(true);
if ($cssLinks) {
    echo $cssLinks;
}
