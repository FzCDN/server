<?php
session_write_close();
if (!defined('BASE_DIR')) {
    session_write_close();
    exit('Access denied!');
}
include BASE_DIR . 'includes/themes.php';

echo loadJsDelivrScript('pwacompat@latest');
echo loadJsDelivrScript('jquery-ui/dist/jquery-ui.min.js');
echo loadJsDelivrScript('bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js');
echo loadJsDelivrScript('js-cookie@latest');
echo loadJsDelivrScript('bootstrap-sweetalert@latest');
echo loadJsDelivrScript('toastify-js@latest');
echo loadJsDelivrScript('bs-custom-file-input@latest');
echo loadJsDelivrScript('select2@latest');
echo loadJsDelivrScript('jquery-wheelcolorpicker@latest');
echo loadJsDelivrScript('apexcharts@latest');
echo loadCdnJsScript('multi-select/0.9.12/js/jquery.multi-select.min.js');
echo loadScript('https://cdn.datatables.net/v/bs4/dt-1.13.2/fc-4.2.1/fh-3.3.1/r-2.4.0/rg-1.3.0/sr-1.2.1/datatables.min.js');
echo loadScript('assets/js/md5.js');
echo loadScript('assets/js/main-v3.1.min.js');

$script = $plugins->getBackendJS(true);
if ($script) {
    echo $script;
}
echo $widget->recaptcha();
echo $widget->histats();
echo htmlspecialchars_decode(get_option('chat_widget'), ENT_QUOTES);
?>
<script>
    if ("serviceWorker" in navigator) {
        navigator.serviceWorker
            .register('sw.js')
            .then(function(res) {
                console.log("service worker registered");
            })
            .catch(function(err) {
                console.log("service worker not registered", err);
            });
    }
</script>
