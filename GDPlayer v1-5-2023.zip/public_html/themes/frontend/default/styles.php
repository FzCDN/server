<?php
session_write_close();
if (!defined('BASE_DIR')) {
    session_write_close();
    exit('Access denied!');
}
include BASE_DIR . 'includes/themes.php';

echo loadJsDelivrStyle('bootstrap@4.6.2/dist/css/bootstrap.min.css');
echo loadJsDelivrStyle('bootstrap-sweetalert/dist/sweetalert.min.css');
echo loadJsDelivrStyle('@fortawesome/fontawesome-free/css/all.min.css');
echo loadStyle('assets/css/style-v3.2.min.css');
?>
<style>
    a,
    .page-link,
    .btn-outline-custom {
        color: <?php echo $customColor; ?>;
    }

    .btn-outline-custom {
        border-color: <?php echo $customColor; ?>;
    }

    a:hover,
    .page-link:hover {
        color: <?php echo $customColor2; ?>;
    }

    .border-custom {
        border-color: <?php echo $customColor; ?> !important;
    }

    .page-item.active .page-link,
    .dropdown-item.active,
    .dropdown-item:active,
    .bg-custom,
    .btn-custom,
    .nav-pills .nav-link.active,
    .nav-pills .show>.nav-link {
        color: #fff;
        border-color: <?php echo $customColor; ?>;
        background-image: -webkit-linear-gradient(to right, <?php echo $customColor; ?>, <?php echo $customColor2; ?>);
        background-image: -moz-linear-gradient(to right, <?php echo $customColor; ?>, <?php echo $customColor2; ?>);
        background-image: -o-linear-gradient(to right, <?php echo $customColor; ?>, <?php echo $customColor2; ?>);
        background-image: linear-gradient(to right, <?php echo $customColor; ?>, <?php echo $customColor2; ?>);
        background-color: <?php echo $customColor; ?>;
    }

    .btn-outline-custom.active,
    .btn-outline-custom:active,
    .btn-outline-custom.focus,
    .btn-outline-custom:focus,
    .btn-outline-custom:not(:disabled):hover,
    .btn-custom.focus,
    .btn-custom:focus,
    .btn-custom:not(:disabled):hover {
        color: #fff !important;
        border-color: <?php echo $customColor2; ?>;
        background-image: -webkit-linear-gradient(to right, <?php echo $customColor2; ?>, <?php echo $customColor; ?>);
        background-image: -moz-linear-gradient(to right, <?php echo $customColor2; ?>, <?php echo $customColor; ?>);
        background-image: -o-linear-gradient(to right, <?php echo $customColor2; ?>, <?php echo $customColor; ?>);
        background-image: linear-gradient(to right, <?php echo $customColor2; ?>, <?php echo $customColor; ?>);
        background-color: <?php echo $customColor2; ?>;
    }

    .page-link:focus,
    .btn-outline-custom.focus,
    .btn-outline-custom:focus,
    .btn-outline-custom:not(:disabled):hover,
    .btn-custom.focus,
    .btn-custom:focus {
        box-shadow: 0 0 0 .2rem rgba(<?php echo $rgbColor; ?>, .2);
    }

    .table-hover tbody tr:hover td {
        background-color: rgba(<?php echo $rgbColor; ?>, .07) !important;
    }
</style>
<?php
$cssLinks = $plugins->getFrontendCSS(true);
if ($cssLinks) {
    echo $cssLinks;
}
