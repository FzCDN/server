<?php
session_write_close();
if (!defined('BASE_DIR')) {
    session_write_close();
    exit('Access denied!');
}
include BASE_DIR . 'includes/themes.php';

echo loadJsDelivrScript('pwacompat@latest');
echo loadJsDelivrScript('bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js');
echo loadJsDelivrScript('bootstrap-sweetalert@latest');
echo loadJsDelivrScript('bs-custom-file-input@latest');
echo loadJsDelivrScript('js-cookie@latest');
echo loadScript('assets/js/main-v3.1.min.js');

$script = $plugins->getFrontendJS(true);
if ($script) {
    echo $script;
}
echo $widget->recaptcha();
echo $widget->sharer();
echo $widget->histats();
echo htmlspecialchars_decode(get_option('chat_widget'), ENT_QUOTES);
?>
<script>
    if ("serviceWorker" in navigator) {
        navigator.serviceWorker
            .register('sw.js')
            .then(function(res) {
                console.debug("service worker registered");
            })
            .catch(function(err) {
                console.debug("service worker not registered", err);
            });
    }

    var deferredPrompt,
        $prompt;

    window.addEventListener('beforeinstallprompt', function(e) {
        e.preventDefault();
        deferredPrompt = e;
        $prompt = $('<div id="installPrompt" class="position-fixed bg-white p-3 shadow rounded text-center" style="bottom:50px;left:50%;z-index:11;width:200px;transform:translateX(-50%)"><p><strong>You can access this website on your device easily.</strong></p><button type="button" id="installWeb" class="btn btn-custom"><i class="fas fa-download mr-2"></i>Install Now</button><a id="hideInstallPrompt" href="javascript:void(0)" onclick="$(\'#installPrompt\').remove()" role="button" class="text-danger position-absolute bg-white rounded-circle p-2" style="top:-1rem;right:-1rem;width:2.5rem;height:2.5rem"><i class="fas fa-xl fa-times-circle"></i></a></div>');
        $('body').append($prompt);
        document.getElementById('installWeb').addEventListener('click', async () => {
            deferredPrompt.prompt();
            const {
                outcome
            } = await deferredPrompt.userChoice;
            if (outcome !== 'dismissed') {
                deferredPrompt = null;
            }
            $prompt.remove()
        });
    });

    window.addEventListener('appinstalled', function() {
        $(document).find('#hideInstallPrompt').click();
        deferredPrompt = null;
    });
</script>
