-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 14, 2024 at 09:57 AM
-- Server version: 10.6.16-MariaDB-0ubuntu0.22.04.1
-- PHP Version: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `festi_testloader`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_gdrive_auth`
--

CREATE TABLE `tb_gdrive_auth` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `api_key` varchar(50) NOT NULL,
  `client_id` varchar(100) NOT NULL,
  `client_secret` varchar(50) NOT NULL,
  `refresh_token` varchar(150) NOT NULL,
  `created` int(11) NOT NULL,
  `modified` int(11) NOT NULL DEFAULT 0,
  `uid` int(11) NOT NULL DEFAULT 1,
  `status` int(1) NOT NULL DEFAULT 1,
  `project_number` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_gdrive_mirrors`
--

CREATE TABLE `tb_gdrive_mirrors` (
  `id` bigint(20) NOT NULL,
  `gdrive_id` varchar(50) NOT NULL,
  `mirror_id` varchar(50) NOT NULL,
  `mirror_email` varchar(100) NOT NULL,
  `added` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_gdrive_queue`
--

CREATE TABLE `tb_gdrive_queue` (
  `id` bigint(20) NOT NULL,
  `gdrive_id` varchar(50) NOT NULL DEFAULT '',
  `delayed` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_loadbalancers`
--

CREATE TABLE `tb_loadbalancers` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `link` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `public` int(11) NOT NULL DEFAULT 0,
  `added` int(11) NOT NULL,
  `updated` int(11) NOT NULL DEFAULT 0,
  `disallow_hosts` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_plugins`
--

CREATE TABLE `tb_plugins` (
  `id` int(11) NOT NULL,
  `key` varchar(150) NOT NULL,
  `value` text NOT NULL,
  `updated` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_sessions`
--

CREATE TABLE `tb_sessions` (
  `id` int(11) NOT NULL,
  `ip` text NOT NULL,
  `useragent` varchar(250) NOT NULL,
  `created` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL,
  `expired` int(11) NOT NULL DEFAULT 0,
  `token` varchar(250) NOT NULL,
  `stat` int(11) NOT NULL DEFAULT 9
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_settings`
--

CREATE TABLE `tb_settings` (
  `id` int(11) NOT NULL,
  `key` varchar(150) NOT NULL,
  `value` mediumtext NOT NULL,
  `updated` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_settings`
--

INSERT INTO `tb_settings` (`id`, `key`, `value`, `updated`) VALUES
(156, 'db_engine', 'InnoDB', 1714561269),
(157, 'updated', '63', 1714561269),
(158, 'gdplayer_license', 'skamjaqj', 1714561287),
(159, 'anonymous_generator', 'true', 1715220640),
(160, 'embed_only', '', 1715220640),
(161, 'enable_download_page', '', 1715220640),
(162, 'hide_sub_download', 'true', 1715220640),
(163, 'save_public_video', '', 1715220640),
(164, 'public_video_user', '3', 1715220640),
(165, 'enable_gsharer', '', 1715220640),
(166, 'enable_gdrive_downloader', '', 1715220640),
(167, 'disable_registration', '', 1715220640),
(168, 'dmca_page_link', '', 1715220640),
(169, 'contact_page_link', '', 1715220640),
(170, 'player', 'jwplayer', 1715669674),
(171, 'player_skin', 'hotstar', 1715669674),
(172, 'player_color', 'ab0600', 1715669674),
(173, 'stretching', 'exactfit', 1715669674),
(174, 'preload', 'auto', 1715669674),
(175, 'default_resolution', '700', 1715669674),
(176, 'default_subtitle', 'Albanian', 1715669674),
(177, 'subtitle_color', 'f0eeff', 1715669674),
(178, 'autoplay', 'true', 1715669674),
(179, 'mute', '', 1715669674),
(180, 'repeat', '', 1715669674),
(181, 'display_title', 'true', 1715669674),
(182, 'playback_rate', 'true', 1715669674),
(183, 'enable_share_button', '', 1715669674),
(184, 'enable_download_button', '', 1715669674),
(185, 'continue_watching', '', 1715669674),
(186, 'poster', '', 1715669674),
(187, 'small_logo_file', '', 1715669674),
(188, 'small_logo_link', '', 1715669674),
(189, 'logo_file', '', 1715669674),
(190, 'logo_open_link', '', 1715669674),
(191, 'logo_position', 'top-right', 1715669674),
(192, 'logo_margin', '', 1715669674),
(193, 'logo_hide', '', 1715669674),
(194, 'p2p', '', 1715669674),
(195, 'torrent_tracker', 'wss://tracker.openwebtorrent.com\r\nwss://tracker.novage.com.ua\r\nwss://tracker.btorrent.xyz\r\nudp://public.popcorn-tracker.org:6969/announce\r\n\r\nhttp://104.28.1.30:8080/announce\r\n\r\nhttp://104.28.16.69/announce\r\n\r\nhttp://107.150.14.110:6969/announce\r\n\r\nhttp://109.121.134.121:1337/announce\r\n\r\nhttp://114.55.113.60:6969/announce\r\n\r\nhttp://125.227.35.196:6969/announce\r\n\r\nhttp://128.199.70.66:5944/announce\r\n\r\nhttp://157.7.202.64:8080/announce\r\n\r\nhttp://158.69.146.212:7777/announce\r\n\r\nhttp://173.254.204.71:1096/announce\r\n\r\nhttp://178.175.143.27/announce\r\n\r\nhttp://178.33.73.26:2710/announce\r\n\r\nhttp://182.176.139.129:6969/announce\r\n\r\nhttp://185.5.97.139:8089/announce\r\n\r\nhttp://188.165.253.109:1337/announce\r\n\r\nhttp://194.106.216.222/announce\r\n\r\nhttp://195.123.209.37:1337/announce\r\n\r\nhttp://210.244.71.25:6969/announce\r\n\r\nhttp://210.244.71.26:6969/announce\r\n\r\nhttp://213.159.215.198:6970/announce\r\n\r\nhttp://213.163.67.56:1337/announce\r\n\r\nhttp://37.19.5.139:6969/announce\r\n\r\nhttp://37.19.5.155:6881/announce\r\n\r\nhttp://46.4.109.148:6969/announce\r\n\r\nhttp://5.79.249.77:6969/announce\r\n\r\nhttp://5.79.83.193:2710/announce\r\n\r\nhttp://51.254.244.161:6969/announce\r\n\r\nhttp://59.36.96.77:6969/announce\r\n\r\nhttp://74.82.52.209:6969/announce\r\n\r\nhttp://80.246.243.18:6969/announce\r\n\r\nhttp://81.200.2.231/announce\r\n\r\nhttp://85.17.19.180/announce\r\n\r\nhttp://87.248.186.252:8080/announce\r\n\r\nhttp://87.253.152.137/announce\r\n\r\nhttp://91.216.110.47/announce\r\n\r\nhttp://91.217.91.21:3218/announce\r\n\r\nhttp://91.218.230.81:6969/announce\r\n\r\nhttp://93.92.64.5/announce\r\n\r\nhttp://atrack.pow7.com/announce\r\n\r\nhttp://bt.henbt.com:2710/announce\r\n\r\nhttp://bt.pusacg.org:8080/announce\r\n\r\nhttp://bt2.careland.com.cn:6969/announce\r\n\r\nhttp://explodie.org:6969/announce\r\n\r\nhttp://mgtracker.org:2710/announce\r\n\r\nhttp://mgtracker.org:6969/announce\r\n\r\nhttp://open.acgtracker.com:1096/announce\r\n\r\nhttp://open.lolicon.eu:7777/announce\r\n\r\nhttp://open.touki.ru/announce.php\r\n\r\nhttp://p4p.arenabg.ch:1337/announce\r\n\r\nhttp://p4p.arenabg.com:1337/announce\r\n\r\nhttp://pow7.com:80/announce\r\n\r\nhttp://retracker.gorcomnet.ru/announce\r\n\r\nhttp://retracker.krs-ix.ru/announce\r\n\r\nhttp://retracker.krs-ix.ru:80/announce\r\n\r\nhttp://secure.pow7.com/announce\r\n\r\nhttp://t1.pow7.com/announce\r\n\r\nhttp://t2.pow7.com/announce\r\n\r\nhttp://thetracker.org:80/announce\r\n\r\nhttp://torrent.gresille.org/announce\r\n\r\nhttp://torrentsmd.com:8080/announce\r\n\r\nhttp://tracker.aletorrenty.pl:2710/announce\r\n\r\nhttp://tracker.baravik.org:6970/announce\r\n\r\nhttp://tracker.bittor.pw:1337/announce\r\n\r\nhttp://tracker.bittorrent.am/announce\r\n\r\nhttp://tracker.calculate.ru:6969/announce\r\n\r\nhttp://tracker.dler.org:6969/announce\r\n\r\nhttp://tracker.dutchtracking.com/announce\r\n\r\nhttp://tracker.dutchtracking.com:80/announce\r\n\r\nhttp://tracker.dutchtracking.nl/announce\r\n\r\nhttp://tracker.dutchtracking.nl:80/announce\r\n\r\nhttp://tracker.edoardocolombo.eu:6969/announce\r\n\r\nhttp://tracker.ex.ua/announce\r\n\r\nhttp://tracker.ex.ua:80/announce\r\n\r\nhttp://tracker.filetracker.pl:8089/announce\r\n\r\nhttp://tracker.flashtorrents.org:6969/announce\r\n\r\nhttp://tracker.grepler.com:6969/announce\r\n\r\nhttp://tracker.internetwarriors.net:1337/announce\r\n\r\nhttp://tracker.kicks-ass.net/announce\r\n\r\nhttp://tracker.kicks-ass.net:80/announce\r\n\r\nhttp://tracker.kuroy.me:5944/announce\r\n\r\nhttp://tracker.mg64.net:6881/announce\r\n\r\nhttp://tracker.opentrackr.org:1337/announce\r\n\r\nhttp://tracker.skyts.net:6969/announce\r\n\r\nhttp://tracker.tfile.me/announce\r\n\r\nhttp://tracker.tiny-vps.com:6969/announce\r\n\r\nhttp://tracker.tvunderground.org.ru:3218/announce\r\n\r\nhttp://tracker.yoshi210.com:6969/announce\r\n\r\nhttp://tracker1.wasabii.com.tw:6969/announce\r\n\r\nhttp://tracker2.itzmx.com:6961/announce\r\n\r\nhttp://tracker2.wasabii.com.tw:6969/announce\r\n\r\nhttp://www.wareztorrent.com/announce\r\n\r\nhttp://www.wareztorrent.com:80/announce\r\n\r\nhttps://104.28.17.69/announce\r\n\r\nhttps://www.wareztorrent.com/announce\r\n\r\nudp://107.150.14.110:6969/announce\r\n\r\nudp://109.121.134.121:1337/announce\r\n\r\nudp://114.55.113.60:6969/announce\r\n\r\nudp://128.199.70.66:5944/announce\r\n\r\nudp://151.80.120.114:2710/announce\r\n\r\nudp://168.235.67.63:6969/announce\r\n\r\nudp://178.33.73.26:2710/announce\r\n\r\nudp://182.176.139.129:6969/announce\r\n\r\nudp://185.5.97.139:8089/announce\r\n\r\nudp://185.86.149.205:1337/announce\r\n\r\nudp://188.165.253.109:1337/announce\r\n\r\nudp://191.101.229.236:1337/announce\r\n\r\nudp://194.106.216.222:80/announce\r\n\r\nudp://195.123.209.37:1337/announce\r\n\r\nudp://195.123.209.40:80/announce\r\n\r\nudp://208.67.16.113:8000/announce\r\n\r\nudp://213.163.67.56:1337/announce\r\n\r\nudp://37.19.5.155:2710/announce\r\n\r\nudp://46.4.109.148:6969/announce\r\n\r\nudp://5.79.249.77:6969/announce\r\n\r\nudp://5.79.83.193:6969/announce\r\n\r\nudp://51.254.244.161:6969/announce\r\n\r\nudp://62.138.0.158:6969/announce\r\n\r\nudp://62.212.85.66:2710/announce\r\n\r\nudp://74.82.52.209:6969/announce\r\n\r\nudp://85.17.19.180:80/announce\r\n\r\nudp://89.234.156.205:80/announce\r\n\r\nudp://9.rarbg.com:2710/announce\r\n\r\nudp://9.rarbg.me:2780/announce\r\n\r\nudp://9.rarbg.to:2730/announce\r\n\r\nudp://91.218.230.81:6969/announce\r\n\r\nudp://94.23.183.33:6969/announce\r\n\r\nudp://bt.xxx-tracker.com:2710/announce\r\n\r\nudp://eddie4.nl:6969/announce\r\n\r\nudp://explodie.org:6969/announce\r\n\r\nudp://mgtracker.org:2710/announce\r\n\r\nudp://open.stealth.si:80/announce\r\n\r\nudp://p4p.arenabg.com:1337/announce\r\n\r\nudp://shadowshq.eddie4.nl:6969/announce\r\n\r\nudp://shadowshq.yi.org:6969/announce\r\n\r\nudp://torrent.gresille.org:80/announce\r\n\r\nudp://tracker.aletorrenty.pl:2710/announce\r\n\r\nudp://tracker.bittor.pw:1337/announce\r\n\r\nudp://tracker.coppersurfer.tk:6969/announce\r\n\r\nudp://tracker.eddie4.nl:6969/announce\r\n\r\nudp://tracker.ex.ua:80/announce\r\n\r\nudp://tracker.filetracker.pl:8089/announce\r\n\r\nudp://tracker.flashtorrents.org:6969/announce\r\n\r\nudp://tracker.grepler.com:6969/announce\r\n\r\nudp://tracker.ilibr.org:80/announce\r\n\r\nudp://tracker.internetwarriors.net:1337/announce\r\n\r\nudp://tracker.kicks-ass.net:80/announce\r\n\r\nudp://tracker.kuroy.me:5944/announce\r\n\r\nudp://tracker.leechers-paradise.org:6969/announce\r\n\r\nudp://tracker.mg64.net:2710/announce\r\n\r\nudp://tracker.mg64.net:6969/announce\r\n\r\nudp://tracker.opentrackr.org:1337/announce\r\n\r\nudp://tracker.piratepublic.com:1337/announce\r\n\r\nudp://tracker.sktorrent.net:6969/announce\r\n\r\nudp://tracker.skyts.net:6969/announce\r\n\r\nudp://tracker.tiny-vps.com:6969/announce\r\n\r\nudp://tracker.yoshi210.com:6969/announce\r\n\r\nudp://tracker2.indowebster.com:6969/announce\r\n\r\nudp://tracker4.piratux.com:6969/announce\r\n\r\nudp://zer0day.ch:1337/announce\r\n\r\nudp://zer0day.to:1337/announce', 1715669674),
(196, 'text_title', 'Watch {title} - {siteName}', 1715669674),
(197, 'text_loading', 'Please wait...', 1715669674),
(198, 'text_download', 'Download {title}', 1715669674),
(199, 'text_resume', 'Welcome back! You left off at hh:mm:ss. Would you like to resume watching?', 1715669674),
(200, 'text_resume_yes', 'Yes, Please', 1715669674),
(201, 'text_resume_no', 'No, Thanks', 1715669674),
(202, 'text_rewind', 'Rewind 10 Seconds', 1715669674),
(203, 'text_forward', 'Forward 10 Seconds', 1715669674),
(204, 'slug_embed', 'embed', 1715669674),
(205, 'slug_download', 'download', 1715669674),
(206, 'slug_request', 'embed2', 1715669674),
(207, 'pause_on_left', '', 1715669674),
(208, 'hide_hostname', '', 1715669674),
(211, 'SECURE_SALT', 'kbdX-=', 1714562126),
(212, 'anti_captcha', '', 1715671305),
(213, 'main_site', 'https://player.ksalsocial.online/', 1715671305),
(214, 'timezone', 'UTC', 1715671305),
(215, 'cache_instance', '', 1715671305),
(216, 'production_mode', 'true', 1715671305),
(217, 'load_balancer_rand', 'true', 1715671305),
(218, 'gdrive_copy', '', 1715671305),
(219, 'gdrive_copy_all', '', 1715671305),
(220, 'visit_counter', '10', 1715671305),
(221, 'visit_counter_runtime', '', 1715671305),
(222, 'maxmind_license_key', '', 1715671305),
(223, 'google_analytics_id', '', 1715671305),
(224, 'google_tag_manager', '', 1715671305),
(225, 'histats_id', '', 1715671305),
(226, 'recaptcha_site_key', '', 1715671305),
(227, 'recaptcha_secret_key', '', 1715671305),
(228, 'disqus_shortname', '', 1715671305),
(229, 'chat_widget', '', 1715671305),
(230, 'uptobox_api', '', 1715671305),
(231, 'disable_validation', '', 1715671305),
(232, 'disable_video_cache', '', 1715671305),
(233, 'bypass_host', '[\"anonfile\",\"bayfiles\",\"cloudvideo\",\"daddyhd\",\"dailymotion\",\"dropbox\",\"ecast123\",\"facebook\",\"fembed\",\"filecm\",\"filemoon\",\"filerio\",\"filesim\",\"gdrive\",\"gocast2\",\"gofile\",\"gomunime\",\"mediafire\",\"mixdropto\",\"mp4upload\",\"mstream\",\"mymailru\",\"okru\",\"onedrive\",\"pcloud\",\"racaty\",\"sendvid\",\"solidfiles\",\"streamlare\",\"supervideo\",\"tiktok\",\"uploadbuzz\",\"uploadsmobi\",\"upstream\",\"uptobox\",\"uqload\",\"vidio\",\"vidoza\",\"viu\",\"vk\",\"voe\",\"vudeo\",\"yadisk\",\"yourupload\",\"youtube\",\"zippyshare\"]', 1714562874),
(234, 'disable_vast_ads', '', 1715668928),
(235, 'block_adblocker', '', 1715668928),
(236, 'vast_client', 'googima', 1715668928),
(237, 'vast_offset', '', 1715668928),
(238, 'vast_xml', '', 1715668928),
(239, 'vast_skip', '', 1715668928),
(240, 'disable_banner_ads', '', 1715668928),
(241, 'dl_banner_top', '', 1715668928),
(242, 'dl_banner_bottom', '', 1715668928),
(243, 'sh_banner_top', '', 1715668928),
(244, 'sh_banner_bottom', '', 1715668928),
(245, 'disable_direct_ads', '', 1715668928),
(246, 'direct_ads_link', '', 1715668928),
(247, 'visitads_onplay', '', 1715668928),
(248, 'disable_popup_ads', '', 1715668928),
(249, 'popup_ads_link', '', 1715668928),
(250, 'popup_ads_code', '', 1715668928),
(251, 'disable_shortener_link', 'true', 1715218882),
(252, 'main_url_shortener', '', 1715218882),
(253, 'additional_url_shortener', 'clk.sh', 1715218882),
(254, 'additional_url_shortener_random', '', 1715218882),
(255, 'additional_url_shortener_adf.ly', '', 1715218882),
(256, 'additional_url_shortener_adtival.network', '', 1715218882),
(257, 'additional_url_shortener_clk.sh', '8fd966f18f5e8da313a8ee5938d221f87f2b1762', 1715218883),
(258, 'additional_url_shortener_cutpaid.com', '', 1715218883),
(259, 'additional_url_shortener_ouo.io', '', 1715218883),
(260, 'additional_url_shortener_shrinkads.com', '', 1715218883),
(261, 'additional_url_shortener_safelinku.com', '', 1715218883),
(262, 'additional_url_shortener_wi.cr', '', 1715218883),
(263, 'additional_url_shortener_ylinkz.com', '', 1715218883),
(264, 'site_name', 'KSAL PLAYER', 1715220250),
(265, 'site_slogan', 'KSAL PLAYER', 1715220250),
(266, 'site_description', 'KSAL PLAYER', 1715220250),
(267, 'favicon', '', 1715220250),
(268, 'custom_color', '673ab7', 1715220250),
(269, 'custom_color2', '3f51b5', 1715220250),
(270, 'pwa_shortname', 'KSAL PLAYER', 1715220250),
(271, 'pwa_themecolor', 'b70007', 1715220250),
(272, 'pwa_backgroundcolor', 'ffffff', 1715220250),
(273, 'pwa_display', 'fullscreen', 1715220250);

-- --------------------------------------------------------

--
-- Table structure for table `tb_stats`
--

CREATE TABLE `tb_stats` (
  `id` bigint(20) NOT NULL,
  `vid` bigint(20) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `ua` text NOT NULL,
  `created` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_stats_recap`
--

CREATE TABLE `tb_stats_recap` (
  `id` bigint(20) NOT NULL,
  `date` int(15) NOT NULL DEFAULT 0,
  `value` int(15) NOT NULL DEFAULT 0,
  `uid` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_subtitles`
--

CREATE TABLE `tb_subtitles` (
  `id` int(11) NOT NULL,
  `language` varchar(25) NOT NULL,
  `link` text NOT NULL,
  `vid` int(11) NOT NULL,
  `added` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `order` int(5) NOT NULL DEFAULT 0,
  `updated` int(15) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_subtitle_manager`
--

CREATE TABLE `tb_subtitle_manager` (
  `id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_size` int(11) NOT NULL,
  `file_type` varchar(25) NOT NULL,
  `language` varchar(50) NOT NULL,
  `added` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `host` varchar(255) NOT NULL,
  `updated` int(15) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_users`
--

CREATE TABLE `tb_users` (
  `id` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(500) NOT NULL,
  `name` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `added` int(11) NOT NULL,
  `updated` int(15) NOT NULL DEFAULT 0,
  `role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_users`
--

INSERT INTO `tb_users` (`id`, `user`, `email`, `password`, `name`, `status`, `added`, `updated`, `role`) VALUES
(1, 'admin', 'admin@gdplayer.top', '$2y$10$CmeA6fPZckFBp2pnZlpPIOs8KSFxAC.BQtjImAPBTBu6m4D.qfWzm', 'Admin', 1, 0, 1715671667, 0),
(2, 'demo', 'demo@gdplayer.top', '$2y$10$CmeA6fPZckFBp2pnZlpPIOs8KSFxAC.BQtjImAPBTBu6m4D.qfWzm', 'Demo', 1, 0, 1630917289, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_videos`
--

CREATE TABLE `tb_videos` (
  `id` int(11) NOT NULL,
  `title` varchar(1000) NOT NULL,
  `host` varchar(50) NOT NULL,
  `host_id` varchar(1500) NOT NULL,
  `uid` int(11) NOT NULL,
  `added` int(11) NOT NULL,
  `updated` int(11) NOT NULL,
  `poster` text NOT NULL,
  `status` int(1) NOT NULL DEFAULT 0,
  `views` int(11) NOT NULL DEFAULT 0,
  `dmca` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_videos_alternatives`
--

CREATE TABLE `tb_videos_alternatives` (
  `id` bigint(20) NOT NULL,
  `vid` bigint(20) NOT NULL,
  `host` varchar(50) NOT NULL,
  `host_id` varchar(1500) NOT NULL,
  `order` int(5) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_videos_hash`
--

CREATE TABLE `tb_videos_hash` (
  `id` bigint(20) NOT NULL,
  `host` varchar(50) NOT NULL,
  `host_id` varchar(1500) NOT NULL,
  `gdrive_email` varchar(250) NOT NULL,
  `data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_videos_short`
--

CREATE TABLE `tb_videos_short` (
  `id` int(11) NOT NULL,
  `key` varchar(50) NOT NULL,
  `vid` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_videos_sources`
--

CREATE TABLE `tb_videos_sources` (
  `id` bigint(20) NOT NULL,
  `host` varchar(50) NOT NULL,
  `host_id` varchar(1500) NOT NULL,
  `data` text NOT NULL,
  `dl` tinyint(1) NOT NULL DEFAULT 0,
  `sid` int(11) NOT NULL DEFAULT 0,
  `created` int(11) NOT NULL DEFAULT 0,
  `expired` int(11) NOT NULL DEFAULT 0,
  `validator_type` varchar(50) NOT NULL,
  `validator` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_gdrive_auth`
--
ALTER TABLE `tb_gdrive_auth`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tb_gdrive_mirrors`
--
ALTER TABLE `tb_gdrive_mirrors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mirror_id` (`mirror_id`),
  ADD KEY `gdrive_id` (`gdrive_id`);

--
-- Indexes for table `tb_gdrive_queue`
--
ALTER TABLE `tb_gdrive_queue`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `gdrive_id` (`gdrive_id`),
  ADD UNIQUE KEY `gdrive_id_2` (`gdrive_id`);

--
-- Indexes for table `tb_loadbalancers`
--
ALTER TABLE `tb_loadbalancers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_plugins`
--
ALTER TABLE `tb_plugins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key` (`key`);

--
-- Indexes for table `tb_sessions`
--
ALTER TABLE `tb_sessions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_settings`
--
ALTER TABLE `tb_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_stats`
--
ALTER TABLE `tb_stats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_stats_recap`
--
ALTER TABLE `tb_stats_recap`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_subtitles`
--
ALTER TABLE `tb_subtitles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_subtitle_manager`
--
ALTER TABLE `tb_subtitle_manager`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `tb_subtitle_manager` ADD FULLTEXT KEY `file_name` (`file_name`);

--
-- Indexes for table `tb_users`
--
ALTER TABLE `tb_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user` (`user`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tb_videos`
--
ALTER TABLE `tb_videos`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `tb_videos` ADD FULLTEXT KEY `title` (`title`);

--
-- Indexes for table `tb_videos_alternatives`
--
ALTER TABLE `tb_videos_alternatives`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_videos_hash`
--
ALTER TABLE `tb_videos_hash`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_videos_short`
--
ALTER TABLE `tb_videos_short`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key` (`key`);

--
-- Indexes for table `tb_videos_sources`
--
ALTER TABLE `tb_videos_sources`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_gdrive_auth`
--
ALTER TABLE `tb_gdrive_auth`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tb_gdrive_mirrors`
--
ALTER TABLE `tb_gdrive_mirrors`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=209;

--
-- AUTO_INCREMENT for table `tb_gdrive_queue`
--
ALTER TABLE `tb_gdrive_queue`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_loadbalancers`
--
ALTER TABLE `tb_loadbalancers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_plugins`
--
ALTER TABLE `tb_plugins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_sessions`
--
ALTER TABLE `tb_sessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tb_settings`
--
ALTER TABLE `tb_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=274;

--
-- AUTO_INCREMENT for table `tb_stats`
--
ALTER TABLE `tb_stats`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1855147;

--
-- AUTO_INCREMENT for table `tb_stats_recap`
--
ALTER TABLE `tb_stats_recap`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_subtitles`
--
ALTER TABLE `tb_subtitles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_subtitle_manager`
--
ALTER TABLE `tb_subtitle_manager`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tb_users`
--
ALTER TABLE `tb_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_videos`
--
ALTER TABLE `tb_videos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_videos_alternatives`
--
ALTER TABLE `tb_videos_alternatives`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_videos_hash`
--
ALTER TABLE `tb_videos_hash`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127619;

--
-- AUTO_INCREMENT for table `tb_videos_short`
--
ALTER TABLE `tb_videos_short`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_videos_sources`
--
ALTER TABLE `tb_videos_sources`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
