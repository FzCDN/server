export async function fetchLastUpdate(page: number = 1) {
  const apiKey = "sigit"
  const url = page === 1
    ? "https://baca02.manhwadesu.co.in"
    : `https://baca02.manhwadesu.co.in/komik/page/${page}`
  const apiUrl = `https://api-v2.agcprojects.com/api/v2/manga/list?type=mangareader&apikey=${apiKey}&url=${encodeURIComponent(url)}`

  try {
    const response = await fetch(apiUrl, { 
      next: { revalidate: 3600 },
      headers: {
        'Accept': 'application/json'
      }
    })
    
    if (!response.ok) {
      throw new Error(`Failed to fetch manga data: ${response.status}`)
    }
    
    const data = await response.json()
    return data.result
  } catch (error) {
    console.error('Error fetching manga data:', error)
    return []
  }
}

export async function fetchPopular() {
  const allItems = await fetchLastUpdate()
  const shuffled = allItems.sort(() => 0.5 - Math.random())
  return shuffled.slice(0, 10)
}

export async function fetchFeaturedItems() {
  const allItems = await fetchLastUpdate()
  const shuffled = allItems.sort(() => 0.5 - Math.random())
  return shuffled.slice(0, 5)
}

