export function extractSlug(url: string): string {
  // Extract the last part after /komik/
  const match = url.match(/\/komik\/([^\/]+)/);
  return match ? match[1] : '';
}

export function createSeriesUrl(slug: string): string {
  return `/series/${slug}`;
}

