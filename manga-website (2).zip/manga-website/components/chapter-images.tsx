"use client"

import { useEffect, useRef, useState } from 'react'
import { AutoScroll } from '@/components/auto-scroll'
import { Loader2 } from 'lucide-react'

interface ChapterImage {
  index: number
  download_url: string
}

interface ChapterImagesProps {
  images: ChapterImage[]
  title: string
  chapter: string
}

export function ChapterImages({ images, title, chapter }: ChapterImagesProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [isScrolling, setIsScrolling] = useState(false)
  const [scrollSpeed, setScrollSpeed] = useState(5)
  const [loadedImages, setLoadedImages] = useState<Set<number>>(new Set())

  const handleImageLoad = (index: number) => {
    setLoadedImages(prev => new Set(prev).add(index))
  }

  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    const preventDefault = (e: Event) => e.preventDefault()

    const disableRightClick = (e: MouseEvent) => {
      e.preventDefault()
      alert('Right-clicking is disabled')
    }

    container.addEventListener('contextmenu', preventDefault)
    container.addEventListener('mousedown', preventDefault)
    container.addEventListener('mouseup', preventDefault)
    container.addEventListener('contextmenu', disableRightClick)

    return () => {
      container.removeEventListener('contextmenu', preventDefault)
      container.removeEventListener('mousedown', preventDefault)
      container.removeEventListener('mouseup', preventDefault)
      container.removeEventListener('contextmenu', disableRightClick)
    }
  }, [])

  useEffect(() => {
    let animationFrameId: number

    const scroll = () => {
      if (isScrolling) {
        window.scrollBy(0, scrollSpeed)
        animationFrameId = requestAnimationFrame(scroll)
      }
    }

    if (isScrolling) {
      animationFrameId = requestAnimationFrame(scroll)
    }

    return () => {
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId)
      }
    }
  }, [isScrolling, scrollSpeed])

  return (
    <>
      <div className="bg-black/80 backdrop-blur-sm p-4 mb-4 rounded-lg text-center">
        <h1 className="text-2xl font-bold text-white mb-2">{title}</h1>
        <h2 className="text-xl text-gray-300">Chapter {chapter}</h2>
      </div>
      <div ref={containerRef} className="space-y-4 select-none">
        {images.map((image) => (
          <div key={image.index} className="w-full relative">
            {!loadedImages.has(image.index) && (
              <div className="absolute inset-0 flex items-center justify-center bg-zinc-800">
                <Loader2 className="w-8 h-8 animate-spin text-white" />
              </div>
            )}
            <img
              src={image.download_url}
              alt={`Page ${image.index}`}
              className="w-full h-auto pointer-events-none"
              loading={image.index === 1 ? 'eager' : 'lazy'}
              style={{ WebkitUserSelect: 'none', userSelect: 'none' }}
              onDragStart={(e) => e.preventDefault()}
              onLoad={() => handleImageLoad(image.index)}
            />
          </div>
        ))}
      </div>
      <AutoScroll
        isScrolling={isScrolling}
        setIsScrolling={setIsScrolling}
        scrollSpeed={scrollSpeed}
        setScrollSpeed={setScrollSpeed}
      />
    </>
  )
}

export function ChapterImagesSkeleton() {
  return (
    <div className="space-y-4">
      <div className="bg-zinc-800 p-4 mb-4 rounded-lg">
        <div className="h-8 w-3/4 bg-zinc-700 rounded mb-2"></div>
        <div className="h-6 w-1/2 bg-zinc-700 rounded"></div>
      </div>
      {[...Array(5)].map((_, index) => (
        <div key={index} className="w-full h-[600px] bg-zinc-800 animate-pulse" />
      ))}
    </div>
  )
}

