"use client"

import Link from "next/link"
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface PaginationProps {
  currentPage: number
  totalPages?: number
}

export function Pagination({ currentPage, totalPages = 999 }: PaginationProps) {
  return (
    <div className="flex items-center justify-center gap-2">
      <Button
        variant="ghost"
        size="icon"
        className={cn(
          "h-8 w-8 rounded-lg bg-zinc-900/90",
          currentPage === 1 && "opacity-50 cursor-not-allowed"
        )}
        asChild={currentPage !== 1}
        disabled={currentPage === 1}
      >
        {currentPage === 1 ? (
          <div>
            <ChevronLeft className="h-4 w-4" />
          </div>
        ) : (
          <Link prefetch href={currentPage === 2 ? "/" : `/page/${currentPage - 1}`}>
            <ChevronLeft className="h-4 w-4" />
          </Link>
        )}
      </Button>
      
      <div className="min-w-8 px-3 h-8 flex items-center justify-center rounded-lg bg-zinc-900/90 text-sm">
        {currentPage}
      </div>

      <Button
        variant="ghost"
        size="icon"
        className="h-8 w-8 rounded-lg bg-zinc-900/90"
        asChild
      >
        <Link prefetch href={`/page/${currentPage + 1}`}>
          <ChevronRight className="h-4 w-4" />
        </Link>
      </Button>
    </div>
  )
}

