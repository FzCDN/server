"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { MangaGridSkeleton } from "@/components/skeleton/manga-grid-skeleton"
import { extractSlug, createSeriesUrl } from "@/utils/url"

function truncateTitle(title: string, maxLength: number = 18): string {
  return title.length > maxLength ? title.slice(0, maxLength) + '...' : title;
}

interface MangaItem {
  title: string
  image: string
  link: string
  total_chapter: string
}

interface MangaGridProps {
  items: MangaItem[]
}

export function MangaGrid({ items }: MangaGridProps) {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    setIsLoading(false)
  }, [items])

  if (isLoading) {
    return <MangaGridSkeleton />
  }

  if (!items || items.length === 0) {
    return <div className="text-center text-white">No manga items found.</div>
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
      {items.map((manga, index) => (
        <div key={index} className="group relative flex flex-col">
          <Link prefetch href={createSeriesUrl(extractSlug(manga.link))} className="flex flex-col gap-2">
            <div className="relative aspect-[3/4] overflow-hidden rounded-lg">
              <Image
                src={manga.image}
                alt={manga.title}
                fill
                className="object-cover transition-transform group-hover:scale-105"
                sizes="(max-width: 768px) 50vw, (max-width: 1200px) 33vw, 25vw"
              />
              <div className="absolute bottom-2 right-2">
                <Button 
                  variant="secondary" 
                  size="sm" 
                  className="text-xs px-2 py-1 bg-black/50 hover:bg-black/70 text-white backdrop-blur-sm"
                >
                  {manga.total_chapter}
                </Button>
              </div>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="h-2 w-2 flex-shrink-0 rounded-full bg-[#09CE6B]" />
                <h3 className="font-medium text-sm text-white truncate">
                  {truncateTitle(manga.title)}
                </h3>
              </div>
            </div>
          </Link>
        </div>
      ))}
    </div>
  )
}

