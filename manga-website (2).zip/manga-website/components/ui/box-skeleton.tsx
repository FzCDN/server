import { cn } from "@/lib/utils"

interface BoxSkeletonProps extends React.HTMLAttributes<HTMLDivElement> {
  className?: string
}

export function BoxSkeleton({ className, ...props }: BoxSkeletonProps) {
  return (
    <div
      className={cn("animate-pulse bg-zinc-800 rounded-md", className)}
      {...props}
    />
  )
}

