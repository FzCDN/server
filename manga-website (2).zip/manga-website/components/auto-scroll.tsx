"use client"

import { useState, useEffect, useRef } from 'react'
import { Pause, Play, ChevronUp, ChevronDown, Settings } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { cn } from "@/lib/utils"

interface AutoScrollProps {
  isScrolling: boolean
  setIsScrolling: (isScrolling: boolean) => void
  scrollSpeed: number
  setScrollSpeed: (speed: number) => void
}

export function AutoScroll({ isScrolling, setIsScrolling, scrollSpeed, setScrollSpeed }: AutoScrollProps) {
  const [isOpen, setIsOpen] = useState(false)
  const controlsRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (controlsRef.current && !controlsRef.current.contains(event.target as Node)) {
        setIsOpen(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [])

  return (
    <div className="fixed right-4 top-1/2 transform -translate-y-1/2">
      <Button
        variant="outline"
        size="icon"
        onClick={() => setIsOpen(!isOpen)}
        className="w-10 h-10 bg-zinc-800 text-white hover:bg-zinc-700"
      >
        <Settings className="h-4 w-4" />
      </Button>
      <div
        ref={controlsRef}
        className={cn(
          "absolute right-12 top-1/2 transform -translate-y-1/2 bg-zinc-800 p-4 rounded-lg shadow-lg transition-all duration-300 ease-in-out",
          isOpen ? "opacity-100 translate-x-0" : "opacity-0 translate-x-full pointer-events-none"
        )}
      >
        <div className="flex flex-col items-center space-y-4">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setIsScrolling(!isScrolling)}
            className="w-10 h-10"
          >
            {isScrolling ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          </Button>
          <div className="flex flex-col items-center space-y-2">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setScrollSpeed(Math.min(scrollSpeed + 1, 20))}
              className="w-8 h-8"
            >
              <ChevronUp className="h-4 w-4" />
            </Button>
            <span className="text-white text-sm">{scrollSpeed}</span>
            <Button
              variant="outline"
              size="icon"
              onClick={() => setScrollSpeed(Math.max(scrollSpeed - 1, 5))}
              className="w-8 h-8"
            >
              <ChevronDown className="h-4 w-4" />
            </Button>
          </div>
          <Slider
            min={5}
            max={20}
            step={1}
            value={[scrollSpeed]}
            onValueChange={(value) => setScrollSpeed(value[0])}
            orientation="vertical"
            className="h-24"
          />
        </div>
      </div>
    </div>
  )
}

