"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Search, Sun, Archive, User, MoreVertical } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { cn } from "@/lib/utils"

export function SiteHeader() {
  const [isSearchOpen, setIsSearchOpen] = useState(false)

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-black/95 backdrop-blur supports-[backdrop-filter]:bg-black/60">
        <div className="container flex h-14 max-w-screen-2xl items-center">
          <div className="flex flex-1 items-center justify-between">
            <div className="w-[200px]">
              <Link 
                href="/" 
                className="block"
              >
                <Image
                  src="https://imgkub.com/images/2024/12/05/1000015802.png"
                  alt="MANHWADESU"
                  width={200}
                  height={40}
                  className="w-auto h-8"
                  priority
                />
              </Link>
            </div>

            <div className="flex items-center gap-2">
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-10 w-10 rounded-lg bg-zinc-900 text-muted-foreground hover:text-white"
                onClick={() => setIsSearchOpen(!isSearchOpen)}
              >
                <Search className="h-5 w-5" />
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-10 w-10 rounded-lg bg-zinc-900 text-muted-foreground hover:text-white"
              >
                <Sun className="h-5 w-5" />
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-10 w-10 rounded-lg bg-zinc-900 text-muted-foreground hover:text-white"
                  >
                    <MoreVertical className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56 bg-zinc-900 text-white">
                  <DropdownMenuItem className="flex items-center gap-2">
                    <Archive className="h-4 w-4" />
                    <span>Archive</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="flex items-center gap-2">
                    <User className="h-4 w-4" />
                    <span>Profile</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </header>

      <div 
        className={cn(
          "fixed inset-x-0 top-14 z-40 transform overflow-hidden bg-zinc-900/95 backdrop-blur transition-all duration-300 ease-in-out",
          isSearchOpen ? "h-16 border-b border-border/40" : "h-0"
        )}
      >
        <div className="container h-full py-3">
          <div className="relative flex items-center">
            <Search className="absolute left-3 h-5 w-5 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search Anime"
              className="h-10 w-full bg-black/50 pl-10 text-sm text-white placeholder:text-muted-foreground focus-visible:ring-0 focus-visible:ring-offset-0"
            />
          </div>
        </div>
      </div>
    </>
  )
}

