import { MangaGrid } from "@/components/manga-grid"
import { SiteHeader } from "@/components/site-header"
import { FeaturedSlider } from "@/components/featured-slider"
import { Popular } from "@/components/popular"
import { Pagination } from "@/components/pagination"
import { fetchLastUpdate, fetchPopular, fetchFeaturedItems } from "@/utils/api"

export default async function Home() {
  const mangaItems = await fetchLastUpdate(1)
  const popularItems = await fetchPopular()
  const featuredItems = await fetchFeaturedItems()

  return (
    <div className="min-h-screen bg-black">
      <SiteHeader />
      <div className="container mx-auto py-6 space-y-8">
        <FeaturedSlider items={featuredItems} />
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_300px] gap-8">
          <div className="space-y-6">
            <MangaGrid items={mangaItems} />
            <Pagination currentPage={1} />
          </div>
          <Popular items={popularItems} />
        </div>
      </div>
    </div>
  )
}

