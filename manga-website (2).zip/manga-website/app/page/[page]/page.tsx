import { notFound } from "next/navigation"
import { MangaGrid } from "@/components/manga-grid"
import { SiteHeader } from "@/components/site-header"
import { Popular } from "@/components/popular"
import { Pagination } from "@/components/pagination"
import { fetchLastUpdate, fetchPopular } from "@/utils/api"

interface PageProps {
  params: {
    page: string
  }
}

export default async function Page({ params }: PageProps) {
  const page = parseInt(params.page)

  if (isNaN(page) || page <= 1) {
    notFound()
  }

  const mangaItems = await fetchLastUpdate(page)
  const popularItems = await fetchPopular()

  return (
    <div className="min-h-screen bg-black">
      <SiteHeader />
      <div className="container mx-auto py-6 space-y-8">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_300px] gap-8">
          <div className="space-y-6">
            <MangaGrid items={mangaItems} />
            <Pagination currentPage={page} />
          </div>
          <Popular items={popularItems} />
        </div>
      </div>
    </div>
  )
}

