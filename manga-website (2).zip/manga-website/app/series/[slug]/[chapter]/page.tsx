import { Suspense } from 'react'
import { notFound } from "next/navigation"
import { SiteHeader } from "@/components/site-header"
import { ChapterImages, ChapterImagesSkeleton } from "@/components/chapter-images"

async function getChapterImages(slug: string, chapter: string) {
  const apiKey = "sigit"
  const url = `https://api-v2.agcprojects.com/api/v2/manga/chapter?type=mangareader&apikey=${apiKey}&url=https://manhwadesu.asia/${slug}-${chapter}/`

  const res = await fetch(url, { next: { revalidate: 3600 } })

  if (!res.ok) {
    throw new Error('Failed to fetch chapter images')
  }

  const data = await res.json()
  return data.result
}

interface ChapterContentProps {
  slug: string
  chapter: string
}

async function ChapterContent({ slug, chapter }: ChapterContentProps) {
  let chapterImages
  try {
    chapterImages = await getChapterImages(slug, chapter)
  } catch (error) {
    console.error("Error fetching chapter images:", error)
    notFound()
  }

  // Replace hyphens with spaces and capitalize each word for the title
  const title = slug.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')

  // Remove 'chapter-' from the chapter parameter
  const chapterNumber = chapter.replace('chapter-', '')

  return <ChapterImages images={chapterImages} title={title} chapter={chapterNumber} />
}

export default function ChapterPage({ params }: { params: { slug: string, chapter: string } }) {
  return (
    <div className="min-h-screen bg-black">
      <SiteHeader />
      <main className="container max-w-4xl py-6">
        <Suspense fallback={<ChapterImagesSkeleton />}>
          <ChapterContent slug={params.slug} chapter={params.chapter} />
        </Suspense>
      </main>
    </div>
  )
}

