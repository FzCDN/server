import { Suspense } from "react"
import { SeriesContent } from "@/components/series-content"
import { SeriesSkeleton } from "@/components/skeleton/series-skeleton"
import { SiteHeader } from "@/components/site-header"

export default function SeriesPage({ params }: { params: { slug: string } }) {
  return (
    <div className="min-h-screen bg-black">
      <SiteHeader />
      <main className="container max-w-4xl py-6">
        <Suspense fallback={<SeriesSkeleton />}>
          <SeriesContent slug={params.slug} />
        </Suspense>
      </main>
    </div>
  )
}

