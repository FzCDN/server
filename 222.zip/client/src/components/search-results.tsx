import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Star } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import type { SearchResponse, MangaDetail } from "@shared/schema";

interface SearchResultsProps {
  searchQuery: string;
  onMangaSelect: (manga: MangaDetail) => void;
}

export default function SearchResults({ searchQuery, onMangaSelect }: SearchResultsProps) {
  const [currentPage, setCurrentPage] = useState(1);
  const [, setLocation] = useLocation();

  // Scroll to top when page changes
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const { data: searchResults, isLoading, error } = useQuery<SearchResponse>({
    queryKey: [`/api/search/${searchQuery}`, currentPage],
    queryFn: async () => {
      const response = await fetch(`/api/search/${searchQuery}?page=${currentPage}`);
      if (!response.ok) {
        throw new Error('Failed to fetch search results');
      }
      return response.json();
    },
    enabled: !!searchQuery && searchQuery.length >= 2,
  });

  const handleMangaClick = (mangaId: string) => {
    setLocation(`/download/${mangaId}`);
  };

  if (isLoading) {
    return (
      <div className="mb-8 animate-fade-in">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">Search Results</h3>
          <Skeleton className="h-4 w-24" />
        </div>
        
        <div className="space-y-3">
          {Array.from({ length: 8 }).map((_, i) => (
            <Card key={i} className="overflow-hidden">
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <Skeleton className="w-16 h-20 flex-shrink-0 rounded" />
                  <div className="flex-1 min-w-0">
                    <Skeleton className="h-5 w-3/4 mb-2" />
                    <Skeleton className="h-3 w-24 mb-2" />
                    <Skeleton className="h-3 w-32" />
                  </div>
                  <div className="flex-shrink-0">
                    <Skeleton className="h-4 w-12" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="mb-8 text-center py-8">
        <p className="text-red-600">Failed to load search results. Please try again.</p>
      </div>
    );
  }

  if (!searchResults || searchResults.mangaList.length === 0) {
    return (
      <div className="mb-8 text-center py-8">
        <p className="text-gray-600">No manga found for "{searchQuery}". Try a different search term.</p>
      </div>
    );
  }

  return (
    <div className="mb-8 animate-fade-in">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">Search Results</h3>
        <div className="text-sm text-gray-500">
          {searchResults.mangaList.length} results found
        </div>
      </div>
      
      <div className="space-y-3">
        {searchResults.mangaList.map((manga) => (
          <Card 
            key={manga.id}
            className="overflow-hidden hover:shadow-md hover:bg-gray-50 transition-all duration-200 cursor-pointer"
            onClick={() => handleMangaClick(manga.id)}
          >
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-20 flex-shrink-0 relative">
                  <img 
                    src={manga.imageUrl}
                    alt={manga.imageAlt}
                    className="w-full h-full object-cover rounded shadow-sm"
                    loading="lazy"
                  />
                </div>
                
                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold text-gray-900 mb-1 truncate text-lg">{manga.title}</h4>
                  <p className="text-sm text-gray-600 mb-1">{manga.chapter}</p>
                  <div className="flex items-center gap-2 text-xs text-gray-500">
                    <span className="bg-gray-100 px-2 py-1 rounded">{manga.type}</span>
                    <span className="bg-gray-100 px-2 py-1 rounded">{manga.status}</span>
                  </div>
                </div>
                
                <div className="flex-shrink-0 text-right">
                  <div className="flex items-center gap-1 text-sm text-gray-600 mb-1">
                    <Star size={14} fill="currentColor" className="text-yellow-500" />
                    {manga.rating}
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="text-xs"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleMangaClick(manga.id);
                    }}
                  >
                    View Details
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Pagination */}
      {searchResults.pagination.totalPages > 1 && (
        <div className="flex justify-center mt-8">
          <nav className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => handlePageChange(Math.max(1, currentPage - 1))}
              disabled={!searchResults.pagination.previousPage}
            >
              <ChevronLeft size={16} />
            </Button>
            
            {/* Page numbers */}
            {Array.from({ length: Math.min(5, searchResults.pagination.totalPages) }, (_, i) => {
              const pageNum = i + 1;
              const isActive = pageNum === searchResults.pagination.currentPage;
              
              return (
                <Button
                  key={pageNum}
                  variant={isActive ? "default" : "outline"}
                  size="sm"
                  onClick={() => handlePageChange(pageNum)}
                  className={isActive ? "bg-primary text-primary-foreground" : ""}
                >
                  {pageNum}
                </Button>
              );
            })}
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={!searchResults.pagination.nextPage}
            >
              <ChevronRight size={16} />
            </Button>
          </nav>
        </div>
      )}
    </div>
  );
}
