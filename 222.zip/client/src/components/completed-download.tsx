import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, Download, Share, RotateCcw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface CompletedDownloadProps {
  downloadId: number;
  onNewDownload: () => void;
}

export default function CompletedDownload({ downloadId, onNewDownload }: CompletedDownloadProps) {
  const downloadUrl = `/api/download/${downloadId}/file`;
  const { toast } = useToast();

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Manga Download',
        text: 'Check out this manga download!',
        url: downloadUrl,
      }).catch(console.error);
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(window.location.href).then(() => {
        toast({
          title: "Link copied",
          description: "Download link copied to clipboard!",
        });
      });
    }
  };

  return (
    <div className="mb-8 animate-fade-in">
      <Card>
        <CardContent className="p-6">
          <div className="text-center">
            <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="text-white" size={32} />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Download Completed!</h3>
            <p className="text-gray-600 mb-6">
              Your manga chapters have been successfully converted to PDF and compressed into a ZIP file.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button 
                className="inline-flex items-center"
                onClick={() => window.open(downloadUrl, '_blank')}
              >
                <Download className="mr-2" size={16} />
                Download ZIP File
              </Button>
              <Button 
                variant="outline"
                onClick={handleShare}
                className="inline-flex items-center"
              >
                <Share className="mr-2" size={16} />
                Share Link
              </Button>
              <Button 
                variant="outline"
                onClick={onNewDownload}
                className="inline-flex items-center"
              >
                <RotateCcw className="mr-2" size={16} />
                New Download
              </Button>
            </div>

            <div className="mt-6 p-4 bg-gray-50 rounded-lg">
              <div className="text-sm text-gray-600 space-y-1">
                <p><strong>File size:</strong> Approximately 45-60 MB</p>
                <p><strong>Chapters:</strong> Multiple chapters included</p>
                <p><strong>Format:</strong> PDF files in ZIP archive</p>
                <p><strong>Quality:</strong> JPEG 70% compression, 1000px width</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
