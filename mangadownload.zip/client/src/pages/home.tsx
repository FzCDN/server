import { useState } from "react";
import NavigationHeader from "@/components/navigation-header";
import SearchSection from "@/components/search-section";
import SearchResults from "@/components/search-results";
import MangaDetail from "@/components/manga-detail";
import DownloadProgress from "@/components/download-progress";
import CompletedDownload from "@/components/completed-download";
import type { MangaDetail as MangaDetailType } from "@shared/schema";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedManga, setSelectedManga] = useState<MangaDetailType | null>(null);
  const [downloadId, setDownloadId] = useState<number | null>(null);
  const [downloadCompleted, setDownloadCompleted] = useState(false);
  const [completedDownloadId, setCompletedDownloadId] = useState<number | null>(null);
  const [showSearchResults, setShowSearchResults] = useState(false);

  const handleMangaSelect = (manga: MangaDetailType) => {
    console.log('Manga selected:', manga);
    setSelectedManga(manga);
    setShowSearchResults(false);
    setDownloadCompleted(false);
    setDownloadId(null);
  };

  const handleBackToSearch = () => {
    setSelectedManga(null);
    setShowSearchResults(true);
    setDownloadCompleted(false);
    setDownloadId(null);
    setCompletedDownloadId(null);
  };

  const handleBackToHomepage = () => {
    setSelectedManga(null);
    setShowSearchResults(false);
    setDownloadCompleted(false);
    setDownloadId(null);
    setCompletedDownloadId(null);
    setSearchQuery("");
  };

  const handleDownloadStart = (id: number) => {
    console.log("handleDownloadStart called with ID:", id);
    setDownloadId(id);
    setDownloadCompleted(false);
    setCompletedDownloadId(null);
  };

  const handleDownloadComplete = (completedId: number) => {
    setCompletedDownloadId(completedId);
    setDownloadCompleted(true);
    setDownloadId(null);
  };

  const handleNewSearch = (query: string) => {
    setSearchQuery(query);
    setShowSearchResults(query.length >= 2);
    setSelectedManga(null);
    setDownloadCompleted(false);
    setDownloadId(null);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavigationHeader onHomeClick={handleBackToHomepage} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <SearchSection 
          onSearch={handleNewSearch}
          initialQuery={searchQuery}
        />
        
        {showSearchResults && searchQuery && (
          <SearchResults 
            searchQuery={searchQuery}
            onMangaSelect={handleMangaSelect}
          />
        )}
        
        {selectedManga && !downloadId && !downloadCompleted && (
          <MangaDetail 
            manga={selectedManga}
            onBackToSearch={handleBackToSearch}
            onDownloadStart={handleDownloadStart}
          />
        )}
        
        {downloadId && (
          <DownloadProgress 
            downloadId={downloadId}
            onComplete={handleDownloadComplete}
            onCancel={() => setDownloadId(null)}
          />
        )}
        
        {downloadCompleted && completedDownloadId && (
          <CompletedDownload 
            downloadId={completedDownloadId}
            onNewDownload={handleBackToSearch}
          />
        )}
      </main>
    </div>
  );
}
