/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: ['imgkub.com', 'manhwadesu.asia', 'baca02.manhwadesu.co.in'],
  },
}

module.exports = nextConfig

