import { Suspense } from 'react'
import { notFound } from "next/navigation"
import { SiteHeader } from "@/components/site-header"
import { ChapterImages, ChapterImagesSkeleton } from "@/components/chapter-images"
import { getChapterData } from "@/utils/api"

interface ChapterContentProps {
  slug: string
  chapter: string
}

async function ChapterContent({ slug, chapter }: ChapterContentProps) {
  try {
    const chapterData = await getChapterData(slug, chapter)
    return <ChapterImages 
      images={chapterData.images}
      title={chapterData.title}
      chapter={chapterData.chapter}
      seriesCover={chapterData.seriesCover}
      chapterList={chapterData.chapterList}
      slug={slug}
      currentChapter={chapter}
      prevChapter={chapterData.prevChapter}
      nextChapter={chapterData.nextChapter}
    />
  } catch (error) {
    console.error("Error fetching data:", error)
    notFound()
  }
}

export default function ChapterPage({ params }: { params: { slug: string, chapter: string } }) {
  return (
    <div className="min-h-screen bg-black">
      <SiteHeader />
      <main className="container max-w-4xl py-6">
        <Suspense fallback={<ChapterImagesSkeleton />}>
          <ChapterContent slug={params.slug} chapter={params.chapter} />
        </Suspense>
      </main>
    </div>
  )
}

