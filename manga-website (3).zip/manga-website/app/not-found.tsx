import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function NotFound() {
  return (
    <div className="min-h-screen bg-black flex items-center justify-center">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold">404</h1>
        <p className="text-gray-400">Page not found</p>
        <Button asChild>
          <Link href="/page/1">Go Home</Link>
        </Button>
      </div>
    </div>
  )
}

