import { Suspense } from "react"
import { MangaGrid } from "@/components/manga-grid"
import { SiteHeader } from "@/components/site-header"
import { FeaturedSlider } from "@/components/featured-slider"
import { Popular } from "@/components/popular"
import { Pagination } from "@/components/pagination"
import { SearchContent } from "@/components/search-content"
import { fetchLastUpdate, fetchPopular, fetchFeaturedItems } from "@/utils/api"
import { BoxSkeleton } from "@/components/ui/box-skeleton"

interface HomePageProps {
  searchParams: {
    search?: string
    page?: string
  }
}

export default async function Home({ searchParams }: HomePageProps) {
  const searchQuery = searchParams.search
  const page = parseInt(searchParams.page || '1', 10)

  return (
    <div className="min-h-screen bg-black">
      <SiteHeader />
      <Suspense fallback={
        <div className="container py-6">
          <BoxSkeleton className="h-[400px] w-full" />
        </div>
      }>
        <HomeContent searchQuery={searchQuery} page={page} />
      </Suspense>
    </div>
  )
}

async function HomeContent({ 
  searchQuery, 
  page 
}: { 
  searchQuery?: string
  page: number 
}) {
  if (searchQuery) {
    return (
      <main className="container py-6">
        <SearchContent query={searchQuery} initialPage={page} />
      </main>
    )
  }

  try {
    const [mangaItems, popularItems, featuredItems] = await Promise.allSettled([
      fetchLastUpdate(page),
      fetchPopular(),
      fetchFeaturedItems()
    ])

    return (
      <div className="container mx-auto py-6 space-y-8">
        {featuredItems.status === 'fulfilled' && featuredItems.value && (
          <FeaturedSlider items={featuredItems.value} />
        )}
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_300px] gap-8">
          <div className="space-y-6">
            {mangaItems.status === 'fulfilled' && mangaItems.value && (
              <>
                <MangaGrid items={mangaItems.value} />
                <Pagination 
                  currentPage={page}
                  hasNextPage={mangaItems.value.length > 0}
                  onPrevPage={() => {}}
                  onNextPage={() => {}}
                />
              </>
            )}
          </div>
          {popularItems.status === 'fulfilled' && popularItems.value && (
            <Popular items={popularItems.value} />
          )}
        </div>
      </div>
    )
  } catch (error) {
    return (
      <div className="container mx-auto py-6">
        <div className="text-center text-white space-y-4">
          <p>Failed to load content. Please try again later.</p>
          <p className="text-sm text-gray-400">Error: {error instanceof Error ? error.message : 'Unknown error'}</p>
        </div>
      </div>
    )
  }
}

