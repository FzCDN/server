export function extractSlug(url: string): string {
  const match = url.match(/\/komik\/(.+)/);
  return match ? match[1] : '';
}

export function createSeriesUrl(slug: string): string {
  return `/series/${slug}`;
}

export function extractChapter(url: string): string {
  const match = url.match(/chapter-[^/]+/);
  return match ? match[0] : '';
}

export function createChapterUrl(mangaLink: string, chapterUrl: string): string {
  const slug = extractSlug(mangaLink);
  const chapterInfo = extractChapter(chapterUrl);
  return `/series/${slug}/${chapterInfo}`.replace('//', '/');
}

