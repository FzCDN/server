"use client"

import * as React from "react"
import Image from "next/image"
import Link from "next/link"
import { ChevronLeft, ChevronRight, Info } from 'lucide-react'
import useEmblaCarousel from "embla-carousel-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { FeaturedSliderSkeleton } from "@/components/skeleton/featured-slider-skeleton"
import { extractSlug } from "@/utils/url"

interface FeaturedItem {
  title: string
  image: string
  link: string
}

interface FeaturedSliderProps {
  items: FeaturedItem[]
}

export function FeaturedSlider({ items }: FeaturedSliderProps) {
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true })
  const [selectedIndex, setSelectedIndex] = React.useState(0)
  const [isLoading, setIsLoading] = React.useState(true)

  const scrollPrev = React.useCallback(() => {
    if (emblaApi) emblaApi.scrollPrev()
  }, [emblaApi])

  const scrollNext = React.useCallback(() => {
    if (emblaApi) emblaApi.scrollNext()
  }, [emblaApi])

  const onSelect = React.useCallback(() => {
    if (!emblaApi) return
    setSelectedIndex(emblaApi.selectedScrollSnap())
  }, [emblaApi])

  React.useEffect(() => {
    if (!emblaApi) return
    onSelect()
    emblaApi.on("select", onSelect)
    return () => {
      emblaApi.off("select", onSelect)
    }
  }, [emblaApi, onSelect])

  React.useEffect(() => {
    if (!emblaApi) return
    const intervalId = setInterval(() => {
      emblaApi.scrollNext()
    }, 5000)
    return () => clearInterval(intervalId)
  }, [emblaApi])

  React.useEffect(() => {
    setIsLoading(false)
  }, [items])

  if (isLoading) {
    return <FeaturedSliderSkeleton />
  }

  return (
    <div className="relative overflow-hidden rounded-lg">
      <div ref={emblaRef} className="overflow-hidden">
        <div className="flex">
          {items.map((item, index) => (
            <div key={index} className="relative flex-[0_0_100%]">
              <div className="relative aspect-[9/6]">
                <Image
                  src={item.image}
                  alt={item.title}
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
                <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-transparent to-transparent" />
              </div>
              <div className="absolute inset-0 flex flex-col justify-end p-6 space-y-4">
                <h2 className="text-3xl font-bold text-white">{item.title}</h2>
                <div className="flex gap-3">
                  <Button
                    variant="secondary"
                    size="sm"
                    className="bg-white/10 backdrop-blur-sm hover:bg-white/20"
                    asChild
                  >
                    <Link href={`/series/${extractSlug(item.link)}`}>
                      <Info className="mr-2 h-4 w-4" />
                      DETAILS
                    </Link>
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="absolute bottom-6 right-6 flex gap-2">
        <Button
          variant="secondary"
          size="icon"
          className="h-8 w-8 rounded-lg bg-white/10 backdrop-blur-sm hover:bg-white/20"
          onClick={scrollPrev}
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <Button
          variant="secondary"
          size="icon"
          className="h-8 w-8 rounded-lg bg-white/10 backdrop-blur-sm hover:bg-white/20"
          onClick={scrollNext}
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      <div className="absolute bottom-6 left-1/2 flex -translate-x-1/2 gap-1">
        {items.map((_, index) => (
          <div
            key={index}
            className={cn(
              "h-1.5 w-1.5 rounded-full bg-white/50",
              selectedIndex === index && "bg-white"
            )}
          />
        ))}
      </div>
    </div>
  )
}

