"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Flame } from 'lucide-react'
import { PopularSkeleton } from "@/components/skeleton/popular-skeleton"
import { extractSlug } from "@/utils/url"

interface PopularItem {
  title: string
  image: string
  link: string
  total_chapter: string
}

interface PopularProps {
  items: PopularItem[]
}

export function Popular({ items }: PopularProps) {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    setIsLoading(false)
  }, [items])

  if (isLoading) {
    return <PopularSkeleton />
  }

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold text-white flex items-center gap-2">
        <Flame className="h-5 w-5 text-red-500" />
        <span>POPULAR</span>
      </h2>
      <div className="space-y-4">
        {items.map((item, index) => (
          <Link 
            prefetch
            key={index} 
            href={`/series/${extractSlug(item.link)}`}
            className="flex gap-4 p-2 rounded-lg hover:bg-zinc-800/50 transition-colors"
          >
            <div className="relative aspect-[3/4] w-20 flex-shrink-0 overflow-hidden rounded-lg">
              <Image
                src={item.image}
                alt={item.title}
                fill
                className="object-cover"
              />
              <div className="absolute top-1 left-1">
                <Button 
                  variant="secondary" 
                  size="sm" 
                  className="w-6 h-6 p-0 text-xs bg-black/50 hover:bg-black/70 text-white backdrop-blur-sm rounded-full"
                >
                  {index + 1}
                </Button>
              </div>
            </div>
            <div className="flex-1 min-w-0 space-y-1">
              <h3 className="font-medium text-white truncate">
                {item.title}
              </h3>
              <p className="text-xs text-zinc-400">
                {item.total_chapter}
              </p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}

