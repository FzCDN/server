import { MangaGridSkeleton } from "@/components/skeleton/manga-grid-skeleton"

export function SearchSkeleton() {
  return (
    <div className="space-y-4">
      <div className="h-10 w-full max-w-sm bg-zinc-800 rounded-lg animate-pulse" />
      <MangaGridSkeleton />
    </div>
  )
}

