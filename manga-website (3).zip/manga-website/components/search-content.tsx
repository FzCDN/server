"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { MangaGrid } from "@/components/manga-grid"
import { BoxSkeleton } from "@/components/ui/box-skeleton"
import { Pagination } from "@/components/pagination"
import { Button } from "@/components/ui/button"

interface SearchContentProps {
  query: string
  initialPage: number
}

interface SearchResult {
  title: string
  image: string
  link: string
  total_chapter: string
}

export function SearchContent({ query, initialPage }: SearchContentProps) {
  const router = useRouter()
  const [results, setResults] = useState<SearchResult[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [currentPage, setCurrentPage] = useState(initialPage)
  const [hasNextPage, setHasNextPage] = useState(true)

  useEffect(() => {
    async function fetchResults() {
      setIsLoading(true)
      try {
        const response = await fetch(
          `https://api-v2.agcprojects.com/api/v2/manga/list?type=mangareader&apikey=sigit&url=${encodeURIComponent(
            `https://baca02.manhwadesu.co.in/page/${currentPage}/?s=${query}`
          )}`
        )
        const data = await response.json()
        setResults(data.result || [])
        setHasNextPage(data.result && data.result.length > 0)
      } catch (error) {
        console.error("Error fetching search results:", error)
        setResults([])
        setHasNextPage(false)
      }
      setIsLoading(false)
    }

    fetchResults()
  }, [query, currentPage])

  const handlePrevPage = () => {
    if (currentPage > 1) {
      const newPage = currentPage - 1
      setCurrentPage(newPage)
      router.push(`/?search=${encodeURIComponent(query)}&page=${newPage}`)
    }
  }

  const handleNextPage = () => {
    if (hasNextPage) {
      const newPage = currentPage + 1
      setCurrentPage(newPage)
      router.push(`/?search=${encodeURIComponent(query)}&page=${newPage}`)
    }
  }

  if (isLoading) {
    return <BoxSkeleton className="h-[400px] w-full" />
  }

  if (results.length === 0) {
    return (
      <div className="text-center space-y-4">
        <div className="text-muted-foreground">
          No results found for &quot;{query}&quot;
        </div>
        <Link href="/">
          <Button variant="outline" className="bg-zinc-800 text-white hover:bg-zinc-700">
            BACK TO HOME
          </Button>
        </Link>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <MangaGrid items={results} />
      <Pagination 
        currentPage={currentPage}
        hasNextPage={hasNextPage}
        onPrevPage={handlePrevPage}
        onNextPage={handleNextPage}
      />
    </div>
  )
}

