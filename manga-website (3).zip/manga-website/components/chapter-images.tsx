"use client"

import { useEffect, useRef, useState } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { AutoScroll } from '@/components/auto-scroll'
import { Loader2, ChevronDown, ChevronLeft, ChevronRight, ArrowUp } from 'lucide-react'
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Popular } from "@/components/popular"
import { fetchPopular } from "@/utils/api"

interface ChapterImage {
  index: number
  download_url: string
}

interface ChapterInfo {
  title: string
  url: string
  weight?: number
}

interface ChapterImagesProps {
  images: ChapterImage[]
  title: string
  chapter: string
  seriesCover: string
  chapterList: ChapterInfo[]
  slug: string
  currentChapter: string
  prevChapter: ChapterInfo | null
  nextChapter: ChapterInfo | null
}

export function ChapterImages({ images, title, chapter, seriesCover, chapterList, slug, currentChapter, prevChapter, nextChapter }: ChapterImagesProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [isScrolling, setIsScrolling] = useState(false)
  const [scrollSpeed, setScrollSpeed] = useState(1)
  const [loadedImages, setLoadedImages] = useState<Set<number>>(new Set())
  const [showBackToTop, setShowBackToTop] = useState(false)
  const [popularItems, setPopularItems] = useState<any[]>([])

  const handleImageLoad = (index: number) => {
    setLoadedImages(prev => new Set(prev).add(index))
  }

  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    const preventDefault = (e: Event) => e.preventDefault()

    const disableRightClick = (e: MouseEvent) => {
      e.preventDefault()
      alert('Right-clicking is disabled')
    }

    container.addEventListener('contextmenu', preventDefault)
    container.addEventListener('mousedown', preventDefault)
    container.addEventListener('mouseup', preventDefault)
    container.addEventListener('contextmenu', disableRightClick)

    return () => {
      container.removeEventListener('contextmenu', preventDefault)
      container.removeEventListener('mousedown', preventDefault)
      container.removeEventListener('mouseup', preventDefault)
      container.removeEventListener('contextmenu', disableRightClick)
    }
  }, [])

  useEffect(() => {
    let animationFrameId: number

    const scroll = () => {
      if (isScrolling) {
        window.scrollBy(0, scrollSpeed)
        animationFrameId = requestAnimationFrame(scroll)
      }
    }

    if (isScrolling) {
      animationFrameId = requestAnimationFrame(scroll)
    }

    return () => {
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId)
      }
    }
  }, [isScrolling, scrollSpeed])

  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > 200)
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    fetchPopular().then(items => setPopularItems(items))
  }, [])

  const sortedChapterList = [...chapterList].sort((a, b) => b.weight - a.weight)

  const getChapterNumber = (url: string) => {
    const match = url.match(/chapter-(\d+)/i)
    return match ? match[1] : ''
  }

  const createChapterUrl = (chapterUrl: string) => {
    const chapterNumber = getChapterNumber(chapterUrl)
    return `/series/${slug}/chapter-${chapterNumber}`
  }

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    })
  }

  return (
    <>
      <div className="space-y-4 mb-4">
        <div className="bg-black/80 backdrop-blur-sm p-4 rounded-lg text-center">
          <h1 className="text-2xl font-bold text-white mb-2">{title}</h1>
          <h2 className="text-xl text-gray-300">{chapter}</h2>
        </div>

        <div className="bg-black/80 backdrop-blur-sm p-4 rounded-lg">
          <div className="flex gap-4">
            <div className="w-16 h-16 shrink-0 relative overflow-hidden rounded-lg">
              <Image
                src={seriesCover}
                alt={title}
                layout="fill"
                objectFit="cover"
              />
            </div>
            <p className="text-white/80">
              Manhwa <span className="font-bold">{title}</span> {chapter} di DoujinDesu.
            </p>
          </div>
          <div className="mt-4 flex justify-between items-center">
            {sortedChapterList.length > 0 && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="bg-zinc-800 text-white">
                    {chapter} <ChevronDown className="ml-2 h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56 bg-zinc-800 text-white">
                  <ScrollArea className="h-[200px]">
                    {sortedChapterList.map((chapterItem, index) => (
                      <DropdownMenuItem key={index} asChild>
                        <Link href={createChapterUrl(chapterItem.url)} className="cursor-pointer">
                          {chapterItem.title}
                        </Link>
                      </DropdownMenuItem>
                    ))}
                  </ScrollArea>
                </DropdownMenuContent>
              </DropdownMenu>
            )}

            <div className="flex gap-2">
              {prevChapter && (
                <Link href={createChapterUrl(prevChapter.url)}>
                  <Button className="bg-red-700 hover:bg-red-800 text-white">
                    Prev
                  </Button>
                </Link>
              )}
              {nextChapter && (
                <Link href={createChapterUrl(nextChapter.url)}>
                  <Button className="bg-green-700 hover:bg-green-800 text-white">
                    Next
                  </Button>
                </Link>
              )}
            </div>
          </div>
        </div>

        <div className="bg-green-800/90 p-4 rounded-lg text-center text-white">
          Chapter ini error ? segera laporkan agar diperbaiki secepatnya!
        </div>
      </div>
      <div ref={containerRef} className="select-none">
        {images.map((image) => (
          <div key={image.index} className="w-full relative" style={{ marginBottom: '-4px' }}>
            {!loadedImages.has(image.index) && (
              <div className="absolute inset-0 flex items-center justify-center bg-zinc-800">
                <Loader2 className="w-8 h-8 animate-spin text-white" />
              </div>
            )}
            <img
              src={image.download_url}
              alt={`Page ${image.index}`}
              className="w-full h-auto pointer-events-none block"
              loading={image.index === 1 ? 'eager' : 'lazy'}
              style={{ WebkitUserSelect: 'none', userSelect: 'none' }}
              onDragStart={(e) => e.preventDefault()}
              onLoad={() => handleImageLoad(image.index)}
            />
          </div>
        ))}
      </div>
      <div className="mt-4 space-y-4">
        <div className="flex justify-between items-center bg-black/80 backdrop-blur-sm p-4 rounded-lg">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="bg-zinc-800 text-white">
                {chapter} <ChevronDown className="ml-2 h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56 bg-zinc-800 text-white">
              <ScrollArea className="h-[200px]">
                {sortedChapterList.map((chapterItem, index) => (
                  <DropdownMenuItem key={index} asChild>
                    <Link href={createChapterUrl(chapterItem.url)} className="cursor-pointer">
                      {chapterItem.title}
                    </Link>
                  </DropdownMenuItem>
                ))}
              </ScrollArea>
            </DropdownMenuContent>
          </DropdownMenu>
          <div className="flex items-center gap-2">
            {prevChapter && (
              <Link href={createChapterUrl(prevChapter.url)}>
                <Button variant="outline" size="icon" className="h-8 w-8">
                  <ChevronLeft className="h-4 w-4" />
                </Button>
              </Link>
            )}
            <div className="text-white">{chapter}</div>
            {nextChapter && (
              <Link href={createChapterUrl(nextChapter.url)}>
                <Button variant="outline" size="icon" className="h-8 w-8">
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </Link>
            )}
          </div>
        </div>
      </div>
      <AutoScroll
        isScrolling={isScrolling}
        setIsScrolling={setIsScrolling}
        scrollSpeed={scrollSpeed}
        setScrollSpeed={setScrollSpeed}
      />
      {showBackToTop && (
        <Button
          variant="secondary"
          size="icon"
          className="fixed bottom-4 right-4 h-10 w-10 rounded-full bg-zinc-800 text-white hover:bg-zinc-700 z-50"
          onClick={scrollToTop}
        >
          <ArrowUp className="h-5 w-5" />
        </Button>
      )}
      <div className="mt-8">
        <Popular items={popularItems} />
      </div>
    </>
  )
}

export function ChapterImagesSkeleton() {
  return (
    <div className="space-y-4">
      <div className="bg-zinc-800 p-4 mb-4 rounded-lg">
        <div className="h-8 w-3/4 bg-zinc-700 rounded mb-2"></div>
        <div className="h-6 w-1/2 bg-zinc-700 rounded"></div>
      </div>
      {[...Array(5)].map((_, index) => (
        <div key={index} className="w-full h-[600px] bg-zinc-800 animate-pulse" />
      ))}
    </div>
  )
}

